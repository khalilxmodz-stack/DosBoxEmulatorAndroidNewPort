# DOSBox Staging

> **Android (armeabi-v7a) port, work in progress and unbuilt:** see [docs/android/README.md](docs/android/README.md).

![GPL-2.0-or-later][gpl-badge]
[![Chat][discord-badge]][discord]

**DOSBox Staging** is a modern continuation of DOSBox with advanced features and current development practices.

It is a (mostly) drop-in replacement for older DOSBox versions—your existing configurations will continue to work, and you will have access to many advanced features.

For a detailed description of the project's scope please refer to the [About](https://www.dosbox-staging.org/about/) page on our website.

## Donations

If you enjoy using DOSBox Staging, please [consider a
donation](https://www.dosbox-staging.org/get-involved/#make-a-donation) to the
project.

If you want to help but can't afford a donation, check out the [Get
involved](https://www.dosbox-staging.org/get-involved/) page of our website
for other ways to contribute.


## Project website

https://www.dosbox-staging.org/

First-time users and people migrating from other DOSBox variants should start by reading the [Getting started guide](https://www.dosbox-staging.org/getting-started/).

## Build status

[![Windows build status][build-windows-badge]][build-windows-ci]
[![macOS build status][build-macos-badge]][build-macos-ci]
[![Linux build status][build-linux-badge]][build-linux-ci]

## Stable release builds

Regular users should use our stable release builds available on our project website:

- [Windows](https://www.dosbox-staging.org/download/windows/)
- [macOS](https://www.dosbox-staging.org/download/macos/)
- [Linux](https://www.dosbox-staging.org/download/linux/)


## Development builds

Development builds are automatically created on every commit merged to the `main` branch. You need to be logged in to GitHub to download the development builds.

[Development builds]

## Key features for developers

| **Feature**                | **Status**                          |
| -------------------------- | -------------------------------     |
| **Version control**        | Git                                 |
| **Language**               | C++23                               |
| **Logging**                | Loguru for C++<sup>[3]</sup>        |
| **Build system**           | CMake + Ninja or Visual Studio 2022 |
| **Dependency manager**     | vcpkg                               |
| **CI**                     | Yes                                 |
| **Static analysis**        | Yes<sup>[1],[2]</sup>               |
| **Dynamic analysis**       | Yes                                 |
| **clang-format**           | Yes                                 |
| **[Development builds]**   | Yes                                 |
| **Unit tests**             | Yes<sup>[4]</sup>                   |

[1]: https://github.com/dosbox-staging/dosbox-staging/actions/workflows/clang-analysis.yml
[2]: https://github.com/dosbox-staging/dosbox-staging/actions/workflows/pvs-studio.yml
[3]: https://github.com/emilk/loguru
[4]: https://github.com/dosbox-staging/dosbox-staging/tree/main/tests
[Development builds]: https://www.dosbox-staging.org/download/development-builds/

## Source code analysis tools

- [PVS-Studio](https://pvs-studio.com/pvs-studio/?utm_source=website&utm_medium=github&utm_campaign=open_source) — C++ static analyser
- [Pylint](https://pypi.org/project/pylint/) — Python static analyser
- [markdownlint](https://github.com/DavidAnson/markdownlint) — style checker and linter for Markdown
- [ShellCheck](https://www.shellcheck.net/) — shell script analysis tool

## Dependencies

DOSBox Staging has the following library dependencies:

| Dependency                                                | Provides feature                                | vcpkg package name | vcpkg version     | Optional?           |
| --------------------------------------------------------- | ----------------------------------------------- | ------------------ | ----------------- | ------------------- |
| [Asio](https://think-async.com/Asio/)                     | Network API for emulated serial and IPX         | asio               | 1.32.0            | **no** :red_circle: |
| [FluidSynth](https://www.fluidsynth.org/)                 | General MIDI playback                           | fluidsynth         | 2.5.7             | **no** :red_circle: |
| [GoogleTest](https://github.com/google/googletest)        | Unit testing (development)                      | gtest              | 1.18.0            | yes :green_circle:  |
| [IIR](https://github.com/berndporr/iir1)                  | Audio filtering                                 | iir1               | 1.10.0            | **no** :red_circle: |
| [libmt32emu](https://github.com/munt/munt)                | Roland MT-32 and CM-32L emulation               | libmt32emu         | 2.8.3             | yes :green_circle:  |
| [libpng](http://www.libpng.org/pub/png/libpng.html)       | PNG encoding of screen captures                 | libpng             | 1.6.58            | **no** :red_circle: |
| [libslirp](https://gitlab.freedesktop.org/slirp/libslirp) | General purpose TCP-IP emulator                 | libslirp           | 4.9.1             | yes :green_circle:  |
| [Opus File](https://opus-codec.org/)                      | CD Audio playback for Opus-encoded audio tracks | opusfile           | 0.12+20221121#1   | **no** :red_circle: |
| [SDL 3](https://github.com/libsdl-org/SDL)                | OS-agnostic API for video, audio, and eventing  | sdl3               | 3.4.16#1          | **no** :red_circle: |
| [SDL_image 3](https://github.com/libsdl-org/SDL_image)    | Image decoding for many popular formats         | sdl3-image         | 3.4.4#1           | **no** :red_circle: |
| [SpeexDSP](https://github.com/xiph/speexdsp)              | Audio resampling                                | speexdsp           | 1.2.1#1           | **no** :red_circle: |
| [zlib-ng](https://github.com/zlib-ng/zlib-ng)             | ZMBV video capture                              | zlib-ng            | 2.3.3             | yes¹ :green_circle: |

_¹ You can use plain old zlib instead._


### Dynamically loaded dependencies

**Slirp** is built separately as a dynamic library (via
vcpkg) and is loaded on-demand at runtime if available. Please refer to the
[dosbox-staging-ext](https://github.com/dosbox-staging/dosbox-staging-ext)
project for further details. To check the version of this dependency 
included in our stable and dev build packages, check out the comments of the
[releases packages](https://github.com/dosbox-staging/dosbox-staging-ext/releases) of
the [dosbox-staging-ext](https://github.com/dosbox-staging/dosbox-staging-ext)
project.

For information on the optional **Nuked SC-55 CLAP** audio plugin, check out
the [plugin's GitHub repository](https://github.com/johnnovak/Nuked-SC55-CLAP/) (note Nuked SC-55
CLAP is _not_ a DOSBox Staging project).


## Build instructions

Please refer to the platform specific build instructions:

- [Windows](docs/build-windows.md)
- [macOS](docs/build-macos.md)
- [Linux](docs/build-linux.md)

For building versions prior to 0.83.0 (e.g. when bisecting), see the
[legacy Meson build guide](docs/build-meson.md).


## Website & documentation

Please refer to the [documentation guide](DOCUMENTATION.md) before making
changes to the website or the documentation.


## Imported branches, community patches, old forks

Upstream commits are imported to this repo in a timely manner,
see branch [`svn/trunk`].

- [`svn/*`] - branches from SVN
- [`forks/*`] - code for various abandoned DOSBox forks
- [`vogons/*`] - community patches posted on the Vogons forum

Git tags matching pattern `svn/*` are pointing to the commits referenced by SVN
"tag" paths at the time of creation.

Additionally, we attach some optional metadata to the commits in the form of
[Git notes][git-notes]. To fetch them, run:

``` shell
git fetch origin "refs/notes/*:refs/notes/*"
```

[`svn/*`]:     https://github.com/dosbox-staging/dosbox-staging/branches/all?utf8=%E2%9C%93&query=svn%2F
[`svn/trunk`]: https://github.com/dosbox-staging/dosbox-staging/tree/svn/trunk
[`vogons/*`]:  https://github.com/dosbox-staging/dosbox-staging/branches/all?utf8=%E2%9C%93&query=vogons%2F
[`forks/*`]:   https://github.com/dosbox-staging/dosbox-staging/branches/all?utf8=%E2%9C%93&query=forks%2F
[git-notes]:   https://git-scm.com/docs/git-notes

[gpl-badge]:     https://img.shields.io/badge/license-GPL--2.0--or--later-blue
[discord-badge]: https://img.shields.io/discord/514567252864008206?color=%237289da&logo=discord&logoColor=white&label=discord
[discord]:       https://discord.gg/WwAg3Xf

[build-windows-badge]: https://img.shields.io/github/actions/workflow/status/dosbox-staging/dosbox-staging/windows.yml?label=Windows%20%28x86_64%29
[build-windows-ci]:    https://github.com/dosbox-staging/dosbox-staging/actions/workflows/windows.yml?query=branch%3Amain

[build-macos-badge]: https://img.shields.io/github/actions/workflow/status/dosbox-staging/dosbox-staging/macos.yml?label=macOS%20%28x86_64%2C%20arm64%29
[build-macos-ci]:    https://github.com/dosbox-staging/dosbox-staging/actions/workflows/macos.yml?query=branch%3Amain

[build-linux-badge]: https://img.shields.io/github/actions/workflow/status/dosbox-staging/dosbox-staging/linux.yml?label=Linux%20%28x86_64%29
[build-linux-ci]:    https://github.com/dosbox-staging/dosbox-staging/actions/workflows/linux.yml?query=branch%3Amain
