// SPDX-FileCopyrightText:  2026-2026 The DOSBox Staging Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "private/shader.h"

#include <array>

#if C_OPENGL

// Build a OpenGL shader program.
//
// Input GLSL source must contain both vertex and fragment stages inside their
// respective preprocessor definitions.
//
// Returns a ready to use OpenGL shader program on success.
//
bool Shader::BuildShaderProgram(const std::string& shader_source)
{
	if (shader_source.empty()) {
		LOG_ERR("OPENGL: No shader source present");
		return false;
	}

	const auto maybe_vertex_shader = BuildShader(GL_VERTEX_SHADER, shader_source);
	if (!maybe_vertex_shader) {
		LOG_ERR("OPENGL: Error compiling vertex shader");
		return false;
	}
	const auto vertex_shader = *maybe_vertex_shader;

	const auto maybe_fragment_shader = BuildShader(GL_FRAGMENT_SHADER,
	                                               shader_source);
	if (!maybe_fragment_shader) {
		LOG_ERR("OPENGL: Error compiling fragment shader");
		glDeleteShader(vertex_shader);
		return false;
	}
	const auto fragment_shader = *maybe_fragment_shader;

	const GLuint shader_program = glCreateProgram();

	if (!shader_program) {
		LOG_ERR("OPENGL: Error creating shader program");
		glDeleteShader(vertex_shader);
		glDeleteShader(fragment_shader);
		return false;
	}

	glAttachShader(shader_program, vertex_shader);
	glAttachShader(shader_program, fragment_shader);

	glLinkProgram(shader_program);

	glDeleteShader(vertex_shader);
	glDeleteShader(fragment_shader);

	// Check the link status
	GLint is_program_linked = GL_FALSE;
	glGetProgramiv(shader_program, GL_LINK_STATUS, &is_program_linked);

	// The info log might contain warnings and info messages even if the
	// linking was successful, so we'll always log it if it's non-empty.
	GLint log_length_bytes = 0;
	glGetProgramiv(shader_program, GL_INFO_LOG_LENGTH, &log_length_bytes);

	// The returned length includes the null termination character
	if (log_length_bytes > 1) {
		std::vector<GLchar> info_log(static_cast<size_t>(log_length_bytes));

		glGetProgramInfoLog(shader_program,
		                    log_length_bytes,
		                    nullptr,
		                    info_log.data());

		if (is_program_linked) {
			LOG_WARNING("OPENGL: Program info log:\n %s",
			            info_log.data());
		} else {
			LOG_ERR("OPENGL: Error linking shader program:\n %s",
			        info_log.data());
		}
	}

	if (!is_program_linked) {
		glDeleteProgram(shader_program);
		return false;
	}

	program_object = shader_program;
	return true;
}

std::optional<GLuint> Shader::BuildShader(const GLenum type,
                                          const std::string& shader_source) const
{
	assert(!shader_source.empty());

	constexpr std::string_view VersionTag = "#version ";
	constexpr std::string_view Newline    = "\n";

	std::string_view body = shader_source;

	// Empty, but still pointing into the source (a default-constructed
	// string_view has a null data pointer)
	auto preamble = body.substr(0, 0);

	// "#version" has to come first, so split the source after its line
	if (const auto version_pos = body.find(VersionTag);
	    version_pos != std::string_view::npos) {

		if (const auto eol = body.find(Newline,
		                               version_pos + VersionTag.size());
		    eol != std::string_view::npos) {

			const auto body_start = eol + Newline.size();

			preamble = body.substr(0, body_start);
			body.remove_prefix(body_start);
		}
	}

	constexpr std::string_view VertexDefine   = "#define VERTEX 1\n";
	constexpr std::string_view FragmentDefine = "#define FRAGMENT 1\n";

	const std::string_view define = (type == GL_VERTEX_SHADER)
	                                      ? VertexDefine
	                                      : FragmentDefine;

	constexpr size_t NumParts = 3;
	const std::array<std::string_view, NumParts> parts = {preamble, define, body};

	std::array<const GLchar*, NumParts> sources = {};
	std::array<GLint, NumParts> lengths         = {};

	for (size_t i = 0; i < parts.size(); ++i) {
		sources[i] = parts[i].data();
		lengths[i] = check_cast<GLint>(parts[i].size());
	}

	const auto shader = glCreateShader(type);
	if (shader == 0) {
		return {};
	}

	glShaderSource(shader,
	               check_cast<GLsizei>(parts.size()),
	               sources.data(),
	               lengths.data());

	// Compile the shader
	glCompileShader(shader);

	// Check the compile status
	GLint is_shader_compiled = 0;

	glGetShaderiv(shader, GL_COMPILE_STATUS, &is_shader_compiled);

	// The info log might contain warnings and info messages even if the
	// compilation was successful, so we'll always log it if it's non-empty.
	GLint log_length_bytes = 0;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &log_length_bytes);

	// The returned length includes the null termination character
	if (log_length_bytes > 1) {
		std::vector<GLchar> info_log(log_length_bytes);
		glGetShaderInfoLog(shader, log_length_bytes, nullptr, info_log.data());

		if (is_shader_compiled) {
			LOG_WARNING("OPENGL: Shader info log: %s", info_log.data());
		} else {
			LOG_ERR("OPENGL: Error compiling shader: %s",
			        info_log.data());
		}
	}

	if (!is_shader_compiled) {
		glDeleteShader(shader);
		return {};
	}

	return shader;
}

GLint Shader::GetUniformLocation(const std::string& name) const
{
	const auto location = glGetUniformLocation(program_object, name.c_str());
#ifdef DEBUG_OPENGL
	if (location == -1) {
		LOG_DEBUG("OPENGL: Error retrieving location of '%s' uniform",
		          name.c_str());
	}
#endif
	return location;
}

void Shader::SetUniform1i(const std::string& name, const int val) const
{
	const auto location = GetUniformLocation(name);
	if (location != -1) {
		glUniform1i(location, val);
	}
}

void Shader::SetUniform1f(const std::string& name, const float val) const
{
	const auto location = GetUniformLocation(name);
	if (location != -1) {
		glUniform1f(location, val);
	}
}

void Shader::SetUniform2f(const std::string& name, const float val1,
                          const float val2) const
{
	const auto location = GetUniformLocation(name);
	if (location != -1) {
		glUniform2f(location, val1, val2);
	}
}

void Shader::SetUniform3f(const std::string& name, const float val1,
                          const float val2, const float val3) const
{
	const auto location = GetUniformLocation(name);
	if (location != -1) {
		glUniform3f(location, val1, val2, val3);
	}
}

#endif
