// SPDX-FileCopyrightText:  2021-2026 The DOSBox Staging Team
// SPDX-FileCopyrightText:  2002-2021 The DOSBox Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "mount.h"
#include "mount_common.h"

#include "dosbox.h"

#include <algorithm>
#include <limits>
#include <vector>

#include "config/config.h"
#include "dos/cdrom.h"
#include "dos/drives.h"
#include "dos/mount.h"
#include "gui/mapper.h"
#include "hardware/ide.h"
#include "ints/bios_disk.h"
#include "ints/int10.h"
#include "misc/cross.h"
#include "misc/notifications.h"
#include "more_output.h"
#include "shell/shell.h"
#include "utils/fs_utils.h"
#include "utils/string_utils.h"
#include <sys/stat.h>

#ifndef S_ISREG
#define S_ISREG(m) (((m) & S_IFMT) == S_IFREG)
#endif

void MOUNT::ListMounts()
{
	const std::string header_drive = MSG_Get("PROGRAM_MOUNT_STATUS_DRIVE");
	const std::string header_type  = MSG_Get("PROGRAM_MOUNT_STATUS_TYPE");
	const std::string header_path  = MSG_Get("PROGRAM_MOUNT_STATUS_PATH");
	const std::string header_label = MSG_Get("PROGRAM_MOUNT_STATUS_LABEL");

	const int console_width = real_readw(BIOSMEM_SEG, BIOSMEM_NB_COLS);

	const auto width_drive = static_cast<int>(header_drive.length());
	const auto width_type  = 16;

	const auto width_label = std::max(minimum_column_length,
	                                  static_cast<int>(header_label.size()));

	const auto width_path = console_width - 4 - width_drive - width_type -
	                        width_label;

	if (width_path < 0) {
		LOG_WARNING("Message is too long.");
		return;
	}

	auto print_row = [&](const std::string& txt_drive,
	                     const std::string& txt_type,
	                     const std::string& txt_path,
	                     const std::string& txt_label) {
		WriteOut("%-*s %-*s %-*s %-*s\n",
		         width_drive,
		         txt_drive.c_str(),
		         width_type,
		         txt_type.c_str(),
		         width_path,
		         txt_path.c_str(),
		         width_label,
		         txt_label.c_str());
	};

	WriteOut("\n");
	print_row(convert_ansi_markup("[color=white]") + header_drive,
	          header_type,
	          header_path,
	          header_label + convert_ansi_markup("[reset]"));

	// Make a horizontal divider that draws "-" underneath the headers,
	// using width_drive, width_type, width_path, and width_label to
	// determine how long each section should be
	const std::string horizontal_divider = std::string(width_drive, '-') + " " +
	                                       std::string(width_type, '-') + " " +
	                                       std::string(width_path, '-') + " " +
	                                       std::string(width_label, '-') + "\n";
	WriteOut_NoParsing(horizontal_divider);

	bool found_drives = false;
	for (uint8_t d = 0; d < DOS_DRIVES; d++) {
		if (Drives[d]) {
			const auto& images = DriveManager::GetFilesystemImages(d);

			// Render rows for drives holding multiple loaded images
			if (images.size() > 1) {
				bool first = true;

				for (const auto& img : images) {
					auto type = img->GetTypeString();
					auto path = img->GetInfo();

					std::string drive_letter_str =
					        first ? convert_ansi_markup(
					                        " [color=light-cyan]" +
					                        std::string{drive_letter(
					                                d)} +
					                        ":[reset]  ")
					              : "";

					std::string label_str =
					        first ? To_Label(Drives[d]->GetLabel())
					              : "";

					std::string type_str = first ? type : "";

					print_row(drive_letter_str,
					          type_str,
					          truncate_path(path, width_path),
					          label_str);

					first = false;
				}
			} else {
				// Render singular drive logic
				auto type = Drives[d]->GetTypeString();
				auto path = Drives[d]->GetInfo();

				print_row(convert_ansi_markup(
				                  " [color=light-cyan]" +
				                  std::string{drive_letter(d)} +
				                  ":[reset]  "),
				          type,
				          truncate_path(path, width_path),
				          To_Label(Drives[d]->GetLabel()));
			}

			found_drives = true;
		}
	}

	if (!found_drives) {
		WriteOut(MSG_Get("PROGRAM_IMGMOUNT_STATUS_NONE"));
	}
	WriteOut("\n");
}

void MOUNT::ShowUsage()
{
	MoreOutputStrings output(*this);

	// Combined help
	output.AddString(MSG_Get("PROGRAM_MOUNT_HELP_LONG"), PRIMARY_MOD_NAME);
#ifdef WIN32
	output.AddString(MSG_Get("PROGRAM_MOUNT_HELP_LONG_WIN32"));
#elif defined(MACOSX)
	output.AddString(MSG_Get("PROGRAM_MOUNT_HELP_LONG_MACOSX"));
#else
	output.AddString(MSG_Get("PROGRAM_MOUNT_HELP_LONG_OTHER"));
#endif
	output.Display();
}

// A helper function that expands wildcard paths from the given argument and
// adds them to the given paths. Returns true if the expansion succeeded.
bool MOUNT::AddWildcardPaths(const std::string& path_arg,
                             std::vector<std::string>& paths)
{
	// Expand the given path argument
	constexpr auto OnlyExpandFiles = true;
	constexpr auto SkipNativePath  = true;

	std::vector<std::string> expanded_paths = {};
	if (!get_expanded_files(path_arg, expanded_paths, OnlyExpandFiles, SkipNativePath)) {
		return false;
	}

	// Sort wildcards with natural ordering
	const auto has_wildcards = path_arg.find_first_of('*') != std::string::npos ||
	                           path_arg.find_first_of('?') != std::string::npos;

	if (has_wildcards) {
		std::sort(expanded_paths.begin(), expanded_paths.end(), natural_compare);
	}

	// Move the expanded paths out
	paths.insert(paths.end(), //-V823
	             std::make_move_iterator(expanded_paths.begin()),
	             std::make_move_iterator(expanded_paths.end()));

	return true;
}

void MOUNT::WriteMountStatus(const std::string& image_type,
                             const std::vector<std::string>& images,
                             char drive_letter, bool readonly)
{
	const size_t term_width = INT10_GetTextColumns();

	constexpr auto Indent  = "  ";
	const auto indent_size = strlen(Indent);

	std::string images_str = {};

	if (images.size() == 1) {
		// If only one image, don't add newlines and just write in one
		// line:
		images_str = image_type.c_str() + std::string(" ") + images[0];

		WriteOut(MSG_Get("PROGRAM_MOUNT_STATUS_2"),
		         images_str.c_str(),
		         drive_letter);

		if (readonly) {
			WriteOut(MSG_Get("PROGRAM_MOUNT_READONLY"));
		}
	} else {

		for (const auto& image : images) {
			assert(!image.empty());

			images_str = images_str.append(
			        std::string(Indent) +
			        truncate_path(image, term_width - indent_size) +
			        std::string("\n"));
		}

		WriteOut(MSG_Get("PROGRAM_MOUNT_RESULT"),
		         image_type.c_str(),
		         drive_letter,
		         images_str.c_str());
	}
}

// Sets:
//   params.sizes
//
bool MOUNT::MountImageFat(MountParameters& params)
{
	// Autosize detection
	bool detect_image_size = (params.type == MountType::HardDiskImage) &&
	                         (params.sizes[0] == 0 && params.sizes[1] == 0 &&
	                          params.sizes[2] == 0 && params.sizes[3] == 0);

	if (detect_image_size) {
		FILE* diskfile = fopen_wrap_ro_fallback(params.paths[0],
		                                        params.roflag);
		if (!diskfile) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_INVALID_IMAGE");
			return false;
		}

		const auto sz = stdio_num_sectors(diskfile);
		if (sz < 0) {
			fclose(diskfile);
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_INVALID_IMAGE");
			return false;
		}

		uint32_t fcsize = check_cast<uint32_t>(sz);
		uint8_t buf[512];

		if (cross_fseeko(diskfile, 0L, SEEK_SET) != 0 ||
		    fread(buf, sizeof(uint8_t), 512, diskfile) < 512) {
			fclose(diskfile);

			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_INVALID_IMAGE");
			return false;
		}

		fclose(diskfile);

		if ((buf[510] != 0x55) || (buf[511] != 0xaa)) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_INVALID_GEOMETRY");
			return false;
		}

		Bitu sectors = (Bitu)(fcsize / (16 * 63));

		if (sectors * 16 * 63 != fcsize) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_INVALID_GEOMETRY");
			return false;
		}

		params.sizes[0] = 512;
		params.sizes[1] = 63;
		params.sizes[2] = 16;
		params.sizes[3] = static_cast<uint16_t>(sectors);

		LOG_MSG("DRIVE: Autosized image file: %d:%d:%d:%d",
		        params.sizes[0],
		        params.sizes[1],
		        params.sizes[2],
		        params.sizes[3]);
	}

	if (Drives.at(drive_index(params.drive))) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_ALREADY_MOUNTED");
		return false;
	}

	DriveManager::filesystem_images_t fat_images = {};

	for (const auto& fat_path : params.paths) {
		auto fat_image = std::make_shared<fatDrive>(fat_path.c_str(),
		                                            params.sizes[0],
		                                            params.sizes[1],
		                                            params.sizes[2],
		                                            params.sizes[3],
		                                            params.mediaid,
		                                            params.roflag);
		if (fat_image->created_successfully) {
			fat_images.push_back(fat_image);

		} else {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_CANT_CREATE");
			return false;
		}
	}
	if (fat_images.empty()) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_CANT_CREATE");
		return false;
	}

	// Update DriveManager
	DriveManager::AppendFilesystemImages(drive_index(params.drive), fat_images);
	DriveManager::InitializeDrive(drive_index(params.drive));

	// Set the correct media byte in the table
	// Each entry is 9 bytes, with the media byte at offset 0x00
	constexpr auto DptEntrySize = 9;

	mem_writeb(RealToPhysical(dos.tables.mediaid) +
	                   drive_index(params.drive) * DptEntrySize,
	           params.mediaid);

	// Command uses dta so set it to our internal dta
	RealPt save_dta = dos.dta();
	dos.dta(dos.tables.tempdta);

	for (auto it = fat_images.begin(); it != fat_images.end(); ++it) {
		const bool should_notify = std::next(it) == fat_images.end();

		DriveManager::CycleDisks(drive_index(params.drive), should_notify);

		// Obtain the drive label, saving it in the dirCache
		char root[7] = {params.drive, ':', '\\', '*', '.', '*', 0};

		if (!DOS_FindFirst(root, FatAttributeFlags::Volume)) {
			LOG_WARNING("DRIVE: Unable to find %c drive's volume label",
			            params.drive);
		}
	}

	dos.dta(save_dta);

	std::string mount_message = (params.paths.size() > 1)
	                                  ? MSG_Get("MOUNT_TYPE_FAT_PLURAL")
	                                  : MSG_Get("MOUNT_TYPE_FAT");

	WriteMountStatus(mount_message, params.paths, params.drive, params.roflag);

	const auto fat_image = std::dynamic_pointer_cast<fatDrive>(
	        fat_images.front());

	assert(fat_image);

	const auto has_hdd = fat_image->loadedDisk && fat_image->loadedDisk->hardDrive;

	const auto is_floppy = (params.drive == 'A' || params.drive == 'B') &&
	                       !has_hdd;

	const auto is_hdd = (params.drive == 'C' || params.drive == 'D') && has_hdd;

	if (is_floppy || is_hdd) {
		imageDiskList.at(drive_index(params.drive)) = fat_image->loadedDisk;
		updateDPT();
	}

	return true;
}

// Return string representation of MSCDEX_AddDrive error code
static const char* mscdex_error_to_message_id(const int error, const bool is_image_file)
{
	switch (error) {
	case 0: return "MSCDEX_SUCCESS";
	case 1: return "MSCDEX_ERROR_MULTIPLE_CDROMS";
	case 2: return "MSCDEX_ERROR_NOT_SUPPORTED";
	case 3:

		return is_image_file ? "MSCDEX_ERROR_OPEN" : "MSCDEX_ERROR_PATH";
	case 4: return "MSCDEX_TOO_MANY_DRIVES";
	case 5: return "MSCDEX_LIMITED_SUPPORT";
	case 6: return "MSCDEX_INVALID_FILEFORMAT";

	default: return "MSCDEX_UNKNOWN_ERROR";
	}
}

bool MOUNT::MountImageIso(const MountParameters& params)
{
	if (Drives.at(drive_index(params.drive))) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_ALREADY_MOUNTED");
		return false;
	}

	// create new drives for all images
	DriveManager::filesystem_images_t iso_images = {};

	for (const auto& iso_path : params.paths) {
		int error = -1;

		iso_images.push_back(std::make_shared<isoDrive>(
		        params.drive, iso_path.c_str(), params.mediaid, error));

		// error: report and leave
		if (error) { //-V547
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      mscdex_error_to_message_id(error, true));

			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_CANT_CREATE");
			return false;
		}
	}

	// Update DriveManager
	DriveManager::AppendFilesystemImages(drive_index(params.drive), iso_images);
	DriveManager::InitializeDrive(drive_index(params.drive));

	// Set the correct media byte in the table
	mem_writeb(RealToPhysical(dos.tables.mediaid) + drive_index(params.drive) * 9,
	           params.mediaid);

	// If instructed, attach to IDE controller as ATAPI CD-ROM device
	if (params.is_ide) {
		if (params.ide_index >= 0) {
			IDE_CDROM_Attach(params.ide_index,
			                 params.is_second_cable_slot,
			                 drive_index(params.drive));
		} else {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_IDE_CONTROLLERS_UNAVAILABLE");
		}
	}

	// Print status message (success)
	NOTIFY_DisplayInfoMessage(Notification::Source::Console,
	                          "MOUNT",
	                          mscdex_error_to_message_id(0, true));

	std::string mount_message = (params.paths.size() > 1)
	                                  ? MSG_Get("MOUNT_TYPE_CDIMAGE_PLURAL")
	                                  : MSG_Get("MOUNT_TYPE_CDIMAGE");

	WriteMountStatus(mount_message, params.paths, params.drive, params.roflag);

	return true;
}

// Sets:
//   params.roflag
//
bool MOUNT::MountImageRaw(MountParameters& params)
{
	auto new_disk = fopen_wrap_ro_fallback(params.paths[0], params.roflag);
	if (!new_disk) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_INVALID_IMAGE");
		return false;
	}

	const auto sz = stdio_size_kb(new_disk);
	if (sz < 0) {
		fclose(new_disk);

		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_INVALID_IMAGE");
		return false;
	}

	auto imagesize = check_cast<uint32_t>(sz);

	// 0=A:, 1=B:, 2=C:, 3=D:
	const auto is_hdd = (params.drive >= '2');

	// Seems to make sense to require a valid geometry..
	if (is_hdd && params.sizes[0] == 0 && params.sizes[1] == 0 &&
	    params.sizes[2] == 0 && params.sizes[3] == 0) {

		fclose(new_disk);

		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_SPECIFY_GEOMETRY");
		return false;
	}

	const auto drv_idx = params.drive - '0';

	imageDiskList.at(drv_idx) = std::make_shared<imageDisk>(
	        new_disk, params.paths[0].c_str(), imagesize, is_hdd);

	if (is_hdd) {
		imageDiskList.at(drv_idx)->Set_Geometry(params.sizes[2],
		                                        params.sizes[3],
		                                        params.sizes[1],
		                                        params.sizes[0]);
	}

	if ((params.drive == '2' || params.drive == '3') && is_hdd) {
		updateDPT();
	}

	WriteOut(MSG_Get("PROGRAM_IMGMOUNT_MOUNT_NUMBER"),
	         drv_idx,
	         params.paths[0].c_str());

	return true;
}

bool MOUNT::MountImage(MountParameters& params)
{
	// Determine Media ID if not already set strictly
	params.mediaid = (params.type == MountType::FloppyImage)
	                       ? MediaId::Floppy1_44MB
	                       : MediaId::HardDisk;

	if (params.fstype == MountFileSystemType::Fat16) {
		return MountImageFat(params);

	} else if (params.fstype == MountFileSystemType::Iso) {
		return MountImageIso(params);

	} else if (params.fstype == MountFileSystemType::None) {
		return MountImageRaw(params);
	}

	return true;
}

bool MOUNT::HandleUnmount()
{
	std::string umount = {};

	// Standard order: -u <drive>
	if (cmd->FindString("-u", umount, false)) {
		WriteOut(UnmountHelper(umount[0]), toupper(umount[0]));
		return true;
	}

	// Reverse order: <drive> -u
	if (cmd->FindExist("-u", false)) {
		// Check umount != "-u" to prevent parsing errors if the user
		// just types "mount -u".
		if (cmd->FindCommand(1, umount) && !umount.empty() && umount != "-u") {
			WriteOut(UnmountHelper(umount[0]), toupper(umount[0]));
			return true;
		}
	}

	return false;
}

static std::optional<MountFileSystemType> parse_file_system_type(const std::string s)
{
	if (iequals(s, "fat")) {
		return MountFileSystemType::Fat16;

	} else if (iequals(s, "iso")) {
		return MountFileSystemType::Iso;

	} else if (iequals(s, "none")) {
		return MountFileSystemType::None;

	} else {
		return {};
	}
}

// Parses a single -chs or -size geometry value. The geometry is stored in
// uint16_t fields, so out-of-range values would silently wrap (e.g., 65536
// cylinders would become 0).
static std::optional<uint16_t> parse_geometry_value(const std::string& s)
{
	constexpr auto MaxValue = std::numeric_limits<uint16_t>::max();

	const auto value = parse_int(s);
	if (!value || *value < 1 || *value > MaxValue) {
		return {};
	}
	return static_cast<uint16_t>(*value);
}

// Parses the -size option value (BytesPerSector,Sectors,Heads,Cylinders)
static std::optional<std::array<uint16_t, 4>> parse_size_option(const std::string& s)
{
	const auto parts = split_with_empties(s, ",");

	std::array<uint16_t, 4> sizes = {};
	if (parts.size() != sizes.size()) {
		return {};
	}

	for (size_t i = 0; i < sizes.size(); ++i) {
		const auto value = parse_geometry_value(parts[i]);
		if (!value) {
			return {};
		}
		sizes[i] = *value;
	}
	return sizes;
}

// The FAT and raw image mounts read sectors into fixed 512-byte buffers, so
// larger sector sizes would overflow them. The limit does not apply to ISO
// images (which ignore the geometry; their default has 2048-byte sectors) or
// to directory mounts (which only use the geometry to report free space).
static bool is_sector_size_supported(const MountParameters& params)
{
	constexpr auto MaxBytesPerSector = 512;

	const auto uses_sector_size = params.is_image_mode &&
	                              params.fstype != MountFileSystemType::Iso;

	return !uses_sector_size || params.sizes[0] <= MaxBytesPerSector;
}

// CD-ROM options of the original DOSBox. They have no effect in DOSBox Staging,
// but they're still common in old configs, so they're ignored with a warning
// instead of being rejected as unknown options.
constexpr std::array LegacyCdRomFlags =
        {"-ioctl", "-noioctl", "-ioctl_dx", "-ioctl_dio", "-ioctl_mci", "-aspi"};

constexpr auto LegacyCdRomOptionWithValue = "-usecd";

// Returns the first option that requires a value and is either the last
// argument or is followed by another MOUNT option. Values can otherwise start
// with a dash (e.g., `-label -DISK-`).
static std::optional<std::string> find_option_missing_value(const CommandLine& cmd)
{
	constexpr std::array OptionsWithValue = {"-t",
	                                         "-fs",
	                                         "-label",
	                                         "-freesize",
	                                         "-size",
	                                         "-chs",
	                                         LegacyCdRomOptionWithValue};

	constexpr std::array Flags = {"-pr", "-ro", "-ide"};

	const auto is_one_of = [](const std::string& arg, const auto& options) {
		return std::ranges::any_of(options, [&arg](const auto option) {
			return iequals(arg, option);
		});
	};

	std::string arg      = {};
	std::string next_arg = {};

	for (auto i = 1; cmd.FindCommand(i, arg); ++i) {
		if (!is_one_of(arg, OptionsWithValue)) {
			continue;
		}

		const auto is_missing = !cmd.FindCommand(i + 1, next_arg) ||
		                        is_one_of(next_arg, OptionsWithValue) ||
		                        is_one_of(next_arg, Flags) ||
		                        is_one_of(next_arg, LegacyCdRomFlags);
		if (is_missing) {
			return arg;
		}
	}
	return {};
}

// Finds and removes a value-taking option and its value. Only the first
// occurrence is used, but all of them are removed so that repeated options are
// not mistaken for paths.
static std::optional<std::string> find_remove_option_value(CommandLine& cmd,
                                                           const std::string& option)
{
	std::string value = {};
	if (!cmd.FindString(option, value, true)) {
		return {};
	}

	std::string ignored_value = {};
	while (cmd.FindString(option, ignored_value, true)) {
	}
	return value;
}

static void remove_legacy_cdrom_options(CommandLine& cmd)
{
	const auto warn_ignored = [](const char* option) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "MSCDEX_WARNING_NO_OPTION",
		                      option);
	};

	for (const auto option : LegacyCdRomFlags) {
		if (cmd.FindExistRemoveAll(option)) {
			warn_ignored(option);
		}
	}

	if (find_remove_option_value(cmd, LegacyCdRomOptionWithValue)) {
		warn_ignored(LegacyCdRomOptionWithValue);
	}
}

// Sets:
//   params.type   (from the -t option)
//   params.roflag (from the -ro option)
//   params.fstype (from the -fs option or if -t iso is specified)
//
//   params.is_ide (from the -ide option))
//   params.ide_index (based on DOS internal state)
//   params.is_second_cable_slot (based on DOS internal state)
//
//   params.label  (from the -label option)
//
bool MOUNT::ParseArguments(MountParameters& params, bool& explicit_fs,
                           bool& path_relative_to_last_config)
{
	// Reject options with missing values upfront, so an option never
	// consumes the next option as its value
	if (const auto option = find_option_missing_value(*cmd); option) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MISSING_OPTION_VALUE",
		                      option->c_str());
		return false;
	}

	remove_legacy_cdrom_options(*cmd);

	if (cmd->FindExistRemoveAll("-pr")) {
		path_relative_to_last_config = true;
	}

	// Default is "dir" if the -t option is not provided
	const auto type_str = find_remove_option_value(*cmd, "-t").value_or("dir");

	const auto maybe_mount_type = parse_mount_type(type_str);
	if (!maybe_mount_type) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MOUNT_ILL_TYPE",
		                      type_str.c_str());
		return false;
	}
	params.type = *maybe_mount_type;

	params.roflag = cmd->FindExistRemoveAll("-ro");

	// Parse -fs (filesystem type)
	// Default is "fat" if the -fs option is not provided
	const auto fs_value = find_remove_option_value(*cmd, "-fs");

	explicit_fs           = fs_value.has_value();
	const auto fstype_str = fs_value.value_or("fat");

	const auto maybe_fs_type = parse_file_system_type(fstype_str);
	if (!maybe_fs_type) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MOUNT_ILL_TYPE",
		                      fstype_str.c_str());
		return false;
	}
	if (explicit_fs) {
		params.fstype = *maybe_fs_type;
	} else {
		if (params.type == MountType::CdRomImage) {
			params.fstype = MountFileSystemType::Iso;
		}
	}

	// Parse -ide. It is a flag, so anything following it is left on the
	// command line.
	params.is_ide = cmd->FindExistRemoveAll("-ide");

	if (params.is_ide && (params.type == MountType::CdRomImage)) {
		IDE_Get_Next_Cable_Slot(params.ide_index, params.is_second_cable_slot);
	}

	// Label
	params.label = find_remove_option_value(*cmd, "-label").value_or("");

	return true;
}

MOUNT::GeometryOptions MOUNT::ParseGeometryOptions()
{
	return {.freesize = find_remove_option_value(*cmd, "-freesize"),
	        .size     = find_remove_option_value(*cmd, "-size"),
	        .chs      = find_remove_option_value(*cmd, "-chs")};
}

// Sets:
//   params.mediaid
//   params.sizes
//
bool MOUNT::ParseGeometry(MountParameters& params, const GeometryOptions& options)
{
	// Default sizing logic based on type
	switch (params.type) {
	case MountType::FloppyImage:
		params.sizes = {512, 1, 2880, 2880};

		params.mediaid = MediaId::Floppy1_44MB;
		break;

	case MountType::Directory:
	case MountType::Overlay: {
		// 512*32*32765==~500MB total size
		// 512*32*16000==~250MB total free size
		params.sizes = {512, 32, 32765, 16000};

		// If drive mounted to A or B, set mediaid to floppy
		// This is preferable to using type because floppies can
		// be auto-mounted as type "dir"
		std::string command_arg;
		cmd->FindCommand(1, command_arg);

		if (!command_arg.empty()) {
			const int i_drive = std::toupper(command_arg[0]);

			if (i_drive == 'A' || i_drive == 'B') {
				params.mediaid = MediaId::Floppy1_44MB;
			}
		}
	} break;

	case MountType::CdRomImage:
		params.sizes = {2048, 1, 65535, 0};

		// mediaid is used in staging to differentiate between floppy
		// and non-floppy for cache rescan, disk noise and I/O timing.
		// The same value was used in the original dosbox code
		params.mediaid = MediaId::HardDisk;
		break;

	case MountType::HardDiskImage: break;

	default: assertm(false, "Invalid MountType");
	}

	// Parse the free space in mb (kb for floppies)
	if (options.freesize) {
		const auto freesize = static_cast<uint16_t>(
		        atoi(options.freesize->c_str()));

		if (params.type == MountType::FloppyImage) {
			// freesize in kb
			const auto free_sectors = freesize * 1024 / 512;

			params.sizes = {512, 1, 2880, static_cast<uint16_t>(free_sectors)};
		} else {
			uint32_t total_size_cyl = 32765;

			uint32_t free_size_cyl = (uint32_t)freesize * 1024 *
			                         1024 / (512 * 32);

			if (free_size_cyl > 65534) {
				free_size_cyl = 65534;
			}
			if (total_size_cyl < free_size_cyl) {
				total_size_cyl = free_size_cyl + 10;
			}
			if (total_size_cyl > 65534) {
				total_size_cyl = 65534;
			}
			params.sizes = {512,
			                32,
			                static_cast<uint16_t>(total_size_cyl),
			                static_cast<uint16_t>(free_size_cyl)};
		}
	}

	// Parse -size B,S,H,C
	if (options.size) {
		const auto sizes = parse_size_option(*options.size);
		if (!sizes) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_MOUNT_INVALID_SIZE");
			return false;
		}
		params.sizes = *sizes;
	}

	// Parse -chs C,H,S
	if (options.chs) {
		const auto parts = split(*options.chs, ",");

		std::optional<uint16_t> cylinders = {};
		std::optional<uint16_t> heads     = {};
		std::optional<uint16_t> sectors   = {};

		if (parts.size() == 3) {
			cylinders = parse_geometry_value(parts[0]);
			heads     = parse_geometry_value(parts[1]);
			sectors   = parse_geometry_value(parts[2]);
		}

		if (!cylinders || !heads || !sectors) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_MOUNT_INVALID_CHS");
			return false;
		}

		params.sizes[0] = 512;
		params.sizes[1] = *sectors;
		params.sizes[2] = *heads;
		params.sizes[3] = *cylinders;
	}

	return true;
}

// Sets:
//   params.drive
//   params.fstype
//   params.is_drive_number
//
bool MOUNT::ParseDrive(MountParameters& params, bool explicit_fs)
{
	// get the drive letter or number
	std::string temp_line;

	cmd->FindCommand(1, temp_line);

	if ((temp_line.size() > 2) ||
	    ((temp_line.size() > 1) && (temp_line[1] != ':'))) {

		ShowUsage();
		return false;
	}

	const char first_char  = toupper(temp_line[0]);
	params.is_drive_number = false;

	if (isdigit(first_char)) {
		// Handle Drive Numbers (0, 1, 2, 3) for bootable images
		if (first_char >= '0' && first_char <= '3') {
			params.drive           = first_char;
			params.is_drive_number = true;

			// If user did not explicit specify filesystem, assume
			// 'none' for raw bootable access
			if (!explicit_fs) {
				params.fstype = MountFileSystemType::None;
			}
		} else {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_IMGMOUNT_SPECIFY2");
			return false;
		}

	} else if (first_char >= 'A' && first_char <= 'Z') {
		params.drive = first_char;

		// Allow A:, B:, C: and D: to be mounted as raw bootable images
		if (explicit_fs && params.fstype == MountFileSystemType::None) {
			switch (params.drive) {
			case 'A':
				params.drive           = '0';
				params.is_drive_number = true;
				break;
			case 'B':
				params.drive           = '1';
				params.is_drive_number = true;
				break;
			case 'C':
				params.drive           = '2';
				params.is_drive_number = true;
				break;
			case 'D':
				params.drive           = '3';
				params.is_drive_number = true;
				break;
			default:
				// Don't allow booting from E:, F:, etc.
				NOTIFY_DisplayWarning(Notification::Source::Console,
				                      "MOUNT",
				                      "PROGRAM_IMGMOUNT_SPECIFY2");
				return false;
			}
		}
	} else {
		ShowUsage();
		return false;
	}

	// Check overlaps
	if (!params.is_drive_number) {
		if (params.type == MountType::Overlay) {
			// Ensure that the base drive exists:
			if (!Drives.at(drive_index(params.drive))) {
				NOTIFY_DisplayWarning(Notification::Source::Console,
				                      "MOUNT",
				                      "PROGRAM_MOUNT_OVERLAY_NO_BASE");
				return false;
			}
		} else if (Drives.at(drive_index(params.drive))) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_MOUNT_ALREADY_MOUNTED",
			                      params.drive,
			                      Drives.at(drive_index(params.drive))
			                              ->GetInfoString()
			                              .c_str());
			return false;
		}
	}

	return true;
}

std::string MOUNT::ApplyRelativePath(const std::string& path,
                                     bool is_relative_to_last_config) const
{
	if (is_relative_to_last_config && !control->config_files.empty() &&
	    !std_fs::path(path).is_absolute()) {

		auto last_config_dir = control->config_files.back();

		const auto pos = last_config_dir.rfind(CROSS_FILESPLIT);

		last_config_dir.erase(pos == std::string::npos ? 0 : pos);
		if (!last_config_dir.empty()) {
			return last_config_dir + CROSS_FILESPLIT + path;
		}
	}
	return path;
}

// Translates a DOS path to a host path if the DOS path is currently mapped as a
// drive. Returns an empty string if it cannot be translated.
std::string MOUNT::GetDosMappedHostPath(const std::string& dos_path) const
{
	// DOS_MakeName requires a writable buffer
	auto fullname_buf = std::array<char, CROSS_LEN>{};
	uint8_t drive_idx = 0;

	if (DOS_MakeName(dos_path.data(), fullname_buf.data(), &drive_idx)) {

		if (Drives.at(drive_idx) &&
		    Drives.at(drive_idx)->GetType() == DosDriveType::Local) {

			if (const auto local_drive = std::dynamic_pointer_cast<localDrive>(
			            Drives.at(drive_idx))) {

				return local_drive->MapDosToHostFilename(
				        fullname_buf.data());
			}
		}
	}

	return "";
}

// Process paths and prepare (mutate) the passed `MountParameters` for
// mounting. This includes resolving host paths, wildcard path arguments,
// auto-detecting mount types, and determining whether we're dealing with
// image or directory/overlay mounts.
//
// Sets:
//   params.fstype
//   params.is_image_mode
//   params.mediaid
//   params.paths
//   params.type
//
void MOUNT::ProcessPaths(const std::string first_path, MountParameters& params,
                         bool path_relative_to_last_config)
{
	// Expand ~ to home directory and apply relative path logic
	auto path_arg_1 = ApplyRelativePath(resolve_home(first_path).string(),
	                                    path_relative_to_last_config);

#if defined(WIN32)
	// Removing trailing backslash if not root dir so stat will succeed
	if (path_arg_1.size() > 3 && path_arg_1.back() == '\\') {
		path_arg_1.pop_back();
	}
#endif

	// Check first path on the host OS
	struct stat test = {};
	auto stat_ok     = (stat(path_arg_1.c_str(), &test) == 0);

	// If not found on the host, check if it is a mounted DOS path
	if (!stat_ok) {
		const auto mapped_host_path = GetDosMappedHostPath(path_arg_1);

		if (!mapped_host_path.empty() &&
		    stat(mapped_host_path.c_str(), &test) == 0) {
			stat_ok = true;
		}
	}

	const auto target_is_dir = stat_ok && S_ISDIR(test.st_mode);

	const auto explicit_image_type = (params.type == MountType::HardDiskImage ||
	                                  params.type == MountType::CdRomImage ||
	                                  params.type == MountType::FloppyImage);

	const auto has_wildcards = path_arg_1.find_first_of("*?") !=
	                           std::string::npos;

	params.is_image_mode = (explicit_image_type || params.is_drive_number ||
	                        has_wildcards);

	// If the target is a directory, it is a directory mount,
	// even if -t floppy was specified (legacy MOUNT behavior).
	if (target_is_dir) {
		params.is_image_mode = false;
	}

	// Implicit trigger: First argument exists and is a regular file
	if (!params.is_image_mode && stat_ok && S_ISREG(test.st_mode)) {
		params.is_image_mode = true;
	}

	if (params.is_image_mode) {
		// Loop through all remaining arguments
		auto arg_idx        = 2;
		std::string cur_arg = "";

		while (cmd->FindCommand(arg_idx++, cur_arg)) {

			// Expand ~, then apply relative path logic
			cur_arg = ApplyRelativePath(resolve_home(cur_arg).string(),
			                            path_relative_to_last_config);

			// Resolve virtual drive letters to host paths first
			const auto mapped_path = GetDosMappedHostPath(cur_arg);
			const auto path_to_expand = mapped_path.empty()
			                                  ? cur_arg
			                                  : mapped_path;

			// Now try wildcard expansion on the translated host path
			if (path_to_expand.find_first_of("*?") != std::string::npos) {
				if (MOUNT::AddWildcardPaths(path_to_expand,
				                            params.paths)) {
					continue;
				}
			}

			// Fallback for literal files
			const auto real_path = to_native_path(path_to_expand);
			auto loop_final_path = real_path.empty() ? path_to_expand
			                                         : real_path;

			if (real_path.empty() ||
			    !local_drive_path_exists(real_path.c_str())) {

				// Try Virtual DOS Drive mapping
				auto found_on_virtual = false;

				const auto fallback_mapped = GetDosMappedHostPath(
				        cur_arg);

				if (!fallback_mapped.empty() &&
				    local_drive_path_exists(fallback_mapped.c_str())) {
					loop_final_path  = fallback_mapped;
					found_on_virtual = true;
				}

				if (!found_on_virtual) {
					// Try wildcards if strictly not found
					if (MOUNT::AddWildcardPaths(cur_arg,
					                            params.paths)) {
						continue;
					}
				}
			}

			// Auto-detect type from FIRST valid file if generic "dir"
			if (params.paths.empty() &&
			    params.type == MountType::Directory) {
				struct stat t2 = {};

				if (stat(loop_final_path.c_str(), &t2) == 0 &&
				    S_ISREG(t2.st_mode)) {

					auto ext = loop_final_path.substr(
					        loop_final_path.find_last_of('.') + 1);

					std::transform(ext.begin(),
					               ext.end(),
					               ext.begin(),
					               ::tolower);

					if (ext == "iso" || ext == "cue" ||
					    ext == "bin" || ext == "mds" ||
					    ext == "ccd") {

						params.type = MountType::CdRomImage;
						params.fstype = MountFileSystemType::Iso;

					} else if (ext == "vhd") {
						params.type = MountType::HardDiskImage;

					} else if (ext == "vfd" || ext == "flp" ||
					           ext == "360" || ext == "720" ||
					           ext == "1200" || ext == "1440") {
						params.type = MountType::FloppyImage;

					} else if (ext == "img" ||
					           ext == "ima" || ext == "dsk") {

						const auto file_size_kb =
						        static_cast<uint32_t>(
						                t2.st_size / 1024);

						const auto& geometries =
						        BIOS_GetDiskGeometryList();

						const bool is_floppy = std::ranges::any_of(
						        geometries,
						        [file_size_kb](
						                const DiskGeometry& geo) {
							        return geo.ksize ==
							               file_size_kb;
						        });

						params.type = is_floppy
						                    ? MountType::FloppyImage
						                    : MountType::HardDiskImage;
					}
				}
			}

			// Resolves to absolute canonical path
			loop_final_path = simplify_path(loop_final_path).string();
			params.paths.push_back(loop_final_path);
		}

		// Ensure consistency between type and fstype if user didn't
		// override -fs
		if (params.type == MountType::FloppyImage &&
		    params.fstype == MountFileSystemType::Fat16) {

			params.mediaid = MediaId::Floppy1_44MB;
		}

	} else {
		// Standard directory or overlay mount
		if (S_ISDIR(test.st_mode)) {
			params.paths.push_back(path_arg_1);
		}
	}
}

bool MOUNT::MountPaths(MountParameters& params)
{
	if (params.paths.empty()) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_IMGMOUNT_FILE_NOT_FOUND");
		return false;
	}

	if (params.is_image_mode) {
		const auto success = MountImage(params);
		if (success && params.type == MountType::FloppyImage) {
			incrementFDD();
		}

	} else {
		// Standard directory or overlay mount
		MountLocal(params, params.paths[0]);
	}

	return true;
}

void MOUNT::MountLocal(MountParameters& params, const std::string& local_path)
{
	std::string final_path = local_path;

	if (!final_path.empty() && final_path.back() != CROSS_FILESPLIT) {
		final_path += CROSS_FILESPLIT;
	}

	// Give a warning when mount c:\ or the / root directory
#if defined(WIN32)
	if ((final_path == "c:\\") || (final_path == "C:\\") ||
	    (final_path == "c:/") || (final_path == "C:/")) {

		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MOUNT_WARNING_WIN");
	}
#else
	if (final_path == "/") {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MOUNT_WARNING_OTHER");
	}
#endif

	std::shared_ptr<DOS_Drive> newdrive = {};

	const uint8_t int8_tize = (uint8_t)params.sizes[1];

	if (params.type == MountType::Overlay) {
		const auto ldp = std::dynamic_pointer_cast<localDrive>(
		        Drives[drive_index(params.drive)]);

		const auto cdp = std::dynamic_pointer_cast<cdromDrive>(
		        Drives[drive_index(params.drive)]);

		if (!ldp || cdp) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      "PROGRAM_MOUNT_OVERLAY_INCOMPAT_BASE");
			return;
		}
		std::string base = ldp->GetBasedir();
		uint8_t o_error  = 0;
		newdrive         = std::make_shared<Overlay_Drive>(base.c_str(),
                                                           final_path.c_str(),
                                                           params.sizes[0],
                                                           int8_tize,
                                                           params.sizes[2],
                                                           params.sizes[3],
                                                           params.mediaid,
                                                           o_error);
		// Erase old drive on success
		if (o_error) { //-V547
			if (o_error == 1) {
				NOTIFY_DisplayWarning(Notification::Source::Console,
				                      "MOUNT",
				                      "PROGRAM_MOUNT_OVERLAY_REL_ABS");

			} else if (o_error == 2) {
				NOTIFY_DisplayWarning(Notification::Source::Console,
				                      "MOUNT",
				                      "PROGRAM_MOUNT_OVERLAY_SAME_FS");
			} else {
				NOTIFY_DisplayWarning(Notification::Source::Console,
				                      "MOUNT",
				                      "PROGRAM_MOUNT_OVERLAY_UNKNOWN_ERROR");
			}
			return;
		}
		// Copy current directory if not marked as deleted.
		if (newdrive->TestDir(ldp->curdir)) {
			safe_strcpy(newdrive->curdir, ldp->curdir);
		}
		Drives.at(drive_index(params.drive)) = nullptr;

	} else if (params.type == MountType::CdRomImage) {
		// Mount a host directory as a CD-ROM drive.
		int error = 0;
		newdrive  = std::make_shared<cdromDrive>(params.drive,
                                                        final_path.c_str(),
                                                        params.sizes[0],
                                                        int8_tize,
                                                        params.sizes[2],
                                                        0,
                                                        params.mediaid,
                                                        error);

		const char* msg_id = mscdex_error_to_message_id(error, false);

		if (error == 0) { //-V457 //-V547
			NOTIFY_DisplayInfoMessage(Notification::Source::Console,
			                          "MOUNT",
			                          msg_id);
		} else {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "MOUNT",
			                      msg_id);
		}

		// Errors 1-4 are fatal; 0 (success) and 5 (limited support
		// for subdirectory mounts) allow the drive to be registered.
		if (error && error != 5) { //-V560
			return;
		}
	} else {
		const auto section = get_section("dosbox");

		// Standard directory mount
		newdrive = std::make_shared<localDrive>(
		        final_path.c_str(),
		        params.sizes[0],
		        int8_tize,
		        params.sizes[2],
		        params.sizes[3],
		        params.mediaid,
		        params.roflag,
		        section->GetBool("allow_write_protected_files"));
	}

	DriveManager::RegisterFilesystemImage(drive_index(params.drive), newdrive);
	Drives.at(drive_index(params.drive)) = newdrive;

	// Set the correct media byte in the table
	mem_writeb(RealToPhysical(dos.tables.mediaid) +
	                   (drive_index(params.drive)) * 9,
	           newdrive->GetMediaByte());

	if (params.type != MountType::Overlay) {
		WriteOut(MSG_Get("PROGRAM_MOUNT_STATUS_2"),
		         newdrive->GetInfoString().c_str(),
		         params.drive);

		if (params.roflag) {
			WriteOut(MSG_Get("PROGRAM_MOUNT_READONLY"));
		}
	} else {
		WriteOut(MSG_Get("PROGRAM_MOUNT_OVERLAY_STATUS"),
		         final_path.c_str(),
		         params.drive);
	}

	// check if volume label is given and don't allow it to updated in the
	// future
	if (!params.label.empty()) {
		const auto is_cdrom = (params.type == MountType::CdRomImage);
		newdrive->dirCache.SetLabel(params.label.c_str(), is_cdrom, false);

	} else if (params.type == MountType::Directory ||
	           params.type == MountType::Overlay) {
		// For hard drives set the label to DRIVELETTER_Drive.
		// For floppy drives set the label to DRIVELETTER_Floppy.
		// This way every drive except cdroms should get a label.
		params.label = params.drive;
		params.label += "_DRIVE";

		newdrive->dirCache.SetLabel(params.label.c_str(), false, false);

	} else if (params.type == MountType::FloppyImage) {
		// Floppy labels handled in IMGMOUNT logic usually, but if
		// mounted as dir:
		params.label = params.drive;
		params.label += "_FLOPPY";

		newdrive->dirCache.SetLabel(params.label.c_str(), false, true);
	}

	// We incrementFDD here only if it was a directory mount pretending to
	// be floppy Image mounts return early.
	if (params.type == MountType::FloppyImage) {
		incrementFDD();
	}
}

void MOUNT::Run(void)
{
	if (std::string{cmd->GetFileName()} == "Z:\\IMGMOUNT.COM") {
		// Print deprecation notice
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "IMGMOUNT",
		                      "PROGRAM_IMGMOUNT_DEPRECATED");
	}

	// Hack to allow long commandlines
	ChangeToLongCmd();

	if (!cmd->GetCount()) {
		ListMounts();
		return;
	}
	if (HelpRequested()) {
		ShowUsage();
		return;
	}
	if (control->SecureMode()) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_CONFIG_SECURE_DISALLOW");
		return;
	}

	// Check for unmounting
	if (HandleUnmount()) {
		return;
	}

	ProcessArguments(cmd);
}

std::optional<MountParameters> MOUNT::ProcessArguments(CommandLine* cmd)
{
	// To make it easier injecting arbitrary command lines in the unit tests
	this->cmd = cmd;

	MountParameters params;

	bool explicit_fs                  = false;
	bool path_relative_to_last_config = false;

	// Parse command line arguments
	if (!ParseArguments(params, explicit_fs, path_relative_to_last_config)) {
		return {};
	}

	// Remove the remaining options; everything left on the command line is
	// treated as a path. The geometry values can only be applied once the
	// mount type is known, so they are kept until after the paths have been
	// processed.
	const auto geometry_options = ParseGeometryOptions();

	// All known options have been removed by now, so anything else starting
	// with a dash is an unknown option, not a path
	std::string unknown_option = {};
	if (cmd->FindStringBegin("-", unknown_option)) {
		unknown_option = "-" + unknown_option;

		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "SHELL_ILLEGAL_SWITCH",
		                      unknown_option.c_str());
		return {};
	}

	// Get the first path argument
	std::string first_path = {};
	if (!cmd->FindCommand(2, first_path) || first_path.empty()) {
		ShowUsage();
		return {};
	}

	// Resolve host paths, wildcard path arguments, auto-detect mount types,
	// and determine whether we're dealing with image or directory/overlay
	// mounts.
	ProcessPaths(first_path, params, path_relative_to_last_config);

	// Check drive geometry and types, abort if not valid
	if (!ParseGeometry(params, geometry_options)) {
		return {};
	}

	// Check drive letter/number and overlaps, abort if not valid
	if (!ParseDrive(params, explicit_fs)) {
		return {};
	}

	// Must come after ParseDrive() as that can change the filesystem type
	if (!is_sector_size_supported(params)) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "MOUNT",
		                      "PROGRAM_MOUNT_UNSUPPORTED_SECTOR_SIZE");
		return {};
	}

	if (!MountPaths(params)) {
		return {};
	}

	return params;
}

void MOUNT::AddMessages()
{
	AddCommonMountMessages();
	if (MSG_Exists("PROGRAM_MOUNT_HELP")) {
		return;
	}
	MSG_Add("PROGRAM_MOUNT_HELP",
	        "Mount a directory or an image file to a drive letter.\n");

	MSG_Add("PROGRAM_MOUNT_HELP_LONG",
	        "Mount a directory or an image file to a drive letter.\n"
	        "\n"
	        "Usage:\n"
	        "  [color=light-green]mount[reset] [color=white]DRIVE[reset] [color=light-cyan]PATH[reset] [PARAMETERS]\n"
	        "  [color=light-green]mount[reset] [color=white]DRIVE[reset] [color=light-cyan]IMAGEFILE[reset] [IMAGEFILE2...] [PARAMETERS]\n"
	        "  [color=light-green]mount[reset] [color=white]DRIVE[reset] [color=light-cyan]IMAGE-SET[reset] [PARAMETERS]\n"
	        "  [color=light-green]mount[reset] -u [color=white]DRIVE[reset]  (unmounts [color=white]DRIVE[reset])\n"
	        "\n"
	        "Common parameters:\n"
	        "  [color=white]DRIVE[reset]           drive letter (A-Z) to mount to\n"
	        "  [color=light-cyan]PATH[reset]            directory on the host OS (absolute or relative path)\n"
	        "  [color=light-cyan]IMAGEFILE[reset]       image file on the host OS (absolute or relative path) or on a\n"
	        "                  mounted DOS drive (e.g. C:\\GAME.ISO)\n"
	        "  [color=light-cyan]IMAGE-SET[reset]       ISO, CUE+BIN, CUE+ISO, or CUE+ISO+FLAC/OPUS/OGG/MP3/WAV\n"
	        "\n"
	        "  -t [color=white]TYPE[reset]         type of mount: [color=light-cyan]dir[reset], [color=light-cyan]overlay[reset], [color=light-cyan]floppy[reset], [color=light-cyan]hdd[reset], [color=light-cyan]iso[reset] (or [color=light-cyan]cdrom[reset])\n"
	        "  -fs [color=white]FS[reset]          filesystem: [color=light-cyan]fat[reset], [color=light-cyan]iso[reset], or [color=light-cyan]none[reset] (for bootable images)\n"
	        "  -label [color=white]LABEL[reset]    volume label to assign to the mounted drive\n"
	        "  -ro             mount as read-only\n"
	        "\n"
	        "Directory mount parameters:\n"
	        "  -freesize [color=white]SIZE[reset]  size (in KB for floppies, in MB for hard disks); sets the\n"
	        "                  amount of free space available on the drive (~250 MB by\n"
	        "                  default for HDD directory mounts)\n"
	        "  -t [color=light-cyan]overlay[reset]      mounts the directory as an overlay on top of an existing drive\n"
	        "\n"
	        "Image parameters:\n"
	        "  -chs [color=white]C,H,S[reset]      specify geometry ([color=white]C[reset]ylinders,[color=white]H[reset]eads,[color=white]S[reset]ectors) for HDD images\n"
	        "  -size [color=white]B,S,H,C[reset]   specify geometry ([color=white]B[reset]ytesPerSector,[color=white]S[reset]ectors,[color=white]H[reset]eads,[color=white]C[reset]ylinders);\n"
	        "                  alternative to -chs for HDD images\n"
	        "  -ide            attach as IDE device (for CD-ROM and HDD images)\n"
	        "  -pr             path is relative to the configuration file location\n"
	        "\n"
	        "Notes:\n"
	        "  - Use wildcards or multiple image files to mount them at the same drive\n"
	        "    letter, then press [color=yellow]%s+F4[reset] to cycle between them. This is useful for\n"
	        "    programs that require swapping disks while running.\n"
	        "\n"
	        "  - The -ide flag emulates an IDE controller for an attached HDD or CD drive\n"
	        "    for CD-based games that need a real DOS environment via a bootable HDD\n"
	        "    image.\n"
	        "\n"
	        "  - Type [color=light-cyan]overlay[reset] requires [color=white]DRIVE[reset] to be already mounted. It mounts [color=light-cyan]PATH[reset] on the\n"
	        "    host OS as a write-layer over the drive. Modified files are stored in [color=light-cyan]PATH[reset],\n"
	        "    leaving the original drive data unchanged.\n"
	        "\n"
	        "Examples:\n");

	MSG_Add("PROGRAM_MOUNT_HELP_LONG_WIN32",
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]C:\\dosgames[reset]\n"
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]C:\\dosgamesoverlay[reset] -t overlay\n"
	        "  [color=light-green]mount[reset] [color=white]D[reset] [color=light-cyan]D:\\Games\\doom.iso[reset] -t iso\n"
	        "  [color=light-green]mount[reset] [color=white]2[reset] [color=light-cyan]Win95.img[reset] -t hdd -fs none -chs 304,64,63\n"
	        "  [color=light-green]mount[reset] [color=white]0[reset] [color=light-cyan]floppy.img[reset] -t floppy -fs none\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]floppy*.img[reset] -t floppy\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]disk01.img disk02.img[reset] -t floppy\n");

	MSG_Add("PROGRAM_MOUNT_HELP_LONG_MACOSX",
	        "  (~ is expanded to your home directory)\n"
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]~/dosgames[reset]\n"
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]~/dosgamesoverlay[reset] -t overlay\n"
	        "  [color=light-green]mount[reset] [color=white]D[reset] [color=light-cyan]~/Games/doom.iso[reset] -t iso\n"
	        "  [color=light-green]mount[reset] [color=white]2[reset] [color=light-cyan]Win95.img[reset] -t hdd -fs none -chs 304,64,63\n"
	        "  [color=light-green]mount[reset] [color=white]0[reset] [color=light-cyan]floppy.img[reset] -t floppy -fs none\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]floppy*.img[reset] -t floppy -ro\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]disk01.img disk02.img[reset] -t floppy\n");

	MSG_Add("PROGRAM_MOUNT_HELP_LONG_OTHER",
	        "  (~ is expanded to your home directory)\n"
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]~/dosgames[reset]\n"
	        "  [color=light-green]mount[reset] [color=white]C[reset] [color=light-cyan]~/dosgamesoverlay[reset] -t overlay\n"
	        "  [color=light-green]mount[reset] [color=white]D[reset] [color=light-cyan]~/Games/doom.iso[reset] -t iso\n"
	        "  [color=light-green]mount[reset] [color=white]2[reset] [color=light-cyan]Win95.img[reset] -t hdd -fs none -chs 304,64,63\n"
	        "  [color=light-green]mount[reset] [color=white]0[reset] [color=light-cyan]floppy.img[reset] -t floppy -fs none\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]floppy*.img[reset] -t floppy -ro\n"
	        "  [color=light-green]mount[reset] [color=white]A[reset] [color=light-cyan]disk01.img disk02.img[reset] -t floppy\n");

	MSG_Add("PROGRAM_MOUNT_CDROMS_FOUND", "CD-ROMs found: %d\n");
	MSG_Add("PROGRAM_MOUNT_ERROR_1", "Directory or file %s doesn't exist.\n");

	MSG_Add("PROGRAM_MOUNT_ERROR_2",
	        "%s isn't a directory or valid image file.\n");

	MSG_Add("PROGRAM_MOUNT_ILL_TYPE", "Illegal type %s");
	MSG_Add("PROGRAM_MOUNT_ALREADY_MOUNTED", "Drive %c already mounted with %s\n");
	MSG_Add("PROGRAM_MOUNT_UMOUNT_NOT_MOUNTED", "Drive %c isn't mounted.\n");

	MSG_Add("PROGRAM_MOUNT_UMOUNT_SUCCESS",
	        "Drive %c has successfully been removed.\n");

	MSG_Add("PROGRAM_MOUNT_UMOUNT_NO_VIRTUAL",
	        "Virtual Drives can not be unMOUNTed.\n");

	MSG_Add("PROGRAM_MOUNT_DRIVEID_ERROR",
	        "'%c' is not a valid drive identifier.\n");

	MSG_Add("PROGRAM_MOUNT_WARNING_WIN",
	        "[color=light-red]Mounting c:\\ is NOT recommended. Please mount a (sub)directory next time.[reset]\n");

	MSG_Add("PROGRAM_MOUNT_WARNING_OTHER",
	        "[color=light-red]Mounting / is NOT recommended. Please mount a (sub)directory next time.[reset]\n");

	MSG_Add("PROGRAM_MOUNT_NO_OPTION",
	        "Warning: Ignoring unsupported option '%s'.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_NO_BASE",
	        "A normal directory needs to be MOUNTed first before an overlay can be added on\n"
	        "top.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_INCOMPAT_BASE",
	        "The overlay is NOT compatible with the drive that is specified.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_MIXED_BASE",
	        "The overlay needs to be specified using the same addressing as the underlying\n"
	        "drive. No mixing of relative and absolute paths.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_SAME_AS_BASE",
	        "The overlay directory can not be the same as underlying drive.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_GENERIC_ERROR", "Something went wrong.\n");
	MSG_Add("PROGRAM_MOUNT_OVERLAY_STATUS", "Overlay %s on drive %c mounted.\n");

	MSG_Add("PROGRAM_MOUNT_INVALID_CHS",
	        "Invalid CHS format. Use -chs cylinders,heads,sectors\n");

	MSG_Add("PROGRAM_MOUNT_INVALID_SIZE",
	        "Invalid size format. Use -size BytesPerSector,Sectors,Heads,Cylinders\n");

	MSG_Add("PROGRAM_MOUNT_UNSUPPORTED_SECTOR_SIZE",
	        "Sector sizes larger than 512 bytes are not supported.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_REL_ABS",
	        "The overlay needs to be specified using the same addressing as the underlying\n"
	        "drive. No mixing of relative and absolute paths.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_SAME_FS",
	        "The overlay needs to be on the same filesystem as the underlying drive.\n");

	MSG_Add("PROGRAM_MOUNT_OVERLAY_UNKNOWN_ERROR", "Something went wrong.\n");

	// IMGMOUNT merged messages
	MSG_Add("PROGRAM_IMGMOUNT_SPECIFY2",
	        "Must specify a drive letter A/B/C/D or drive number 0/1/2/3 to mount image at.\n");

	MSG_Add("PROGRAM_IMGMOUNT_SPECIFY_GEOMETRY",
	        "For hard drive images, drive geometry must be specified:\n"
	        "  [color=light-green]imgmount[reset] [color=white]DRIVE[reset] [color=light-cyan]IMAGEFILE[reset] -chs Cylinders,Heads,Sectors\n"
	        "Alternatively:\n"
	        "  [color=light-green]imgmount[reset] [color=white]DRIVE[reset] [color=light-cyan]IMAGEFILE[reset] -size BytesPerSector,Sectors,Heads,Cylinders\n"
	        "For CD-ROM images:\n"
	        "  [color=light-green]imgmount[reset] [color=white]DRIVE[reset] [color=light-cyan]IMAGEFILE[reset] -t iso\n");

	MSG_Add("PROGRAM_IMGMOUNT_STATUS_NONE", "No drive available.\n");

	MSG_Add("PROGRAM_IMGMOUNT_IDE_CONTROLLERS_UNAVAILABLE",
	        "No available IDE controllers. Drive will not have IDE emulation.\n");

	MSG_Add("PROGRAM_IMGMOUNT_INVALID_IMAGE",
	        "Could not load image file.\n"
	        "Check that the path is correct and the image is accessible.\n");

	MSG_Add("PROGRAM_IMGMOUNT_INVALID_GEOMETRY",
	        "Could not extract drive geometry from image.\n"
	        "Use parameter -chs Cylinders,Heads,Sectors to specify the geometry.\n"
	        "Alternatively: -size BytesPerSector,Sectors,Heads,Cylinders\n");

	MSG_Add("PROGRAM_IMGMOUNT_FILE_NOT_FOUND", "Image file not found.\n");

	MSG_Add("PROGRAM_IMGMOUNT_ALREADY_MOUNTED",
	        "Drive already mounted at that letter.\n");

	MSG_Add("PROGRAM_IMGMOUNT_CANT_CREATE", "Can't create drive from file.\n");
	MSG_Add("PROGRAM_IMGMOUNT_MOUNT_NUMBER", "Drive number %d mounted as %s.\n");

	MSG_Add("PROGRAM_IMGMOUNT_DEPRECATED",
	        "The [color=light-green]IMGMOUNT[reset] command is deprecated; "
	        "please use [color=light-green]MOUNT[reset] instead.");
}
