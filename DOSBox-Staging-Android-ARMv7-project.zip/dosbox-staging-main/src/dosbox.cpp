// SPDX-FileCopyrightText:  2020-2026 The DOSBox Staging Team
// SPDX-FileCopyrightText:  2002-2021 The DOSBox Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "dosbox.h"

#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>

#ifdef WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
// block winsock.h to prevent net_defs.h redefinition errors
#define _WINSOCKAPI_
#include <windows.h>
#endif

#include "audio/disk_noise.h"
#include "audio/mixer.h"
#include "capture/capture.h"
#include "config/config.h"
#include "config/setup.h"
#include "cpu/callback.h"
#include "cpu/cpu.h"
#include "cpu/paging.h"
#include "debugger/debugger.h"
#include "dos/dos.h"
#include "dos/dos_locale.h"
#include "dos/programs.h"
#include "dosbox_pause_fsm.h"
#include "fpu/fpu.h"
#include "gui/common.h"
#include "gui/mapper.h"
#include "gui/render/render.h"
#include "gui/titlebar.h"
#include "hardware/audio/gus.h"
#include "hardware/audio/imfc.h"
#include "hardware/audio/innovation.h"
#include "hardware/audio/opl.h"
#include "hardware/audio/pcspeaker.h"
#include "hardware/audio/soundblaster.h"
#include "hardware/audio/speaker.h"
#include "hardware/cmos.h"
#include "hardware/dma.h"
#include "hardware/input/joystick.h"
#include "hardware/input/keyboard.h"
#include "hardware/input/mouse.h"
#include "hardware/memory.h"
#include "hardware/network/ipx.h"
#include "hardware/network/ne2000.h"
#include "hardware/pci_bus.h"
#include "hardware/pic.h"
#include "hardware/port.h"
#include "hardware/serialport/serialport.h"
#include "hardware/timer.h"
#include "hardware/video/reelmagic/reelmagic.h"
#include "hardware/video/vga.h"
#include "hardware/video/voodoo.h"
#include "hardware/virtualbox.h"
#include "hardware/vmware.h"
#include "ints/bios.h"
#include "ints/int10.h"
#include "midi/midi.h"
#include "misc/cross.h"
#include "misc/support.h"
#include "misc/video.h"
#include "network/ethernet.h"
#include "shell/autoexec.h"
#include "shell/shell.h"
#include "utils/math_utils.h"
#include "utils/string_utils.h"
#include "webserver/bridge.h"
#include "webserver/webserver.h"

MachineType machine = MachineType::None;
SvgaType svga_type  = SvgaType::None;

static LoopHandler* loop;

static struct {
	int64_t remain    = {};
	int64_t last      = {};
	int64_t added     = {};
	int64_t done      = {};
	int64_t scheduled = {};
	bool locked       = {};
} ticks = {};

// Reset wall-clock accounting on resume so `increase_ticks()` doesn't see
// a multi-second gap from before pause and try to "catch up" by running
// tens of seconds of emulation in a burst. PIC time is frozen across
// pause; only the wall-clock counters need this rebase.
//
static void rebase_wall_clock_on_resume()
{
	ticks.last      = GetTicks();
	ticks.remain    = 0;
	ticks.added     = 0;
	ticks.done      = 0;
	ticks.scheduled = 0;
}

int64_t DOSBOX_GetTicksDone()
{
	return ticks.done;
}

void DOSBOX_SetTicksDone(const int64_t ticks_done)
{
	ticks.done = ticks_done;
}

void DOSBOX_SetTicksScheduled(const int64_t ticks_scheduled)
{
	ticks.scheduled = ticks_scheduled;
}

void Null_Init([[maybe_unused]] Section* sec)
{
	// do nothing
}

// ---------------------------------------------------------------------------
// Pause state machine
//
// Mirrors the structure of `MixerMuteState` in `audio/mixer.h` --
// user-initiated pause survives the auto-pausing (on focus loss); only the
// auto-pausing can be auto-cleared.
//
// The pending states exist to give the SDL-side fade-out enough real audio
// to work against. Without them, when pause was requested with a
// nearly-drained `final_output` buffer (low prebuffer config, host CPU
// contention, right after fast-forward), the fade would hit silence
// midway and click. During pending we keep producing real audio, so the
// fade always has ~5 ms of it to attenuate.
//
// Resume has no equivalent pending state because the fade-in works for
// free: on resume the mixer thread immediately starts producing real
// audio and ramps the fade-in gain up over it, in-buffer.
//
// All transitions go through `set_pause_state()` (validated against
// `is_valid_transition()`). Public callers express intent via the four
// `DOSBOX_Request{User,Auto}{Pause,Resume}()` API functions, each of which
// consults the pure `NextPauseState()` policy in `dosbox_pause_fsm.h` and
// applies the result. That policy is the single source of truth for what
// each event does; it is exhaustively unit tested in isolation.
//
// THREADING: `pause_state` has a single writer, the main (emulation) thread.
// Every mutator runs there: hotkeys and window events via the SDL event loop,
// HTTP commands via the webserver bridge's `ProcessRequests()`, and the
// pending-transition handler via the PIC ticker. All other threads (the mixer
// and MIDI renderer threads) only *read* the state, via the `DOSBOX_Is*()`
// query functions. With a single writer no lock is needed; the atomic exists
// purely to make those cross-thread reads well-defined.
//
// The `PauseState` and `PauseEvent` enums and the pure `NextPauseState()`
// transition table live in `dosbox_pause_fsm.h`.
// ---------------------------------------------------------------------------

// Single writer (the main thread; see THREADING above).
// All other threads read only.
static std::atomic<PauseState> pause_state{PauseState::Running};

static const char* to_string(const PauseState s)
{
	using enum PauseState;

	switch (s) {
	case Running: return "Running";
	case UserPausePending: return "UserPausePending";
	case AutoPausePending: return "AutoPausePending";
	case UserPaused: return "UserPaused";
	case AutoPaused: return "AutoPaused";

	default: assertm(false, "Invalid PauseState value"); return "";
	}
}

static bool is_pending_state(const PauseState s)
{
	return (s == PauseState::UserPausePending ||
	        s == PauseState::AutoPausePending);
}

static bool is_paused_state(const PauseState s)
{
	return (s == PauseState::UserPaused || s == PauseState::AutoPaused);
}

// Structural guard for the application layer: which edges the FSM permits at
// all. Every state produced by `NextPauseState()` satisfies this, plus the
// unconditional force-to-`Running` used on shutdown. `set_pause_state()`
// asserts on it to catch a bad direct store.
static bool is_valid_transition(const PauseState from, const PauseState to)
{
	using enum PauseState;

	switch (from) {
	case Running: return (to == UserPausePending || to == AutoPausePending);
	case UserPausePending: return (to == UserPaused || to == Running);

	case AutoPausePending:
		return (to == AutoPaused || to == Running || to == UserPausePending);

	case UserPaused: return (to == Running);
	case AutoPaused: return (to == Running || to == UserPaused);

	default: assertm(false, "Invalid PauseState value"); return false;
	}
}

// Pure pause-transition policy; it just maps (current state, event) to the
// next state, or `nullopt` for a no-op.
//
// The `DOSBOX_Request*()` API and `pending_pause_tick_handler()` below apply
// its result. Exhaustively unit tested in `dosbox_pause_fsm_tests.cpp`.
//
std::optional<PauseState> NextPauseState(const PauseState current,
                                         const PauseEvent event)
{
	using enum PauseState;

	switch (event) {
	case PauseEvent::UserPause:
		// User pause trumps auto: it engages from Running, upgrades a
		// pending/engaged auto-pause, and is idempotent once
		// user-paused.
		//
		switch (current) {
		case Running: return UserPausePending;
		case AutoPausePending: return UserPausePending;
		case AutoPaused: return UserPaused;

		case UserPausePending:
		case UserPaused: return {};

		default: assertm(false, "Invalid PauseState value"); return {};
		}
		break;

	case PauseEvent::UserResume:
		// Only clears a user pause; auto-pauses are left for
		// auto-resume.
		//
		switch (current) {
		case UserPausePending: return Running;
		case UserPaused: return Running;

		case Running:
		case AutoPausePending:
		case AutoPaused: return {};

		default: assertm(false, "Invalid PauseState value"); return {};
		}
		break;

	case PauseEvent::AutoPause:
		// Engages only from Running; a user-pause survives it and an
		// existing auto-pause is idempotent.
		switch (current) {
		case Running: return AutoPausePending;

		case UserPausePending:
		case UserPaused:
		case AutoPausePending:
		case AutoPaused: return {};

		default: assertm(false, "Invalid PauseState value"); return {};
		}
		break;

	case PauseEvent::AutoResume:
		// Clears an auto-pause only; never resumes a user pause.
		//
		switch (current) {
		case AutoPausePending: return Running;
		case AutoPaused: return Running;

		case Running:
		case UserPausePending:
		case UserPaused: return {};

		default: assertm(false, "Invalid PauseState value"); return {};
		}
		break;

	case PauseEvent::FadeComplete:
		// The audio fade-out reached zero -- engage the pending pause.
		switch (current) {
		case UserPausePending: return UserPaused;
		case AutoPausePending: return AutoPaused;

		case Running:
		case UserPaused:
		case AutoPaused: return {};

		default: assertm(false, "Invalid PauseState value"); return {};
		}
		break;
	}

	return {};
}

static PauseState get_pause_state()
{
	return pause_state.load(std::memory_order_relaxed);
}

bool DOSBOX_IsRunning()
{
	return get_pause_state() == PauseState::Running;
}

bool DOSBOX_IsPaused()
{
	// Only the actually-paused states -- pending states still have the
	// emulator core, mixer, and MIDI renderer running so the fade has
	// audio to work against. See the FSM header comment.
	return is_paused_state(get_pause_state());
}

bool DOSBOX_IsPauseRequested()
{
	// True for any non-Running state (pending or paused). Callers that
	// want "user has asked to pause" semantics -- e.g. the fade trigger,
	// or the shutdown force-resume -- use this.
	return get_pause_state() != PauseState::Running;
}

// Subsystem pause hook driven by the FSM. Called by `set_pause_state()` only
// on the actually-paused edge. The mixer needs no hook here -- it reads
// `DOSBOX_IsPaused()` at the top of its loop and skips `mix_samples()` while
// paused. Only the MIDI synth renderers have to be actively halted, so their
// internal clock doesn't advance while paused (see `MIDI_Pause()`).
static void set_subsystems_paused(const bool paused)
{
	if (paused) {
		MIDI_Pause();
	} else {
		MIDI_Resume();
	}
}

// Applies a validated pause-state transition and drives the subsystem hooks.
// Only ever called on the main thread (see THREADING above), so nothing has
// to serialise concurrent transitions.
static void set_pause_state(const PauseState new_state)
{
	using enum PauseState;

	const auto prev_state = get_pause_state();

	if (prev_state == new_state) {
		return;
	}

	if (!is_valid_transition(prev_state, new_state)) {
		LOG_WARNING("DOSBOX: Invalid pause transition %s -> %s", //-V510
		            to_string(prev_state),
		            to_string(new_state));

		assertm(false, "Invalid PauseState transition");
		return;
	}

	const auto was_paused_actual   = is_paused_state(prev_state);
	const auto was_pause_requested = (prev_state != Running);

	const auto now_paused_actual   = is_paused_state(new_state);
	const auto now_pause_requested = (new_state != Running);
	const auto now_running         = (new_state == Running);

	const auto request_edge = (now_pause_requested != was_pause_requested);
	const auto actual_edge  = (now_paused_actual != was_paused_actual);

	pause_state.store(new_state, std::memory_order_relaxed);

	if (was_paused_actual && now_running) {
		rebase_wall_clock_on_resume();
	}

	// Halt / wake the subsystems only when the actually-paused status
	// flips; the FSM guarantees this edge fires exactly once per pause
	// and once per resume.
	if (actual_edge) {
		set_subsystems_paused(now_paused_actual);
	}

	// Refresh the titlebar on both the pause-request edge (so any UI
	// that reflects "pause pending" updates instantly on user input)
	// and on the actually-paused edge (which is when the paused
	// indicator -- driven by `DOSBOX_IsPaused()` -- flips). Log only
	// on the actually-paused edge so it reflects when subsystems
	// really halted.
	if (request_edge || actual_edge) {
		TITLEBAR_RefreshTitle();
	}

	if (now_paused_actual && !was_paused_actual) {
		LOG_MSG("DOSBOX: Paused");

	} else if (was_paused_actual && now_running) {
		LOG_MSG("DOSBOX: Resumed");
	}
}

// Drives the `*Pending` -> `*Paused` transition. Runs on the emulator
// thread via PIC's 1 kHz ticker so it fires from a context that's safe
// to call `MIXER_LockMixerThread()` from.
//
// The transition is gated on the fade actually completing --
// `MIXER_GetPlaybackGain()` reflects the ramp maintained by the mixer
// thread, so we hand off to the actually-paused state exactly when
// the audible fade-out reaches zero, not on a wall-clock deadline. No
// timeout fallback: the fade completing IS the signal. Nosound-mode
// works too because the mixer thread snaps the gain directly to
// target when it hits the `no_sound` sleep path -- the FSM sees 0
// immediately and transitions without waiting for a non-existent
// audible fade.
//
static void pending_pause_tick_handler()
{
	using enum PauseState;

	// Fast path: not in a pending state, nothing to do. This runs
	// 1000 times a second regardless, so keep it cheap.
	if (!is_pending_state(get_pause_state())) {
		return;
	}

	if (MIXER_GetPlaybackGain() > 0.0f) {
		return;
	}

	if (const auto next = NextPauseState(get_pause_state(),
	                                     PauseEvent::FadeComplete)) {
		set_pause_state(*next);
	}
}

void DOSBOX_RequestUserPause()
{
	// Never engage a new pause once shutdown has been requested --
	// `DOSBOX_RequestShutdown()` force-resumes so teardown runs from a
	// known-running state, and a late pause request must not undo that
	// between the shutdown request and the main loop exiting.
	if (DOSBOX_IsShutdownRequested()) {
		return;
	}

	if (const auto next = NextPauseState(get_pause_state(),
	                                     PauseEvent::UserPause)) {
		set_pause_state(*next);
	}
}

void DOSBOX_RequestUserResume()
{
	if (const auto next = NextPauseState(get_pause_state(),
	                                     PauseEvent::UserResume)) {
		set_pause_state(*next);
	}
}

void DOSBOX_RequestAutoPause()
{
	// Never engage a new pause after a shutdown request; see
	// `DOSBOX_RequestUserPause()`.
	if (DOSBOX_IsShutdownRequested()) {
		return;
	}

	if (const auto next = NextPauseState(get_pause_state(),
	                                     PauseEvent::AutoPause)) {
		set_pause_state(*next);
	}
}

void DOSBOX_RequestAutoResume()
{
	if (const auto next = NextPauseState(get_pause_state(),
	                                     PauseEvent::AutoResume)) {
		set_pause_state(*next);
	}
}

// CPU-thread tick handler paused. Keeps presentation, host input pump,
// mapper, and webserver bridge alive so hotkeys (fullscreen toggle,
// screenshot, mapper, capture start/stop, config reload) and remote
// commands keep working while the emulator core is frozen.
//
static Bitu paused_tick()
{
	if (DOSBOX_IsShutdownRequested()) {
		return 1;
	}

	GFX_MaybePresentFrame();

	if (!GFX_PollAndHandleEvents()) {
		return 0;
	}

	if (WEBSERVER_IsEnabled()) {
		Webserver::Bridge::Instance().ProcessRequests();
	}

	MAPPER_RunPending();

	constexpr uint64_t one_ms_ns = 1'000'000;
	SDL_DelayPrecise(one_ms_ns);
	return 0;
}

// forward declaration
static void increase_ticks();

static Bitu normal_loop()
{
	if (DOSBOX_IsPaused()) {
		return paused_tick();
	}

	Bits ret;

	while (true) {
		if (PIC_RunQueue()) {
			if (WEBSERVER_IsEnabled()) {
				Webserver::Bridge::Instance().ProcessRequests();
			}

			ret = (*cpudecoder)();
			if (ret < 0) {
				return 1;
			}
			if (ret > 0) {
				if (ret >= CB_MAX) {
					return 0;
				}
				Bitu result = (*Callback_Handlers[ret])();
				if (result) {
					return result;
				}
			}
#if C_DEBUGGER
			if (DEBUG_ExitLoop()) {
				return 0;
			}
#endif
		} else {
			// In 'host-rate' presentation mode, this effectively
			// accomplishes polling at the sub-millisecond level for
			// presenting the frame.
			//
			// We're effectively implementing cooperative
			// multitasking here to present the frame at roughly the
			// right time as `GFX_MaybePresentFrame()` is called
			// around 2-5 times per tick (1 ms) depending on the
			// cycles setting.
			//
			// This is a good-enough alternative to moving the
			// entire emulation off the main thread and then
			// presenting the last-rendered frame at regular
			// intervals from the main thread.
			//
			if (GFX_GetPresentationMode() == PresentationMode::HostRate) {
				GFX_MaybePresentFrame();
			}

			MAPPER_RunPending();

			if (!GFX_PollAndHandleEvents()) {
				return 0;
			}
			if (ticks.remain > 0) {
				TIMER_AddTick();
				--ticks.remain;

				// `pending_pause_tick_handler()` may have just
				// engaged the pause inside `TIMER_AddTick()`.
				// Bail out right away instead of emulating the
				// rest of the tick budget (up to 20 ms):
				// subsystems are already parked, so a MIDI
				// burst in that window could fill the synth's
				// `work_fifo` and deadlock the main thread on
				// its blocking enqueue (the consumer -- the
				// synth renderer thread -- was just halted).
				if (DOSBOX_IsPaused()) {
					return 0;
				}
			} else {
				increase_ticks();
				return 0;
			}
		}
	}
}

constexpr auto auto_cpu_cycles_min = 200;

static void increase_ticks()
{
	// Make it return ticks.remain and set it in the function above to
	// remove the global variable.

	// For fast-forward mode
	if (ticks.locked) {
		ticks.remain = 5;

		// Reset any auto cycle guessing for this frame
		ticks.last      = GetTicks();
		ticks.added     = 0;
		ticks.done      = 0;
		ticks.scheduled = 0;
		return;
	}

	const auto ticks_new_us = GetTicksUs();
	const auto ticks_new    = ticks_new_us / MicrosInMillisecond;

	ticks.scheduled += ticks.added;

	// Lower should not be possible, only equal
	if (ticks_new <= ticks.last) {
		ticks.added = 0;

		static int64_t cumulative_time_slept_us = 0;

		// Sleep until the next millisecond tick boundary rather than a
		// flat 1ms, to wake up as close to the next tick as possible.
		const auto next_tick_us = (ticks.last + 1) * MicrosInMillisecond;
		const auto sleep_us = next_tick_us - ticks_new_us;
		if (sleep_us > 0) {
			SDL_DelayPrecise(static_cast<uint64_t>(sleep_us) * 1000);
		}

		const auto time_slept_us = GetTicksUsSince(ticks_new_us);
		cumulative_time_slept_us += time_slept_us;

		// Update ticks.done with the total time spent sleeping
		if (cumulative_time_slept_us >= MicrosInMillisecond) {
			// 1 tick == 1 millisecond
			const auto cumulative_ticks_slept = cumulative_time_slept_us /
			                                    MicrosInMillisecond;
			ticks.done -= cumulative_ticks_slept;

			// Keep the fractional microseconds part
			cumulative_time_slept_us %= MicrosInMillisecond;
		}

		if (ticks.done < 0) {
			ticks.done = 0;
		}

		// If we do work this tick and sleep till the next tick, then
		// ticks.done is decreased, despite the fact that work was done
		// as well in this tick. Maybe make it depend on an extra
		// parameter. What do we know: ticks.remain = 0 (condition to
		// enter this function) ticks_new = time before sleeping

		// Maybe keep track of slept time in this frame, and use slept
		// and done as indicators, and take care of the fact there are
		// frames that have both.

		return;
	}

	// ticks_new > ticks.last
	ticks.remain = GetTicksDiff(ticks_new, ticks.last);
	ticks.last   = ticks_new;
	ticks.done += ticks.remain;

	if (ticks.remain > 20) {
#if 0
		LOG(LOG_MISC,LOG_ERROR)("large remain %d", ticks.remain);
#endif
		ticks.remain = 20;
	}

	ticks.added = ticks.remain;

	// Is the system in auto cycle guessing mode? If not, do nothing.
	if (!CPU_CycleAutoAdjust) {
		return;
	}

	if (ticks.scheduled >= 100 || ticks.done >= 100 ||
	    (ticks.added > 15 && ticks.scheduled >= 5)) {

		if (ticks.done < 1) {
			// Protect against division by zero.
			ticks.done = 1;
		}

		// Ratio we are aiming for is 100% usage
		auto ratio = (ticks.scheduled * (CPU_CyclePercUsed * 1024 / 100)) /
		             ticks.done;

		auto new_cycle_max = CPU_CycleMax;

		auto cproc = static_cast<int64_t>(CPU_CycleMax) *
		             static_cast<int64_t>(ticks.scheduled);

		// Increase scope for logging
		auto ratio_removed = 0.0;

		// TODO This is full of magic constants with zero explanation.
		// Where are they coming from, what do the signify, why these
		// numbers and not some other numbers, etc.--there's lots of
		// explaining to do here.

		if (cproc > 0) {
			// Ignore the cycles added due to the IO delay code in
			// order to have smoother auto cycle adjustments.
			ratio_removed = static_cast<double>(CPU_IODelayRemoved) /
			                static_cast<double>(cproc);

			if (ratio_removed < 1.0) {
				double ratio_not_removed = 1 - ratio_removed;
				ratio = ifloor(static_cast<double>(ratio) *
				               ratio_not_removed);

				// Don't allow very high ratios; they can cause
				// locking as we don't scale down for very low
				// ratios. High ratios might be the result of
				// timing resolution.
				if (ticks.scheduled >= 100 && ticks.done < 10 &&
				    ratio > 16384) {
					ratio = 16384;
				}

				// Limit the ratio even more when the cycles are
				// already way above the realmode default.
				if (ticks.scheduled >= 100 && ticks.done < 10 &&
				    ratio > 5120 && CPU_CycleMax > 50000) {
					ratio = 5120;
				}

				// When downscaling multiple times in a row,
				// ensure a minimum amount of downscaling
				if (ticks.added > 15 && ticks.scheduled >= 5 &&
				    ticks.scheduled <= 20 && ratio > 800) {
					ratio = 800;
				}

				if (ratio <= 1024) {
					// Uncommenting the below line restores
					// the old formula: ratio_not_removed
					// = 1.0;

					auto r = (1.0 + ratio_not_removed) /
					         (ratio_not_removed +
					          1024.0 / (static_cast<double>(ratio)));

					new_cycle_max = static_cast<int>(
					        CPU_CycleMax * r + 1);
				} else {
					auto ratio_with_removed = static_cast<int64_t>(
					        ((static_cast<double>(ratio) - 1024.0) *
					         ratio_not_removed) +
					        1024.0);

					auto cmax_scaled = check_cast<int64_t>(
					        CPU_CycleMax * ratio_with_removed);

					new_cycle_max = static_cast<int>(
					        1 + (CPU_CycleMax / 2) +
					        cmax_scaled / 2048LL);
				}
			}
		}

		if (new_cycle_max < auto_cpu_cycles_min) {
			new_cycle_max = auto_cpu_cycles_min;
		}

#if 0
		LOG_INFO("CPU: cycles: curr %7d | new %7d | ratio %5d | done %3d | sched %3d | add %3d | rem %4.2f",
		         CPU_CycleMax,
		         new_cycle_max,
		         ratio,
		         ticks.done,
		         ticks.scheduled,
		         ticks.added,
		         ratio_removed);
#endif

		// Ratios below 1% are considered to be dropouts due to
		// temporary load imbalance, the cycles adjusting is skipped.
		if (ratio > 10) {

			// Ratios below 12% along with a large time since the
			// last update has taken place are most likely caused by
			// heavy load through a different application, the
			// cycles adjusting is skipped as well.
			if ((ratio > 120) || (ticks.done < 700)) {
				CPU_CycleMax = new_cycle_max;

				if (CPU_CycleLimit > 0) {
					if (CPU_CycleMax > CPU_CycleLimit) {
						CPU_CycleMax = CPU_CycleLimit;
					}
				} else if (CPU_CycleMax > CpuCyclesMax) {
					// Hardcoded limit if the limit wasn't
					// explicitly specified.
					CPU_CycleMax = CpuCyclesMax;
				}
			}
		}

		// Reset cycle guessing parameters.
		CPU_IODelayRemoved = 0;
		ticks.done         = 0;
		ticks.scheduled    = 0;

	} else if (ticks.added > 15) {
		// ticks.added > 15 but ticks.scheduled < 5, lower the cycles
		// but do not reset the scheduled/done ticks to take them into
		// account during the next auto cycle adjustment.
		CPU_CycleMax /= 3;

		if (CPU_CycleMax < auto_cpu_cycles_min) {
			CPU_CycleMax = auto_cpu_cycles_min;
		}
	}
}

const char* DOSBOX_GetVersion() noexcept
{
	static constexpr char version[] = DOSBOX_VERSION;
	return version;
}

const char* DOSBOX_GetDetailedVersion() noexcept
{
	static constexpr char version[] = DOSBOX_VERSION " (" BUILD_GIT_HASH ")";
	return version;
}

void DOSBOX_SetLoop(LoopHandler* handler)
{
	loop = handler;
}

void DOSBOX_SetNormalLoop()
{
	loop = normal_loop;
}

static std::atomic<bool> is_shutdown_requested = false;

void DOSBOX_RunMachine()
{
	while ((*loop)() == 0 &&
	       !is_shutdown_requested.load(std::memory_order_relaxed)) {
	};
}

void DOSBOX_RequestShutdown()
{
	is_shutdown_requested.store(true, std::memory_order_relaxed);

	// Force-resume so `paused_tick()` exits and subsystem teardown happens
	// from a known-running state. Without this, teardown would block on
	// the mixer / synth threads that are parked in their pause hooks.
	// Covers pending states too so the fade-out timer doesn't fire into
	// a subsystem that's already tearing down.
	if (DOSBOX_IsPauseRequested()) {
		set_pause_state(PauseState::Running);
	}
}

bool DOSBOX_IsShutdownRequested()
{
	return is_shutdown_requested.load(std::memory_order_relaxed);
}

static void DOSBOX_UnlockSpeed(bool pressed)
{
	static bool autoadjust = false;

	// Fast-forward requires PIC + CPU to be running. It's the one feature
	// whose trigger is suppressed during pause; everything else (mapper,
	// screenshot, capture, fullscreen, window resize, shader auto-switch,
	// config reload) keeps working.
	if (pressed && !DOSBOX_IsRunning()) {
		LOG_MSG("Fast Forward is unavailable while paused");
		return;
	}

	if (pressed) {
		LOG_MSG("Fast Forward ON");
		ticks.locked = true;
		MIXER_EnableFastForwardMode();

		if (CPU_CycleAutoAdjust) {
			autoadjust          = true;
			CPU_CycleAutoAdjust = false;
			CPU_CycleMax /= 3;
			if (CPU_CycleMax < 1000) {
				CPU_CycleMax = 1000;
			}
		}
	} else {
		LOG_MSG("Fast Forward OFF");
		ticks.locked = false;
		MIXER_DisableFastForwardMode();

		if (autoadjust) {
			autoadjust          = false;
			CPU_CycleAutoAdjust = true;
		}
	}
}

void DOSBOX_SetMachineTypeFromConfig(SectionProp& section)
{
	const auto arguments = &control->arguments;
	if (!arguments->machine.empty()) {
		// update value in config (else no matching against suggested
		// values
		section.HandleInputLine(std::string("machine=") + arguments->machine);
	}

	const auto machine_str = section.GetString("machine");

	svga_type = SvgaType::None;
	machine   = MachineType::Vga;

	int10.vesa_nolfb  = false;
	int10.vesa_oldvbe = false;

	if (machine_str == "cga") {
		machine = MachineType::CgaColor;

	} else if (machine_str == "cga_mono") {
		machine = MachineType::CgaMono;

	} else if (machine_str == "tandy") {
		machine = MachineType::Tandy;

	} else if (machine_str == "pcjr") {
		machine = MachineType::Pcjr;

	} else if (machine_str == "hercules") {
		machine = MachineType::Hercules;

	} else if (machine_str == "ega") {
		machine = MachineType::Ega;

	} else if (machine_str == "svga_s3") {
		svga_type = SvgaType::S3;

	} else if (machine_str == "vesa_nolfb") {
		svga_type = SvgaType::S3;

		int10.vesa_nolfb = true;
	} else if (machine_str == "vesa_oldvbe") {

		svga_type         = SvgaType::S3;
		int10.vesa_oldvbe = true;

	} else if (machine_str == "svga_et3000") {
		svga_type = SvgaType::TsengEt3k;

	} else if (machine_str == "svga_et4000") {
		svga_type = SvgaType::TsengEt4k;

	} else if (machine_str == "svga_paradise") {
		svga_type = SvgaType::Paradise;

	} else {
		E_Exit("Invalid machine type '%s'", machine_str.c_str());
	}

	// VGA-type machine needs an valid SVGA card and vice-versa
	assert((machine == MachineType::Vga && svga_type != SvgaType::None) ||
	       (machine != MachineType::Vga && svga_type == SvgaType::None));
}

static constexpr auto WaitPidArg = "--wait_pid";
static constexpr auto LogNameArg = "--log_name";

static void remove_arg(std::vector<std::string>& parameters, const std::string arg_name)
{
	auto it = parameters.begin();

	while (it != parameters.end()) {
		if (*it != arg_name) {
			++it;
			continue;
		}

		it = parameters.erase(it);

		// Remove the value unless the next token looks like another option
		if (it != parameters.end() && (it->empty() || (*it)[0] != '-')) {
			it = parameters.erase(it);
		}
	}
}

// Quotes a single argument so that the Microsoft C runtime parses it back into
// exactly the same string.
//
// Windows passes the whole command line to CreateProcess() as one string, and
// it's up to the started program to split it into arguments. The rules for that
// are documented here:
//
// https://learn.microsoft.com/en-us/cpp/c-language/parsing-c-command-line-arguments
//
// The rules that matter here:
//
// - Arguments are separated by spaces or tabs, unless they're inside double
//   quotes.
//
// - Backslashes are literal, except when they immediately precede a double
//   quote. 2*N backslashes followed by a double quote produce N backslashes,
//   and the double quote acts as a delimiter. 2*N+1 backslashes followed by a
//   double quote produce N backslashes and a literal double quote.
//
// We always wrap the argument in double quotes, then:
//
// - Escape every double quote in the argument with a backslash, and double the
//   backslashes that precede it.
//
// - Double the backslashes at the end of the argument, so they don't escape
//   the closing quote.
//
// - Copy all other backslashes as they are.
//
// Examples (argument -> quoted argument):
//
//   a b       ->  "a b"
//   say "hi"  ->  "say \"hi\""
//   a\"b      ->  "a\\\"b"
//   C:\dir\   ->  "C:\dir\\"
//
std::string quote_windows_argument(const std::string_view arg)
{
	std::string quoted = "\"";

	auto num_backslashes = 0;

	for (const auto c : arg) {
		if (c == '\\') {
			++num_backslashes;
			continue;
		}

		// Backslashes are only special in front of a double quote
		if (c == '"') {
			quoted.append(num_backslashes * 2 + 1, '\\');
		} else {
			quoted.append(num_backslashes, '\\');
		}
		quoted.push_back(c);

		num_backslashes = 0;
	}

	// The closing quote must not be escaped by trailing backslashes
	quoted.append(num_backslashes * 2, '\\');
	quoted.push_back('"');

	return quoted;
}

void DOSBOX_Restart()
{
	LOG_INFO("DOSBOX: Restarting...");

	DOSBOX_Restart(control->startup_params);
}

void DOSBOX_Restart(std::vector<std::string>& parameters)
{
	control->ApplyQueuedValuesToCli(parameters);

	// Remove any existing `--wait_pid` and `--log_name` parameters.
	// This can happen with multiple restarts.
	remove_arg(parameters, WaitPidArg);
	remove_arg(parameters, LogNameArg);

	if (const auto maybe_log_name = LOG_GetLogFileName(); maybe_log_name) {
		parameters.emplace_back(LogNameArg);
		parameters.emplace_back(*maybe_log_name);
	}

#ifdef WIN32
	parameters.emplace_back(WaitPidArg);
	parameters.emplace_back(std::to_string(GetCurrentProcessId()));

	std::string command_line = {};

	bool first = true;

	for (const auto& arg : parameters) {
		if (!first) {
			command_line.push_back(' ');
		}

		// On Linux and macOS, command line arguments are passed as an
		// array of strings to execvp() and can contain spaces. On
		// Windows, the entire command line is passed to CreateProcess()
		// as a single string, therefore we need to enclose the
		// arguments in double quotes, otherwise things will break if
		// one or more arguments contain spaces.
		//
		command_line.append(quote_windows_argument(arg));
		first = false;
	}
#else  // macOS & Linux
	parameters.emplace_back(WaitPidArg);
	parameters.emplace_back(std::to_string(getpid()));

	auto newargs = new char*[parameters.size() + 1];

	// parameter 0 is the executable path
	// contents of the vector follow
	// last one is NULL
	for (size_t i = 0; i < parameters.size(); i++) {
		newargs[i] = parameters[i].data();
	}
	newargs[parameters.size()] = nullptr;
#endif // WIN32

	GFX_RequestExit(true);

#if C_DEBUGGER
	// shutdown curses
	DEBUG_Destroy();
#endif

#ifdef WIN32
	// nullptr to parse from command line
	const LPCSTR application_name = nullptr;

	// nullptr for default
	const LPSECURITY_ATTRIBUTES process_attributes = nullptr;

	// nullptr for default
	const LPSECURITY_ATTRIBUTES thread_attributes = nullptr;

	const BOOL inherit_handles = FALSE;

	// CREATE_NEW_CONSOLE fixes a bug where the parent process exiting kills
	// the child process. This can manifest when you use the "restart"
	// hotkey action to restart DOSBox.
	// https://github.com/dosbox-staging/dosbox-staging/issues/3346
	const DWORD creation_flags = CREATE_NEW_CONSOLE;

	// nullptr to use parent's environment
	const LPVOID environment_variables = nullptr;

	// nullptr to use parent's current directory
	const LPCSTR current_directory = nullptr;

	// Input structure with a bunch of stuff we probably don't care about.
	// Zero it out to use defaults save for the size field.
	STARTUPINFO startup_info = {};
	startup_info.cb          = sizeof(startup_info);

	// Output structure we also don't care about.
	PROCESS_INFORMATION process_information = {};

	if (!CreateProcess(application_name,
	                   const_cast<char*>(command_line.c_str()),
	                   process_attributes,
	                   thread_attributes,
	                   inherit_handles,
	                   creation_flags,
	                   environment_variables,
	                   current_directory,
	                   &startup_info,
	                   &process_information)) {
		LOG_ERR("Restart failed: CreateProcess failed");
	}
#else  // macOS & Linux
	int ret = fork();
	switch (ret) {
	case -1:
		LOG_ERR("Restart failed: fork failed: %s", strerror(errno));
		break;
	case 0:
		// Newly created child process immediately executes a new
		// instance of DOSBox. It is not safe for a child process in a
		// multi-threaded program to do much else.
		if (execvp(newargs[0], newargs) == -1) {
			E_Exit("Restart failed: execvp failed: %s", strerror(errno));
		}
		break;
	}
	// Original (parent) process continues execution here.
	// It will proceed to do a normal shutdown due to
	// gfx_request_exit(true); above.
	delete[] newargs;
#endif // WIN32
}

static std::optional<VesaCustomResolution> parse_vesa_custom_resolution(
        const std::string& pref)
{
	if (pref.empty() || has_false(pref)) {
		return {};
	}

	constexpr auto MinWidth  = 320;
	constexpr auto MinHeight = 200;
	constexpr auto MaxWidth  = 1920;
	constexpr auto MaxHeight = 1440;

	if (const auto dimensions = parse_int_dimensions(pref)) {
		const auto [width, height] = *dimensions;

		const auto is_out_of_bounds = (width < MinWidth || width > MaxWidth ||
		                               height < MinHeight ||
		                               height > MaxHeight);

		const auto is_valid_width = ((width % 8) == 0);

		if (!is_out_of_bounds && is_valid_width) {
			return VesaCustomResolution{width, height};
		}
	}

	LOG_WARNING(
	        "VIDEO: Invalid 'vesa_custom_resolution' setting: '%s'; "
	        "must be from %dx%d to %dx%d with the width a multiple of 8, "
	        "using 'none'",
	        pref.c_str(),
	        MinWidth,
	        MinHeight,
	        MaxWidth,
	        MaxHeight);
	return {};
}

static void dosbox_realinit(SectionProp& section)
{
	// Initialize some dosbox internals
	ticks.remain = 0;
	ticks.last   = GetTicks();
	ticks.locked = false;

	DOSBOX_SetNormalLoop();

	MAPPER_AddHandler(DOSBOX_UnlockSpeed, SDL_SCANCODE_F12, MMOD2, "speedlock", "Speedlock");

	DOSBOX_SetMachineTypeFromConfig(section);

	// Set the user's prefered MCB fault handling strategy
	DOS_SetMcbFaultStrategy(section.GetString("mcb_fault_strategy").c_str());

	// Convert the users video memory in either MB or KB to bytes
	const std::string vmemsize_string = section.GetString("vmemsize");

	// If auto, then default to 0 and let the adapter's setup rountine set
	// the size
	auto vmemsize = vmemsize_string == "auto" ? 0 : std::stoi(vmemsize_string);

	// Scale up from MB-to-bytes or from KB-to-bytes
	vmemsize *= (vmemsize <= 8) ? 1024 * 1024 : 1024;
	vga.vmemsize = check_cast<uint32_t>(vmemsize);

	const std::string pref = section.GetString("vesa_modes");
	if (pref == "compatible") {
		int10.vesa_modes = VesaModes::Compatible;
	} else if (pref == "halfline") {
		int10.vesa_modes = VesaModes::Halfline;
	} else {
		int10.vesa_modes = VesaModes::All;
	}

	int10.vesa_custom_resolution = parse_vesa_custom_resolution(
	        section.GetString("vesa_custom_resolution"));

	VGA_SetRefreshRateMode(section.GetString("dos_rate"));

	// Set the disk IO data rate
	const auto hdd_io_speed = section.GetString("hard_disk_speed");
	if (hdd_io_speed == "fast") {
		DOS_SetDiskSpeed(DiskSpeed::Fast, DiskType::HardDisk);
	} else if (hdd_io_speed == "medium") {
		DOS_SetDiskSpeed(DiskSpeed::Medium, DiskType::HardDisk);
	} else if (hdd_io_speed == "slow") {
		DOS_SetDiskSpeed(DiskSpeed::Slow, DiskType::HardDisk);
	} else {
		DOS_SetDiskSpeed(DiskSpeed::Maximum, DiskType::HardDisk);
	}

	// Set the floppy disk IO data rate
	const auto floppy_io_speed = section.GetString("floppy_disk_speed");
	if (floppy_io_speed == "fast") {
		DOS_SetDiskSpeed(DiskSpeed::Fast, DiskType::Floppy);
	} else if (floppy_io_speed == "medium") {
		DOS_SetDiskSpeed(DiskSpeed::Medium, DiskType::Floppy);
	} else if (floppy_io_speed == "slow") {
		DOS_SetDiskSpeed(DiskSpeed::Slow, DiskType::Floppy);
	} else {
		DOS_SetDiskSpeed(DiskSpeed::Maximum, DiskType::Floppy);
	}
}

void DOSBOX_Init()
{
	auto section = get_section("dosbox");
	assert(section);

	dosbox_realinit(*section);

	MSG_LoadMessages();

	IO_Init();
	PAGING_Init();
	MEM_Init(section);
	CALLBACK_Init();
	PIC_Init();
	PROGRAMS_Init();
	TIMER_Init();
	CMOS_Init();

	// Register the PIC-tick handler that completes pending pauses once
	// the fade-out has reached zero. See `pending_pause_tick_handler`.
	TIMER_AddTickHandler(pending_pause_tick_handler);
}

void DOSBOX_Destroy()
{
	CMOS_Destroy();
	TIMER_Destroy();
	PROGRAMS_Destroy();
	PIC_Destroy();
	MEM_Destroy();
	IO_Destroy();
}

static void notify_dosbox_setting_updated(const SectionProp& section,
                                          const std::string prop_name)
{
	if (prop_name == "language") {
		MSG_LoadMessages();

	} else if (prop_name == "dos_rate") {
		VGA_SetRefreshRateMode(section.GetString("dos_rate"));

	} else if (prop_name == "shell_config_shortcuts") {
		// No need to re-init anything; the setting is always queried
		// when executing a command.
	}
}

static void add_dosbox_config_section(const ConfigPtr& conf)
{
	assert(conf);

	using enum Property::Changeable::Value;

	auto section = conf->AddSection("dosbox");
	section->AddUpdateHandler(notify_dosbox_setting_updated);

	auto pstring = section->AddString("language", Always, "en");

	pstring->SetHelp(
	        "Set the DOS messages language ('en' by default). Possible values are 'de', 'en',\n"
	        "'es', 'fr', 'it', 'nl', 'pl', 'pt_BR' and 'ru'.\n"
	        "\n"
	        "Note: English is built-in; the rest is stored in the bundled\n"
	        "      'resources/translations' directory.");

	pstring = section->AddString("log_mode", Never, "console-and-file");
	pstring->SetValues({"console", "file", "console-and-file", "off"});
	pstring->SetHelp(
	        "Set the logging mode ('console-and-file' by default). Possible values:\n"
	        "\n"
	        "  off:               Disable all logging.\n"
	        "\n"
	        "  console:           Print log messages to the console.\n"
	        "\n"
	        "  file:              Write log messages to a file in the 'log_dir' directory,\n"
	        "                     named 'dosbox-YYYYMMDD-HHMMSS.log' after the date and time\n"
	        "                     the file was created. Logs from the most recent ten runs\n"
	        "                     are kept.\n"
	        "\n"
	        "  console-and-file:  Print log messages to the console and also write a log file\n"
	        "                     (default).");

	pstring = section->AddString("log_dir", Never, "");
	pstring->SetHelp(
	        "Log file directory (unset by default). If unset, the logs are written to the\n"
	        "'logs' folder in the configuration directory.");

	pstring = section->AddString("machine", OnlyAtStart, "svga_s3");
	pstring->SetValues({"hercules",
	                    "cga_mono",
	                    "cga",
	                    "pcjr",
	                    "tandy",
	                    "ega",
	                    "svga_s3",
	                    "svga_et3000",
	                    "svga_et4000",
	                    "svga_paradise",
	                    "vesa_nolfb",
	                    "vesa_oldvbe"});

	pstring->SetDeprecatedWithAlternateValue("vgaonly", "svga_paradise");
	pstring->SetHelp(
	        "Set the video adapter or machine to emulate ('svga_s3' by default).\n"
	        "Possible values:\n"
	        "\n"
	        "  hercules:       Hercules Graphics Card (HGC) (see 'monochrome_palette').\n"
	        "\n"
	        "  cga_mono:       CGA adapter connected to a monochrome monitor (see\n"
	        "                  'monochrome_palette').\n"
	        "\n"
	        "  cga:            IBM Color Graphics Adapter (CGA). Also enables composite\n"
	        "                  video emulation (see [composite] section).\n"
	        "\n"
	        "  pcjr:           An IBM PCjr machine. Also enables PCjr sound and composite\n"
	        "                  video emulation (see [composite] section).\n"
	        "\n"
	        "  tandy:          A Tandy 1000 machine with TGA graphics. Also enables Tandy\n"
	        "                  sound and composite video emulation (see [composite]\n"
	        "                  section).\n"
	        "\n"
	        "  ega:            IBM Enhanced Graphics Adapter (EGA).\n"
	        "\n"
	        "  svga_paradise:  Paradise PVGA1A SVGA card (no VESA VBE; 512K vmem by default,\n"
	        "                  can be set to 256K or 1MB with 'vmemsize'). This is the\n"
	        "                  closest to IBM's original VGA adapter.\n"
	        "\n"
	        "  svga_et3000:    Tseng Labs ET3000 SVGA card (no VESA VBE; fixed 512K vmem).\n"
	        "\n"
	        "  svga_et4000:    Tseng Labs ET4000 SVGA card (no VESA VBE; 1MB vmem by\n"
	        "                  default, can be set to 256K or 512K with 'vmemsize').\n"
	        "\n"
	        "  svga_s3:        S3 Trio64 (VESA VBE 2.0; 4MB vmem by default, can be set to\n"
	        "                  512K, 1MB, 2MB, or 8MB with 'vmemsize') (default)\n"
	        "\n"
	        "  vesa_oldvbe:    Same as 'svga_s3' but limited to VESA VBE 1.2.\n"
	        "\n"
	        "  vesa_nolfb:     Same as 'svga_s3' (VESA VBE 2.0), plus the \"no linear\n"
	        "                  framebuffer\" hack (needed only by a few games).");

	pstring = section->AddPath("captures", Deprecated, "capture");
	pstring->SetHelp(
	        "Moved to [color=light-cyan][capture][reset] section and "
	        "renamed to [color=light-green]'capture_dir'[reset].");

	auto pint = section->AddInt("memsize", OnlyAtStart, 16);
	pint->SetMinMax(MEM_GetMinMegabytes(), MEM_GetMaxMegabytes());
	pint->SetHelp(
	        "Amount of memory of the emulated machine has in MB (16 by default). Best leave\n"
	        "at the default setting to avoid problems with some games, though a few games\n"
	        "might require a higher value. There is generally no speed advantage when raising\n"
	        "this value.");

	pstring = section->AddString("mcb_fault_strategy", OnlyAtStart, "repair");
	pstring->SetHelp(
	        "How software-corrupted memory chain blocks should be handled ('repair' by\n"
	        "default). Possible values:\n"
	        "\n"
	        "  repair:  Repair (and report) faults using adjacent blocks (default).\n"
	        "  report:  Report faults but otherwise proceed as-is.\n"
	        "  allow:   Allow faults to go unreported (hardware behavior).\n"
	        "  deny:    Quit (and report) when faults are detected.");

	pstring->SetValues({"repair", "report", "allow", "deny"});

	static_assert(8192 * 1024 <= PciGfxLfbLimit - PciGfxLfbBase);
	pstring = section->AddString("vmemsize", OnlyAtStart, "auto");

	pstring->SetValues({"auto",
	                    // values in MB
	                    "1",
	                    "2",
	                    "4",
	                    "8",
	                    // values in KB
	                    "256",
	                    "512",
	                    "1024",
	                    "2048",
	                    "4096",
	                    "8192"});
	pstring->SetHelp(
	        "Video memory in MB (1-8) or KB (256 to 8192). 'auto' uses the default for\n"
	        "the selected video adapter ('auto' by default). See the 'machine' setting for\n"
	        "the list of valid options and defaults per adapter.");

	pstring = section->AddString("vmem_delay", OnlyAtStart, "off");
	pstring->SetHelp(
	        "Set video memory access delay emulation ('off' by default). Possible values:\n"
	        "\n"
	        "  off:       Disable video memory access delay emulation (default).\n"
	        "             This is preferable for most games to avoid slowdowns.\n"
	        "\n"
	        "  on:        Enable video memory access delay emulation (3000 ns).\n"
	        "             This can help reduce or eliminate flicker in Hercules,\n"
	        "             CGA, EGA, and early VGA games.\n"
	        "\n"
	        "  <number>:  Set access delay in nanoseconds. Valid range is 0 to 20000 ns;\n"
	        "             500 to 5000 ns is the most useful range.\n"
	        "\n"
	        "Note: Only set this on a per-game basis when necessary as it slows down\n"
	        "      the whole emulator.");

	pstring = section->AddString("dos_rate", WhenIdle, "default");
	pstring->SetHelp(format_str(
	        "Override the emulated DOS video mode's refresh rate with a custom rate\n"
	        "('default' by default). Possible values:\n"
	        "\n"
	        "  default:   Don't override; use the emulated DOS video mode's refresh rate\n"
	        "             (default).\n"
	        "\n"
	        "  host:      Override the refresh rate of all DOS video modes with the refresh\n"
	        "             rate of your monitor. This might allow you to play some 70 Hz VGA\n"
	        "             games with perfect vsync on a 60 Hz fixed refresh rate monitor (see\n"
	        "             'vsync' for further details).\n"
	        "\n"
	        "  <number>:  Override the refresh rate of all DOS video modes with a fixed rate\n"
	        "             specified in Hz (valid range is from %d.000 to %d.000). This is a\n"
	        "             niche option for a select few fast-paced mid to late 1990s 3D games\n"
	        "             for high refresh rate gaming.\n"
	        "\n"
	        "Note: Many games will misbehave when overriding the DOS video mode's refresh\n"
	        "      rate with non-standard values. This can manifest in glitchy video,\n"
	        "      sped-up or slowed-down audio, jerky mouse movement, mouse button presses\n"
	        "      not being registered, and even gameplay bugs. Overriding the DOS refresh\n"
	        "      rate is a hack that only works acceptably with a small subset of all DOS\n"
	        "      games (typically mid to late 1990s games).",
	        RefreshRateMin,
	        RefreshRateMax));

	pstring = section->AddString("vesa_modes", OnlyAtStart, "compatible");
	pstring->SetValues({"compatible", "all", "halfline"});
	pstring->SetHelp(
	        "Controls which VESA video modes are available ('compatible' by default).\n"
	        "Possible values:\n"
	        "\n"
	        "  compatible:  Only the most compatible VESA modes for the configured video\n"
	        "               memory size (default). Recommended with 4 or 8 MB of video\n"
	        "               memory ('vmemsize') for the widest compatiblity with games.\n"
	        "               320x200 high colour modes are excluded as they were not\n"
	        "               properly supported until the late '90s. The 256-colour linear\n"
	        "               framebuffer 320x240, 400x300, and 512x384 modes are also\n"
	        "               excluded as they cause timing problems in Build Engine games.\n"
	        "\n"
	        "  halfline:    Same as 'compatible', but the 120h VESA mode is replaced with\n"
	        "               a special halfline mode used by Extreme Assault. Use only if\n"
	        "               needed.\n"
	        "\n"
	        "  all:         All modes are available, including extra DOSBox-specific VESA\n"
	        "               modes. Use 8 MB of video memory for the best results. Some\n"
	        "               games misbehave in the presence of certain VESA modes; try\n"
	        "               'compatible' mode if this happens. The 320x200 high colour\n"
	        "               modes available in this mode are often required by late '90s\n"
	        "               demoscene productions.");

	pstring = section->AddString("vesa_custom_resolution", OnlyAtStart, "none");
	pstring->SetHelp(
	        "Replace the 1152x864 VESA resolution with a custom one ('none' by default).\n"
	        "Useful for playing games in widescreen that support custom VESA resolutions\n"
	        "(e.g., Quake and Build Engine games such as Duke Nukem 3D and Blood), or for\n"
	        "running Windows 3.1 in widescreen with the VBESVGA driver. Custom resolutions\n"
	        "always use square pixels. Possible values:\n"
	        "\n"
	        "  none:  Don't replace the 1152x864 VESA resolution.\n"
	        "\n"
	        "  WxH:   Replacement resolution in WxH format (e.g., 1920x1080, 960x540,\n"
	        "         480x270). Valid range is 320x200 to 1920x1440; width must be a multiple\n"
	        "         of 8. Colour depth variants that don't fit into the video memory are\n"
	        "         skipped with a warning in the logs; increase 'vmemsize' to fit them\n"
	        "         (e.g., 1920x1080 32-bit needs 8 MB).\n"
	        "\n"
	        "Note: The feature only works with the `svga_s3` machine type; any other `svga_*`\n"
	        "      and `vesa_*` machine types are not supported.");

	auto pbool = section->AddBool("vga_8dot_font", OnlyAtStart, false);
	pbool->SetHelp("Use 8-pixel-wide fonts on VGA adapters ('off' by default).");

	pstring = section->AddString("vga_render_per_scanline", Deprecated, "");
	pstring->SetHelp(
	        "The [color=light-green]'vga_render_per_scanline'[reset] setting has been removed;\n"
	        "it's no longer necessary.");

	pstring = section->AddString("autoexec_section", OnlyAtStart, "join");
	pstring->SetValues({"join", "overwrite"});
	pstring->SetHelp(
	        "How autoexec sections are handled from multiple config files ('join' by\n"
	        "default). Possible values:\n"
	        "\n"
	        "  join:       Combine them into one big section (default).\n"
	        "  overwrite:  Use the last one encountered, like other config settings.");

	pbool = section->AddBool("automount", OnlyAtStart, true);
	pbool->SetHelp(
	        "Mount 'drives/[c]' directories as drives on startup, where [c] is a lower-case\n"
	        "drive letter from 'a' to 'y' ('on' by default). The 'drives' folder can be\n"
	        "provided relative to the current directory or via built-in resources.\n"
	        "Mount settings can be optionally provided using a [c].conf file along-side\n"
	        "the drive's directory, with content as follows:\n"
	        "\n"
	        "  [drive]\n"
	        "  type     = dir, overlay, floppy, cdrom or iso (same as cdrom)\n"
	        "  label    = custom_label\n"
	        "  path     = path-specification (e.g., path = %%path%%;c:\\tools)\n"
	        "  override_drive = mount the directory to this drive instead (default empty)\n"
	        "  verbose  = on or off\n"
	        "  readonly = on or off");

	pstring = section->AddString("startup_verbosity", OnlyAtStart, "auto");
	pstring->SetValues({"auto", "high", "low", "quiet"});
	pstring->SetHelp(
	        "Controls verbosity prior to displaying the program ('auto' by default):\n"
	        "\n"
	        "  Verbosity   | Welcome | Early stdout\n"
	        "  high        |   yes   |    yes\n"
	        "  low         |   no    |    yes\n"
	        "  quiet       |   no    |    no\n"
	        "  auto        | 'low' if exec or dir is passed, otherwise 'high'");

	pbool = section->AddBool("allow_write_protected_files", OnlyAtStart, true);
	pbool->SetHelp(
	        "Many games open all their files with writable permissions; even files that they\n"
	        "never modify. This setting lets you write-protect those files while still\n"
	        "allowing the game to read them ('on' by default). A second use-case: if you're\n"
	        "using a copy-on-write or network-based filesystem, this setting avoids\n"
	        "triggering write operations for these write-protected files.");

	pbool = section->AddBool("shell_config_shortcuts", WhenIdle, true);
	pbool->SetHelp(
	        "Allow shortcuts for simpler configuration management ('on' by default).\n"
	        "E.g., instead of 'config -set sbtype sb16', it is enough to execute\n"
	        "'sbtype sb16', and instead of 'config -get sbtype', you can just execute\n"
	        "the 'sbtype' command.");

	pstring = section->AddString("hard_disk_speed", OnlyAtStart, "maximum");
	pstring->SetValues({"maximum", "fast", "medium", "slow"});
	pstring->SetHelp(
	        "Set the emulated hard disk speed ('maximum' by default). Possible values:\n"
	        "\n"
	        "  maximum:  As fast as possible, no slowdown (default)\n"
	        "  fast:     Typical mid-1990s hard disk speed (~15 MB/s)\n"
	        "  medium:   Typical early 1990s hard disk speed (~2.5 MB/s)\n"
	        "  slow:     Typical 1980s hard disk speed (~600 kB/s)");

	pstring = section->AddString("floppy_disk_speed", OnlyAtStart, "maximum");
	pstring->SetValues({"maximum", "fast", "medium", "slow"});
	pstring->SetHelp(
	        "Set the emulated floppy disk speed ('maximum' by default). Possible values:\n"
	        "\n"
	        "  maximum:  As fast as possible, no slowdown (default)\n"
	        "  fast:     Extra-high density (ED) floppy speed (~120 kB/s)\n"
	        "  medium:   High density (HD) floppy speed (~60 kB/s)\n"
	        "  slow:     Double density (DD) floppy speed (~30 kB/s)");
}

void DOSBOX_InitModuleConfigsAndMessages()
{
	// The [sdl] section gets initialised first in `sdl_gui.cpp`, then
	// this init method gets called.

	add_dosbox_config_section(control);

	RENDER_AddConfigSection(control);
	COMPOSITE_AddConfigSection(*control);
	CPU_AddConfigSection(control);
	VOODOO_AddConfigSection(control);
	CAPTURE_AddConfigSection(control);
	MOUSE_AddConfigSection(control);
	MIXER_AddConfigSection(control);

#if C_MT32EMU
	MT32_AddConfigSection(control);
#endif
	FSYNTH_AddConfigSection(control);
	SOUNDCANVAS_AddConfigSection(control);
	CLAP_AddConfigSection(control);

	// The MIDI section must be added *after* all internal MIDI device
	// sections. Initialising MIDI first would initialise the selected device
	// twice at startup time (e.g., with 'mididevice = mt32').
	MIDI_AddConfigSection(control);

#if C_DEBUGGER
	DEBUG_AddConfigSection(control);
#endif

	SBLASTER_AddConfigSection(control);
	OPL_AddConfigSettings();
	GUS_AddConfigSection(control);
	IMFC_AddConfigSection(control);
	INNOVATION_AddConfigSection(control);
	SPEAKER_AddConfigSection(control);

	DISKNOISE_AddConfigSection(control);
	REELMAGIC_AddConfigSection(control);
	JOYSTICK_AddConfigSection(control);
	SERIAL_AddConfigSection(control);
	DOS_AddConfigSection(control);
	IPX_AddConfigSection(control);

	ETHERNET_AddConfigSection(control);
	WEBSERVER_AddConfigSection(control);

	control->AddAutoexecSection();

	MSG_Add("AUTOEXEC_CONFIGFILE_HELP",
	        "Each line in this section is executed at startup as a DOS command.\n"
	        "Important: The [autoexec] section must be the last section in the config!\n");

	MSG_Add("CONFIGFILE_INTRO",
	        "# This is the configuration file for " DOSBOX_NAME
	        " (%s).\n"
	        "# Lines starting with a '#' character are comments.\n");

	// Needs to be initialised early before the config settings get applied
	PROGRAMS_AddMessages();
}

void DOSBOX_InitModules()
{
	DOSBOX_Init();

#if C_DEBUGGER
	DEBUG_StartUpLogging();
	DEBUG_InitLogging();
#endif

	COMPOSITE_Init();

	CPU_Init();
	FPU_Init();
	DMA_Init();
	VGA_Init();
	KEYBOARD_Init();
	PCI_Init();

	VOODOO_Init();
	CAPTURE_Init();

	MIXER_Init();
	MIDI_Init();

#if C_DEBUGGER
	DEBUG_Init();
#endif

	SBLASTER_Init();
	GUS_Init();
	IMFC_Init();
	INNOVATION_Init();
	SPEAKER_Init();

	REELMAGIC_Init();

	BIOS_Init();
	INT10_Init();
	MOUSE_Init();
	JOYSTICK_Init();

	DISKNOISE_Init();
	SERIAL_Init();
	DOS_Init();

	IPX_Init();
	ETHERNET_Init();
	VIRTUALBOX_Init();
	VMWARE_Init();
	WEBSERVER_Init();

	AUTOEXEC_Init();
}

void DOSBOX_DestroyModules()
{
	WEBSERVER_Destroy();
	VMWARE_Destroy();
	VIRTUALBOX_Destroy();
	ETHERNET_Destroy();
	IPX_Destroy();

	DOS_Destroy();
	SERIAL_Destroy();
	DISKNOISE_Destroy();

	JOYSTICK_Destroy();
	BIOS_Destroy();

	REELMAGIC_Destroy();

	SPEAKER_Destroy();
	INNOVATION_Destroy();
	IMFC_Destroy();
	GUS_Destroy();
	SBLASTER_Destroy();

#if C_DEBUGGER
	DEBUG_Destroy();
#endif
	MIDI_Destroy();
	MIXER_Destroy();

	CAPTURE_Destroy();
	VOODOO_Destroy();

	PCI_Destroy();
	VGA_Destroy();
	DMA_Destroy();
	CPU_Destroy();

#if C_DEBUGGER
	DEBUG_DestroyLogging();
#endif

	DOSBOX_Destroy();

	control = {};
}
