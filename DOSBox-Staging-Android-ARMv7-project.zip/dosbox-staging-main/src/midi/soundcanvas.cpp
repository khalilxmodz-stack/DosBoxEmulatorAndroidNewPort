// SPDX-FileCopyrightTextound  2024-2026 The DOSBox Staging Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "private/soundcanvas.h"

#include <optional>
#include <set>
#include <vector>

#include "audio/channel_names.h"
#include "audio/clap/library.h"
#include "audio/clap/plugin_manager.h"
#include "config/setup.h"
#include "dos/programs.h"
#include "misc/ansi_code_markup.h"
#include "misc/std_filesystem.h"
#include "utils/checks.h"
#include "utils/env_utils.h"
#include "utils/string_utils.h"

CHECK_NARROWING();

namespace SoundCanvas {

// Symbolic model aliases
namespace BestModelAlias {
constexpr auto Sc55    = "sc55";
constexpr auto Sc55mk2 = "sc55mk2";
} // namespace BestModelAlias

const SynthModel sc55_100_model = {Model::Sc55_100, "sc55_100", "100", "Roland SC-55 v1.00"};

const SynthModel sc55_110_model = {Model::Sc55_110, "sc55_110", "110", "Roland SC-55 v1.10"};

const SynthModel sc55_120_model = {Model::Sc55_120, "sc55_120", "120", "Roland SC-55 v1.20"};

const SynthModel sc55_121_model = {Model::Sc55_121, "sc55_121", "121", "Roland SC-55 v1.21"};

const SynthModel sc55_200_model = {Model::Sc55_200, "sc55_200", "200", "Roland SC-55 v2.00"};

const SynthModel sc55mk2_100 = {Model::Sc55mk2_100,
                                "sc55mk2_100",
                                "mk2_100",
                                "Roland SC-55mk2 v1.00"};

const SynthModel sc55mk2_101 = {Model::Sc55mk2_101,
                                "sc55mk2_101",
                                "mk2_101",
                                "Roland SC-55mk2 v1.01"};

// Listed in resolution priority order
const std::vector<const SynthModel*> all_models = {&sc55_121_model,
                                                   &sc55_120_model,
                                                   &sc55_110_model,
                                                   &sc55_100_model,
                                                   &sc55_200_model,
                                                   &sc55mk2_101,
                                                   &sc55mk2_100};

// Listed in resolution priority order
const std::vector<const SynthModel*> sc55_models = {&sc55_121_model,
                                                    &sc55_120_model,
                                                    &sc55_110_model,
                                                    &sc55_100_model,
                                                    &sc55_200_model};

// Listed in resolution priority order
const std::vector<const SynthModel*> sc55mk2_models = {&sc55mk2_101, &sc55mk2_100};

struct PluginAndModel {
	std::unique_ptr<Clap::Plugin> plugin = nullptr;
	SynthModel model                     = {};
};

} // namespace SoundCanvas

SoundCanvas::PluginAndModel try_load_plugin(const SoundCanvas::SynthModel& model)
{
	auto& plugin_manager       = Clap::PluginManager::GetInstance();

	if (auto p = plugin_manager.FindPluginInLibrary("Nuked-SC55.clap",
	                                                model.display_name_long);
	    p) {
		const auto plugin_info = *p;
		
		auto plugin = plugin_manager.LoadPlugin(plugin_info);
		if (plugin) {
			return {std::move(plugin), model};
		}
	}
	// Requested model not found
	return {};
}

SoundCanvas::PluginAndModel load_model(const std::string& wanted_model_name)
{
	using namespace SoundCanvas;

	// Determine the list of model candidates and the lookup method:
	//
	// - Symbolic model names ('auto', 'sc55', 'sc55mk2') resolve the first
	//   available model from the list of candidates. The lookup only fails
	//   if none of the candidate models are available.
	//
	// - Concrete versioned model names always try to resolve the requested
	//   version or fail if it's not available.
	//
	auto [load_first_available, candidate_models] =
	        [&]() -> std::pair<bool, std::vector<const SoundCanvas::SynthModel*>> {
		// Symbolic mode names (resolve the best match from a list of
		// candidates in priority order).
		if (wanted_model_name == "auto") {
			return {true, all_models};
		}
		if (wanted_model_name == BestModelAlias::Sc55) {
			return {true, sc55_models};
		}
		if (wanted_model_name == BestModelAlias::Sc55mk2) {
			return {true, sc55mk2_models};
		}

		// Concrete versioned model name (resolve the specific requested
		// model or fail).
		return {false, all_models};
	}();

	// Perform model lookup from the list of candidate models
	for (const auto& model : candidate_models) {
		if (load_first_available || wanted_model_name == model->config_name) {
			if (auto p = try_load_plugin(*model); p.plugin) {
				return p;
			}
		}
	}

	// Couldn't load
	return {};
}

static float native_sample_rate_hz_for_model(const SoundCanvas::Model model)
{
	using namespace SoundCanvas;

	switch (model) {
	// Roland SC-55
	case Model::Sc55_100:
	case Model::Sc55_110:
	case Model::Sc55_120:
	case Model::Sc55_121:
	case Model::Sc55_200: return 32000.0;

	// Roland SC-55mk2
	case Model::Sc55mk2_100:
	case Model::Sc55mk2_101: return 33103.0;

	default: assertm(false, "Invalid SoundCanvas::Model"); return 0.0;
	}
}

SoundCanvas::SynthModel MidiDeviceSoundCanvas::GetModel() const
{
	return model;
}

static SectionProp* get_soundcanvas_section()
{
	return get_section("soundcanvas");
}

static std::string get_model_setting()
{
	return get_soundcanvas_section()->GetString("soundcanvas_model");
}

static void setup_filter(MixerChannelPtr& channel, const bool filter_enabled)
{
	if (filter_enabled) {
		channel->SetHighPassFilter(FilterState::Off);

		// All Roland SC-55 models seem to very gently soften the
		// high-frequency response of the output which makes samples
		// with lots of treble content a bit softer and consequently
		// quieter in the mix (e.g., hi-hats, cymbals, harpsichord, some
		// synth sounds, etc.)
		//
		// On most materials, the filter makes little difference, but in
		// certain soundtracks the unfiltered high-frequency content can
		// get annoying for those with sensitive ears listening in
		// quality headphones.
		//
		// The filter response has been confirmed on different SC-55
		// models (original, SC-55mk2, SC-55st, SC-55K) and recordings
		// made by different individuals. This indicates this was
		// either a deliberate design choice by Roland, or they just
		// happened to use similar analog output stages in the entire
		// SC-55 product line. This also means composers must have
		// compensated for the softened treble resopnse, which can make
		// the unfiltered output a little bit too harsh.
		//
		constexpr auto LpfOrder        = 1;
		constexpr auto LpfCutoffFreqHz = 11000;

		channel->ConfigureLowPassFilter(LpfOrder, LpfCutoffFreqHz);
		channel->SetLowPassFilter(FilterState::On);

	} else {
		channel->SetHighPassFilter(FilterState::Off);
		channel->SetLowPassFilter(FilterState::Off);
	}
}

#if defined(WIN32)

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	return {
	        get_config_dir() / DefaultSoundCanvasRomsDir,
	};
}

#elif defined(MACOSX)

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	return {
	        get_config_dir() / DefaultSoundCanvasRomsDir,
	};
}
#else

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	// First priority is user-specific data location
	const auto xdg_data_home = get_xdg_data_home();

	std::deque<std_fs::path> dirs = {
	        xdg_data_home / "dosbox" / DefaultSoundCanvasRomsDir,
	        xdg_data_home / "soundcanvas-rom-data",
	};

	// Second priority are the $XDG_DATA_DIRS
	for (const auto& data_dir : get_xdg_data_dirs()) {
		dirs.emplace_back(data_dir / "soundcanvas-rom-data");
	}

	// Third priority is $XDG_CONF_HOME, for convenience
	dirs.emplace_back(get_config_dir() / DefaultSoundCanvasRomsDir);

	return dirs;
}

#endif

static std::deque<std_fs::path> get_rom_dirs()
{
	// Get potential ROM directories from the environment and/or system
	auto rom_dirs = get_platform_rom_dirs();

	// Get the user's configured ROM directory; otherwise use
	// 'soundcanvas-roms'
	std_fs::path selected_romdir = get_soundcanvas_section()->GetString(
	        "soundcanvas_rom_dir");

	if (selected_romdir.empty()) { // already trimmed
		selected_romdir = DefaultSoundCanvasRomsDir;
	}

	// Make sure we search the user's configured directory first
	rom_dirs.emplace_front(resolve_home(selected_romdir.string()));
	return rom_dirs;
}

static void set_soundcanvas_rom_dir_env_var()
{
	// Get potential ROM directory candidates, these will be added to a
	// SOUNDCANVAS_ROM_PATH environment variable which may be used by
	// a plugin to search for ROM files
	std::error_code ec;
	std::string env_list = {};
	for (auto rom_dir : get_rom_dirs()) {
		if (std_fs::is_directory(rom_dir, ec) && !ec) {
			const auto canonical_rom_dir = std_fs::canonical(rom_dir, ec);
			if (ec) {
				continue;
			}
			if (env_list.size() > 0) {
				env_list.append(env_path_separator);
			}
			env_list.append(canonical_rom_dir.string());
		}
	}
	LOG_MSG("SOUNDCANVAS: Setting SOUNDCANVAS_ROM_PATH env variable to '%s'",
	        env_list.c_str());
	set_env_var("SOUNDCANVAS_ROM_PATH", env_list.c_str(), Env::Overwrite);
}

MidiDeviceSoundCanvas::MidiDeviceSoundCanvas()
{
	using namespace SoundCanvas;

	set_soundcanvas_rom_dir_env_var();

	const auto model_name = get_model_setting();

	auto plugin_wrapper = load_model(model_name);
	if (!plugin_wrapper.plugin) {
		const auto msg = format_str("SOUNDCANVAS: Failed to load '%s' Sound Canvas model",
		                            model_name.c_str());
		LOG_WARNING("%s", msg.c_str());
		throw std::runtime_error(msg);
	}

	model = plugin_wrapper.model;

	const auto it = std::find_if(all_models.begin(),
	                             all_models.end(),
	                             [&](const SoundCanvas::SynthModel* m) {
		                             return model.model == m->model;
	                             });
	assert(it != all_models.end());

	const auto sc_model = *it;
	LOG_MSG("SOUNDCANVAS: Initialised %s", sc_model->display_name_long);

	// Run the plugin at the native sample rate of the Sound Canvas model
	// to avoid any extra resampling passes.
	//
	const auto sample_rate_hz = native_sample_rate_hz_for_model(model.model);
	clap.Initialize(std::move(plugin_wrapper.plugin), iroundf(sample_rate_hz));

	MIXER_LockMixerThread();

	// Set up the mixer callback
	const auto mixer_callback = std::bind_front(&MidiSynth::MixerCallback, this);

	mixer_channel = MIXER_AddChannel(mixer_callback,
	                                 iroundf(sample_rate_hz),
	                                 ChannelName::SoundCanvas,
	                                 {ChannelFeature::NoiseGate,
	                                  ChannelFeature::Sleep,
	                                  ChannelFeature::Stereo,
	                                  ChannelFeature::Synthesizer});

	mixer_channel->SetResampleMethod(ResampleMethod::Resample);

	// CLAP plugins render float audio frames between -1.0f and +1.0f, so we
	// ask the channel to scale all the samples up to its 0db level.
	mixer_channel->Set0dbScalar(Max16BitSampleValue);

	// The original SC-55 models ("mk1") have a tendency to output a low
	// level constant noise from time to time depending on previous MIDI
	// input. Implementations accurate to the hardwave behaviour might
	// emulate this noise as well, so we'll use our audio gate to remove it.

	// This effectively disables the gate on the mk2
	const auto is_mk1_model = (sc_model->model <= Model::Sc55_200);
	const auto threshold_db = is_mk1_model ? -70.0f : -1000.0f;

	constexpr auto AttackTimeMs  = 1.0f;
	constexpr auto ReleaseTimeMs = 1000.0f;
	mixer_channel->ConfigureNoiseGate(threshold_db, AttackTimeMs, ReleaseTimeMs);

	const auto denoiser_enabled = get_mixer_section()->GetBool("denoiser");
	mixer_channel->EnableNoiseGate(denoiser_enabled);

	// Set up channel filter
	const auto filter_prefs = get_soundcanvas_section()->GetString(
	        "soundcanvas_filter");

	if (const auto maybe_bool = parse_bool_setting(filter_prefs)) {
		const auto filter_enabled = *maybe_bool;
		setup_filter(mixer_channel, filter_enabled);

	} else if (!mixer_channel->TryParseAndSetCustomFilter(filter_prefs)) {
		if (!has_false(filter_prefs)) {
			LOG_WARNING(
			        "SOUNDCANVAS: Invalid 'soundcanvas_filter' value: '%s', "
			        "using 'on'",
			        filter_prefs.c_str());
		}

		const auto filter_enabled = true;
		setup_filter(mixer_channel, filter_enabled);

		set_section_property_value("soundcanvas", "soundcanvas_filter", "off");
	}

	StartRenderer(iroundf(sample_rate_hz), "dosbox:sndcanv");

	// Start playback
	MIXER_UnlockMixerThread();
}

void MidiDeviceSoundCanvas::RenderAudioFramesToFifo(const int num_audio_frames)
{
	clap.RenderAudioFramesToFifo(num_audio_frames, audio_frame_fifo);
}

void MidiDeviceSoundCanvas::ProcessWorkItem(const MidiWork& work)
{
	clap.ProcessWorkItem(work);
}

static std::set<const SoundCanvas::SynthModel*> available_models = {};

static bool available_models_initialised = false;

void SOUNDCANVAS_ListDevices(MidiDeviceSoundCanvas* device, MoreOutputStrings& output)
{
	using namespace SoundCanvas;

	// Always set rom dir environment variable before listing available
	// sound canvas devices
	set_soundcanvas_rom_dir_env_var();

	// Table layout constants
	constexpr auto ColumnDelim = " ";
	constexpr auto Indent      = "  ";

	if (!available_models_initialised) {
		available_models.clear();
		for (auto m : all_models) {
			if (const auto p = try_load_plugin(*m); p.plugin) {
				available_models.insert(m);
			}
		}
		available_models_initialised = true;
	}

	if (available_models.empty()) {
		output.AddString("%s%s\n\n",
		                 Indent,
		                 MSG_Get("MIDI_DEVICE_NO_MODELS").c_str());
		return;
	}

	const std::optional<SynthModel> active_model = [&] {
		std::optional<SynthModel> model = {};
		if (device) {
			model = device->GetModel();
		}
		return model;
	}();

	const auto active_sc_model = [&]() -> std::optional<const SynthModel*> {
		const auto it = std::find_if(all_models.begin(),
		                             all_models.end(),
		                             [&](const SynthModel* m) {
			                             return (active_model &&
			                                     *active_model == m);
		                             });

		if (it != all_models.end()) {
			return *it;
		} else {
			return {};
		}
	}();

	auto highlight_model = [&](const SynthModel* model, const char* display_name) {
		constexpr auto darkgray = "[color=dark-gray]";
		constexpr auto green    = "[color=light-green]";
		constexpr auto reset    = "[reset]";

		const bool is_missing = !available_models.contains(model);

		const auto is_active = active_sc_model && *active_sc_model == model;

		const auto color = (is_missing ? darkgray
		                               : (is_active ? green : reset));

		const auto active_prefix = (is_active ? "*" : " ");

		const auto model_string = format_str(
		        "%s%s%s%s", color, active_prefix, display_name, reset);

		return convert_ansi_markup(model_string);
	};

	// Print available Sound Canvas models
	output.AddString("%s%s", Indent, MSG_Get("SC55_MODELS_LABEL").c_str());

	// Display order, from old to new
	const std::vector<const SynthModel*> models_old_to_new = {&sc55_100_model,
	                                                          &sc55_110_model,
	                                                          &sc55_120_model,
	                                                          &sc55_121_model,
	                                                          &sc55_200_model,
	                                                          &sc55mk2_100,
	                                                          &sc55mk2_101};

	for (const auto& model : models_old_to_new) {
		const auto display_name = model->display_name_short;
		output.AddString("%s%s",
		                 highlight_model(model, display_name).c_str(),
		                 ColumnDelim);
	}
	output.AddString("\n");

	output.AddString("%s---\n", Indent);

	// Print info about the active model
	if (active_sc_model) {
		output.AddString("%s%s%s\n",
		                 Indent,
		                 MSG_Get("SOUNDCANVAS_ACTIVE_MODEL_LABEL").c_str(),
		                 (*active_sc_model)->display_name_long);
	} else {
		output.AddString("%s%s\n",
		                 Indent,
		                 MSG_Get("MIDI_DEVICE_NO_MODEL_ACTIVE").c_str());
	}

	output.AddString("\n");
}

static void init_soundcanvas_config_settings(SectionProp& sec_prop)
{
	using namespace SoundCanvas;

	constexpr auto when_idle = Property::Changeable::WhenIdle;

	auto* str_prop = sec_prop.AddString("soundcanvas_model", when_idle, "auto");

	// Listed in resolution priority order
	str_prop->SetValues({"auto",
	                     SoundCanvas::BestModelAlias::Sc55,
	                     sc55_121_model.config_name,
	                     sc55_120_model.config_name,
	                     sc55_110_model.config_name,
	                     sc55_100_model.config_name,
	                     sc55_200_model.config_name,

	                     SoundCanvas::BestModelAlias::Sc55mk2,
	                     sc55mk2_100.config_name,
	                     sc55mk2_101.config_name});

	str_prop->SetHelp(
	        "Roland Sound Canvas model to use ('auto' by default). Requires the\n"
	        "'Nuked-SC55.clap' CLAP plugin library in the 'plugins' directory in your DOSBox\n"
	        "installation or configuration directory. The requested model is matched by\n"
	        "plugin name within this library. The lookup for the best model is performed\n"
	        "in order as listed. Possible values:\n"
	        "\n"
	        "  auto:       Pick the best available model (default).\n"
	        "  sc55:       Pick the best available original SC-55 model.\n"
	        "  sc55mk2:    Pick the best available SC-55mk2 model.\n"
	        "  <version>:  Use the exact specified model version (e.g., 'sc55_121').");

	str_prop = sec_prop.AddString("soundcanvas_rom_dir", when_idle, "");
	str_prop->SetHelp(
	        "The directory containing the Roland Sound Canvas ROMs (unset by default).\n"
	        "The directory can be absolute or relative, or leave it unset to use the\n"
	        "'soundcanvas-roms' directory in your DOSBox configuration directory. Other\n"
	        "common system locations will be checked as well.");

	str_prop = sec_prop.AddString("soundcanvas_filter", when_idle, "on");
	assert(str_prop);
	str_prop->SetHelp(
	        "Filter for the Roland Sound Canvas audio output ('on' by default).\n"
	        "Possible values:\n"
	        "\n"
	        "  on:        Filter the output (default).\n"
	        "  off:       Don't filter the output.\n"
	        "  <custom>:  Custom filter definition; see 'sb_filter' for details.");
}

static void register_soundcanvas_text_messages()
{
	MSG_Add("SC55_MODELS_LABEL", "SC-55 models    ");
	MSG_Add("SOUNDCANVAS_ACTIVE_MODEL_LABEL", "Active model:    ");
}

static void notify_soundcanvas_setting_updated([[maybe_unused]] SectionProp& section,
                                               const std::string& prop_name)
{
	if (prop_name == "soundcanvas_rom_dir") {
		available_models_initialised = false;
	}

	const auto device = dynamic_cast<MidiDeviceSoundCanvas*>(
	        MIDI_GetCurrentDevice());

	if (!device) {
		return;
	}

	if (prop_name == "soundcanvas_model") {
		const auto curr_model = device->GetModel().config_name;
		const auto new_model  = get_model_setting();

		if (curr_model != new_model) {
			MIDI_Init();
		}

	} else {
		MIDI_Init();
	}
}

void SOUNDCANVAS_AddConfigSection(const ConfigPtr& conf)
{
	assert(conf);

	auto section = conf->AddSection("soundcanvas");
	section->AddUpdateHandler(notify_soundcanvas_setting_updated);

	init_soundcanvas_config_settings(*section);
	register_soundcanvas_text_messages();
}
