// SPDX-FileCopyrightText:  2020-2026 The DOSBox Staging Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "private/mt32.h"

#if C_MT32EMU

#include <cassert>
#include <deque>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <vector>

#include <SDL3/SDL_endian.h>

#include "private/mt32_lasynth_model.h"

#include "audio/channel_names.h"
#include "audio/mixer.h"
#include "config/config.h"
#include "dos/programs.h"
#include "hardware/audio/mpu401.h"
#include "hardware/pic.h"
#include "ints/int10.h"
#include "midi.h"
#include "misc/ansi_code_markup.h"
#include "misc/cross.h"
#include "misc/support.h"
#include "utils/fs_utils.h"
#include "utils/math_utils.h"
#include "utils/string_utils.h"

// #define DEBUG_MT32

// mt32emu Settings
// ----------------

// Analogue circuit modes: DIGITAL_ONLY, COARSE, ACCURATE, OVERSAMPLED
//
// Accurate mode achieves finer emulation of LPF circuit. Output signal is
// upsampled to 48 kHz to allow emulation of audible mirror spectra above 16
// kHz which is passed through the LPF circuit without significant
// attenuation.
constexpr auto AnalogMode = MT32Emu::AnalogOutputMode_ACCURATE;

constexpr auto AccurateAnalogModeSampleRateHz = 48'000;

// DAC Emulation modes: NICE, PURE, GENERATION1, and GENERATION2
//
// "Nice" mode produces samples at double the volume, without tricks, and
// results in nicer overdrive characteristics than the DAC hacks (it simply
// clips samples within range). Higher quality than the real devices.
constexpr auto DacEmulationMode = MT32Emu::DACInputMode_NICE;

// Analog rendering types: BIT16S, FLOAT
//
// Use 16-bit signed samples in the renderer and the accurate wave generator
// model based on logarithmic fixed-point computations and LUTs. Maximum
// emulation accuracy and speed (it's a lot faster than the FLOAT renderer).
constexpr auto RenderingType = MT32Emu::RendererType_BIT16S;

// In this mode, we want to ensure that amp ramp never jumps to the target
// value and always gradually increases or decreases. It seems that real units
// do not bother to always check if a newly started ramp leads to a jump.
// We also prefer the quality improvement over the emulation accuracy,
// so this mode is enabled by default.
constexpr bool UseNiceRamp = true;

// Despite the Roland's manual specifies allowed panpot values in range 0-14,
// the LA-32 only receives 3-bit pan setting in fact. In particular, this
// makes it impossible to set the "middle" panning for a single partial.
// In the NicePanning mode, we enlarge the pan setting accuracy to 4 bits
// making it smoother thus sacrificing the emulation accuracy.
constexpr bool UseNicePanning = true;

// LA-32 is known to mix partials either in-phase (so that they are added)
// or in counter-phase (so that they are subtracted instead).
// In some cases, this quirk isn't highly desired because a pair of closely
// sounding partials may occasionally cancel out.
// In the NicePartialMixing mode, the mixing is always performed in-phase,
// thus making the behaviour more predictable.
constexpr bool UseNicePartialMixing = true;

// Do not attempt to emulate delays introduced by the slow MIDI transfer
// protocol.
//
// Enabling delay emulation could result in missed MIDI events if the MT-32
// receives a large number of events in quick bursts, causing its internal
// ring buffers to overflow. This can be heard as missed notes and
// wrong sounding instrument (e.g., in the intro tune of Bumpy's Arcade
// Fantasy).
//
// Emulating MIDI protocol induced micro-delays are neither musically
// significant nor desirable. Most importantly, these odd up to 1-3 ms delays
// on some events are not noticeable. Losing MIDI events that potentially set
// up the correct sounds when the game starts is a much more important concern.
//
// While such transfer bursts are most likely an MPU-401 intelligent mode
// emulation bug in DOSBox, disabling the delay mode emulation in libmt32
// effectively fixes the problem and makes the resulting music sound closer to
// the composer's intentions.
//
constexpr auto MidiDelayMode = MT32Emu::MIDIDelayMode_IMMEDIATE;

using Rom = LASynthModel::Rom;

// MT-32
const Rom mt32_ctrl_104_f = {"ctrl_mt32_1_04", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_104_a = {"ctrl_mt32_1_04_a", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_104_b = {"ctrl_mt32_1_04_b", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_105_f = {"ctrl_mt32_1_05", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_105_a = {"ctrl_mt32_1_05_a", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_105_b = {"ctrl_mt32_1_05_b", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_106_f = {"ctrl_mt32_1_06", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_106_a = {"ctrl_mt32_1_06_a", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_106_b = {"ctrl_mt32_1_06_b", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_107_f = {"ctrl_mt32_1_07", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_107_a = {"ctrl_mt32_1_07_a", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_107_b = {"ctrl_mt32_1_07_b", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_bluer_f = {"ctrl_mt32_bluer", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_bluer_a = {"ctrl_mt32_bluer_a", LASynthModel::ROM_TYPE::CONTROL};
const Rom mt32_ctrl_bluer_b = {"ctrl_mt32_bluer_b", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_203_f = {"ctrl_mt32_2_03", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_204_f = {"ctrl_mt32_2_04", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_206_f = {"ctrl_mt32_2_06", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_ctrl_207_f = {"ctrl_mt32_2_07", LASynthModel::ROM_TYPE::CONTROL};

const Rom mt32_pcm_100_f = {"pcm_mt32", LASynthModel::ROM_TYPE::PCM};
const Rom mt32_pcm_100_l = {"pcm_mt32_l", LASynthModel::ROM_TYPE::PCM};
const Rom mt32_pcm_100_h = {"pcm_mt32_h", LASynthModel::ROM_TYPE::PCM};

// CM-32L & CM-32LN
const Rom cm32l_ctrl_100_f = {"ctrl_cm32l_1_00", LASynthModel::ROM_TYPE::CONTROL};
const Rom cm32l_ctrl_102_f = {"ctrl_cm32l_1_02", LASynthModel::ROM_TYPE::CONTROL};
const Rom cm32ln_ctrl_100_f = {"ctrl_cm32ln_1_00", LASynthModel::ROM_TYPE::CONTROL};

const Rom cm32l_pcm_100_f = {"pcm_cm32l", LASynthModel::ROM_TYPE::PCM};
const Rom cm32l_pcm_100_h = {"pcm_cm32l_h", LASynthModel::ROM_TYPE::PCM};

// Lower half of samples comes from MT-32
const Rom& cm32l_pcm_100_l = mt32_pcm_100_f;

// Roland LA models (composed of ROMs)
const LASynthModel mt32_104_model = {"mt32_104",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_104_f,
                                     &mt32_ctrl_104_a,
                                     &mt32_ctrl_104_b};

const LASynthModel mt32_105_model = {"mt32_105",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_105_f,
                                     &mt32_ctrl_105_a,
                                     &mt32_ctrl_105_b};

const LASynthModel mt32_106_model = {"mt32_106",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_106_f,
                                     &mt32_ctrl_106_a,
                                     &mt32_ctrl_106_b};

const LASynthModel mt32_107_model = {"mt32_107",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_107_f,
                                     &mt32_ctrl_107_a,
                                     &mt32_ctrl_107_b};

const LASynthModel mt32_bluer_model = {"mt32_bluer",
                                       &mt32_pcm_100_f,
                                       &mt32_pcm_100_l,
                                       &mt32_pcm_100_h,
                                       &mt32_ctrl_bluer_f,
                                       &mt32_ctrl_bluer_a,
                                       &mt32_ctrl_bluer_b};

const LASynthModel mt32_203_model = {"mt32_203",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_203_f,
                                     nullptr,
                                     nullptr};

const LASynthModel mt32_204_model = {"mt32_204",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_204_f,
                                     nullptr,
                                     nullptr};

const LASynthModel mt32_206_model = {"mt32_206",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_206_f,
                                     nullptr,
                                     nullptr};

const LASynthModel mt32_207_model = {"mt32_207",
                                     &mt32_pcm_100_f,
                                     &mt32_pcm_100_l,
                                     &mt32_pcm_100_h,
                                     &mt32_ctrl_207_f,
                                     nullptr,
                                     nullptr};

const LASynthModel cm32l_100_model = {"cm32l_100",
                                      &cm32l_pcm_100_f,
                                      &cm32l_pcm_100_l,
                                      &cm32l_pcm_100_h,
                                      &cm32l_ctrl_100_f,
                                      nullptr,
                                      nullptr};

const LASynthModel cm32l_102_model = {"cm32l_102",
                                      &cm32l_pcm_100_f,
                                      &cm32l_pcm_100_l,
                                      &cm32l_pcm_100_h,
                                      &cm32l_ctrl_102_f,
                                      nullptr,
                                      nullptr};

const LASynthModel cm32ln_100_model = {"cm32ln_100",
                                       &cm32l_pcm_100_f,
                                       &cm32l_pcm_100_l,
                                       &cm32l_pcm_100_h,
                                       &cm32ln_ctrl_100_f,
                                       nullptr,
                                       nullptr};

// In order that 'model = auto' will load.
//
// Notes:
//
// - Blue Ridge is the *least* desirable "old" MT-32 ROM as it crashes Wing
//   Commander 1 & 2 while 1.07 works just fine.
//
// - CM-32LN has a different (faster) vibrato that all the other MT-32/CM-32L
//   models, which causes some soundtracks to sound quite wrong on it. This
//   makes it the *least* desirable CM-32L model.
//
// - For the rest of the models, higher versions are better as they fix
//   certain bugs of previous models.
//
// ------
// More info:
//
// Detailed info about various ROM versions
// - https://www.vogons.org/viewtopic.php?p=848507#p848507
// - https://www.vogons.org/viewtopic.php?p=848518#p848518
//
// Blue Ridge problems
// - https://www.vogons.org/viewtopic.php?p=803448#p803448
//
// CM-32LN vibrato issue
// - https://www.vogons.org/viewtopic.php?p=605136#p605136

// Listed in resolution priority order
static const std::vector<const LASynthModel*> all_models = {
        &cm32l_102_model,
        &cm32l_100_model,
        &cm32ln_100_model,

        &mt32_107_model,
        &mt32_106_model,
        &mt32_105_model,
        &mt32_104_model,
        &mt32_bluer_model,

        &mt32_207_model,
        &mt32_206_model,
        &mt32_204_model,
        &mt32_203_model,
};

// Listed in resolution priority order
static const std::vector<const LASynthModel*> mt32_models = {
        &mt32_107_model,
        &mt32_106_model,
        &mt32_105_model,
        &mt32_104_model,
        &mt32_bluer_model,

        &mt32_207_model,
        &mt32_206_model,
        &mt32_204_model,
        &mt32_203_model,
};

// Listed in resolution priority order
static const std::vector<const LASynthModel*> mt32_old_models = {
        &mt32_107_model,
        &mt32_106_model,
        &mt32_105_model,
        &mt32_104_model,
        &mt32_bluer_model,
};

// Listed in resolution priority order
static const std::vector<const LASynthModel*> mt32_new_models = {
        &mt32_207_model,
        &mt32_206_model,
        &mt32_204_model,
        &mt32_203_model,
};

// Listed in resolution priority order
static const std::vector<const LASynthModel*> cm32l_models = {
        &cm32l_102_model,
        &cm32l_100_model,
        &cm32ln_100_model,
};

// Symbolic model aliases
namespace BestModelAlias {
constexpr auto Mt32Any = "mt32";
constexpr auto Mt32Old = "mt32_old";
constexpr auto Mt32New = "mt32_new";
constexpr auto Cm32l   = "cm32l";
} // namespace BestModelAlias

static void init_mt32_config_settings(SectionProp& sec_prop)
{
	constexpr auto when_idle = Property::Changeable::WhenIdle;

	auto* str_prop = sec_prop.AddString("model", when_idle, "auto");

	// Listed in resolution priority order
	str_prop->SetValues({"auto",
	                     BestModelAlias::Cm32l,
	                     cm32l_102_model.GetName(),
	                     cm32l_100_model.GetName(),
	                     cm32ln_100_model.GetName(),

	                     BestModelAlias::Mt32Any,
	                     BestModelAlias::Mt32Old,
	                     mt32_107_model.GetName(),
	                     mt32_106_model.GetName(),
	                     mt32_105_model.GetName(),
	                     mt32_104_model.GetName(),
	                     mt32_bluer_model.GetName(),

	                     BestModelAlias::Mt32New,
	                     mt32_207_model.GetName(),
	                     mt32_206_model.GetName(),
	                     mt32_204_model.GetName(),
	                     mt32_203_model.GetName()});
	str_prop->SetHelp(
	        "Roland MT-32/CM-32L model to use ('auto' by default). You must have the ROM\n"
	        "files for the selected model available (see 'romdir'). The lookup for the best\n"
	        "models is performed in order as listed. Possible values:\n"
	        "\n"
	        "  auto:       Pick the best available model (default).\n"
	        "  cm32l:      Pick the best available CM-32L model.\n"
	        "  mt32_old:   Pick the best available \"old\" MT-32 model (v1.0x).\n"
	        "  mt32_new:   Pick the best available \"new\" MT-32 model (v2.0x).\n"
	        "  mt32:       Pick the best available MT-32 model.\n"
	        "  <version>:  Use the exact specified model version (e.g., 'mt32_204').\n"
	        "\n"
	        "Notes:\n"
	        "  - Run `MIXER /LISTMIDI` to see the list of available models.\n"
	        "\n"
	        "  - This is *NOT* a General MIDI compatible MIDI device; only use it if the\n"
	        "    game is known to support Roland MT-32 MIDI (which predates General MIDI).\n");

	str_prop = sec_prop.AddString("romdir", when_idle, "");
	str_prop->SetHelp(
	        "The directory containing the Roland MT-32/CM-32L ROMs (unset by default).\n"
	        "The directory can be absolute or relative, or leave it unset to use the\n"
	        "'mt32-roms' directory in your DOSBox configuration directory. Other common\n"
	        "system locations will be checked as well.\n"
	        "\n"
	        "Notes:\n"
	        "  - The file names of the ROM files do not matter; the ROMS are identified\n"
	        "    by their checksums.\n"
	        "\n"
	        "  - Both interleaved and non-interlaved ROM files are supported.");

	str_prop = sec_prop.AddString("mt32_filter", when_idle, "off");
	assert(str_prop);
	str_prop->SetHelp(
	        "Filter for the Roland MT-32/CM-32L audio output ('off' by default).\n"
	        "Possible values:\n"
	        "\n"
	        "  off:       Don't filter the output (default).\n"
	        "  <custom>:  Custom filter definition; see 'sb_filter' for details.");
}

static void register_mt32_text_messages()
{
	MSG_Add("MT32_ROMS_LABEL", "MT-32  models   ");
	MSG_Add("CM32L_ROMS_LABEL", "CM-32L models   ");
	MSG_Add("MT32_ACTIVE_MODEL_LABEL", "Active model  ");
	MSG_Add("MT32_SOURCE_DIR_LABEL", "ROM path      ");
}

#if defined(WIN32)

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	return {
	        get_config_dir() / DefaultMt32RomsDir,
	        "C:\\mt32-rom-data\\",
	};
}

#elif defined(MACOSX)

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	return {
	        get_config_dir() / DefaultMt32RomsDir,
	        resolve_home("~/Library/Audio/Sounds/MT32-Roms/"),
	        "/usr/local/share/mt32-rom-data/",
	        "/usr/share/mt32-rom-data/",
	};
}
#else

static std::deque<std_fs::path> get_platform_rom_dirs()
{
	// First priority is user-specific data location
	const auto xdg_data_home = get_xdg_data_home();

	std::deque<std_fs::path> dirs = {
	        xdg_data_home / "dosbox" / DefaultMt32RomsDir,
	        xdg_data_home / "mt32-rom-data",
	};

	// Second priority are the $XDG_DATA_DIRS
	for (const auto& data_dir : get_xdg_data_dirs()) {
		dirs.emplace_back(data_dir / "mt32-rom-data");
	}

	// Third priority is $XDG_CONF_HOME, for convenience
	dirs.emplace_back(get_config_dir() / DefaultMt32RomsDir);

	return dirs;
}

#endif

static SectionProp* get_mt32_section()
{
	const auto section = get_section("mt32");
	assert(section);

	return section;
}

static std::deque<std_fs::path> get_rom_dirs()
{
	// Get potential ROM directories from the environment and/or system
	auto rom_dirs = get_platform_rom_dirs();

	// Get the user's configured ROM directory; otherwise use 'mt32-roms'
	std_fs::path selected_romdir = get_mt32_section()->GetString("romdir");

	if (selected_romdir.empty()) { // already trimmed
		selected_romdir = DefaultMt32RomsDir;
	}

	// Make sure we search the user's configured directory first
	rom_dirs.emplace_front(resolve_home(selected_romdir.string()));
	return rom_dirs;
}

static std::string get_model_setting()
{
	return get_mt32_section()->GetString("model");
}

static std::set<const LASynthModel*> find_models(MT32Emu::Service& service,
                                                 const std_fs::path& dir)
{
	std::set<const LASynthModel*> models = {};
	for (const auto& model : all_models) {
		if (model->InDir(service, dir)) {
			models.insert(model);
		}
	}
	return models;
}

static std::optional<ModelAndDir> load_model(MT32Emu::Service& service,
                                             const std::string& wanted_model_name,
                                             const std::deque<std_fs::path>& rom_dirs)
{
	// Determine the list of ROM model candidates and the lookup method for
	// the requested model name:
	//
	// - Symbolic model names (e.g., 'auto', 'mt32', 'mt32_old', etc.)
	//   resolve the first available model from the list of candidates in
	//   the listed priority. The lookup only fails if none of the candidate
	//   models could be resolved.
	//
	// - Concrete versioned model names always try to resolve a single model
	//   version or fail if the requested model is not present.
	//
	auto [load_first_available, candidate_models] =
	        [&]() -> std::pair<bool, const std::vector<const LASynthModel*>&> {
		// Symbolic mode names (resolve the best match from a list of
		// candidates).
		if (wanted_model_name == "auto") {
			return {true, all_models};
		}
		if (wanted_model_name == BestModelAlias::Mt32Any) {
			return {true, mt32_models};
		}
		if (wanted_model_name == BestModelAlias::Mt32Old) {
			return {true, mt32_old_models};
		}
		if (wanted_model_name == BestModelAlias::Mt32New) {
			return {true, mt32_new_models};
		}
		if (wanted_model_name == BestModelAlias::Cm32l) {
			return {true, cm32l_models};
		}

		// Concrete versioned model name (resolve the specific requested
		// model from the list of all supported models).
		return {false, all_models};
	}();

	// Perform model lookup from the list of candidate models
	for (const auto& model : candidate_models) {
		if (load_first_available || model->Matches(wanted_model_name)) {
			for (const auto& dir : rom_dirs) {
				if (model->Load(service, dir)) {
					return {
					        {model, simplify_path(dir)}
                                        };
				}
			}
		}
	}
	return {};
}

static mt32emu_report_handler_i get_report_handler_interface()
{
	class ReportHandler {
	public:
		static mt32emu_report_handler_version getReportHandlerVersionID(mt32emu_report_handler_i)
		{
			return MT32EMU_REPORT_HANDLER_VERSION_0;
		}

		static void printDebug([[maybe_unused]] void* instance_data,
		                       [[maybe_unused]] const char* fmt,
		                       [[maybe_unused]] va_list list)
		{
#if !defined(NDEBUG)
			// Skip processing MT-32 debug output in release builds
			// because it can be bursty
			char msg[1024] = "MT32: ";
			assert(fmt);
			safe_strcat(msg, fmt);
			LOG_DEBUG(msg, list);
#endif
		}

		static void onErrorControlROM(void*)
		{
			LOG_ERR("MT32: Error opening Control ROM file");
		}

		static void onErrorPCMROM(void*)
		{
			LOG_ERR("MT32: Error opening PCM ROM file");
		}

		static void showLCDMessage(void*, const char* message)
		{
			LOG_MSG("MT32: LCD message: %s", message);
		}
	};

	static const mt32emu_report_handler_i_v0 REPORT_HANDLER_V0_IMPL = {
	        ReportHandler::getReportHandlerVersionID,
	        ReportHandler::printDebug,
	        ReportHandler::onErrorControlROM,
	        ReportHandler::onErrorPCMROM,
	        ReportHandler::showLCDMessage,
	        nullptr, // explicit empty function pointers
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr,
	        nullptr};

	static const mt32emu_report_handler_i REPORT_HANDLER_I = {
	        &REPORT_HANDLER_V0_IMPL};

	return REPORT_HANDLER_I;
}

static std::unique_ptr<MT32Emu::Service> create_mt32_service()
{
	auto service = std::make_unique<MT32Emu::Service>();

	// Has libmt32emu already created a context?
	if (!service->getContext()) {
		service->createContext(get_report_handler_interface(), nullptr);
	}
	return service;
}

// Returns the set of models supported by all of the directories, and also
// populates the provide map of the modules supported by each directory.

using DirsWithModels = std::map<std_fs::path, std::set<const LASynthModel*>>;

static std::set<const LASynthModel*> find_available_models(MT32Emu::Service& service,
                                                           DirsWithModels& dirs_with_models)
{
	std::set<const LASynthModel*> available_models;

	for (const auto& dir : get_rom_dirs()) {
		const auto models = find_models(service, dir);
		if (!models.empty()) {
			dirs_with_models[dir] = models;
			available_models.insert(models.begin(), models.end());
		}
	}
	return available_models;
}

MidiDeviceMt32::MidiDeviceMt32()
{
	auto mt32_service = create_mt32_service();

	const auto model_name = get_model_setting();
	const auto rom_dirs   = get_rom_dirs();

	// Load the selected model and print info about it
	auto loaded_model_and_dir = load_model(*mt32_service, model_name, rom_dirs);
	if (!loaded_model_and_dir) {
		const auto msg = format_str("MT32: Failed to find ROMs for model %s in:",
		                            model_name.c_str());
		LOG_WARNING("%s", msg.c_str());

		for (const auto& dir : rom_dirs) {
			const char div = (dir != rom_dirs.back() ? '|' : '`');
			LOG_MSG("MT32:  %c- %s", div, dir.string().c_str());
		}
		throw std::runtime_error(msg);
	}

	const std::lock_guard<std::mutex> lock(service_mutex);

	mt32emu_rom_info rom_info;
	mt32_service->getROMInfo(&rom_info);

	assert(loaded_model_and_dir.has_value());
	LOG_MSG("MT32: Initialised %s from '%s'",
	        rom_info.control_rom_description,
	        loaded_model_and_dir->second.string().c_str());

	const auto sample_rate_hz = AccurateAnalogModeSampleRateHz;

	mt32_service->setAnalogOutputMode(AnalogMode);
	mt32_service->selectRendererType(RenderingType);
	mt32_service->setDACInputMode(DacEmulationMode);
	mt32_service->setNiceAmpRampEnabled(UseNiceRamp);
	mt32_service->setNicePanningEnabled(UseNicePanning);
	mt32_service->setNicePartialMixingEnabled(UseNicePartialMixing);
	mt32_service->setMIDIDelayMode(MidiDelayMode);

	const auto rc = mt32_service->openSynth();

	if (rc != MT32EMU_RC_OK) {
		const auto msg = format_str("MT32: Error initialising emulation, error code: %i",
		                            rc);
		LOG_ERR("%s", msg.c_str());
		throw std::runtime_error(msg);
	}

	MIXER_LockMixerThread();

	// Set up the mixer callback
	const auto mixer_callback = std::bind_front(&MidiSynth::MixerCallback, this);

	auto channel = MIXER_AddChannel(mixer_callback,
	                                sample_rate_hz,
	                                ChannelName::RolandMt32,
	                                {ChannelFeature::Sleep,
	                                 ChannelFeature::Stereo,
	                                 ChannelFeature::Synthesizer});

	channel->SetResampleMethod(ResampleMethod::Resample);

	// libmt32emu renders float audio frames between -1.0f and +1.0f, so we
	// ask the channel to scale all the samples up to its 0db level.
	channel->Set0dbScalar(Max16BitSampleValue);

	const std::string filter_prefs = get_mt32_section()->GetString("mt32_filter");

	if (!channel->TryParseAndSetCustomFilter(filter_prefs)) {
		if (!has_false(filter_prefs)) {
			LOG_WARNING("MT32: Invalid 'mt32_filter' value: '%s', using 'off'",
			            filter_prefs.c_str());
		}

		channel->SetHighPassFilter(FilterState::Off);
		channel->SetLowPassFilter(FilterState::Off);

		set_section_property_value("mt32", "mt32_filter", "off");
	}

	// Move the local objects into the member variables
	service       = std::move(mt32_service);
	mixer_channel = std::move(channel);
	model_and_dir = std::move(*loaded_model_and_dir);

	StartRenderer(sample_rate_hz, "dosbox:mt32");

	// Start playback
	MIXER_UnlockMixerThread();
}

void MidiDeviceMt32::CloseSynth()
{
	const std::lock_guard<std::mutex> lock(service_mutex);

	if (service) {
		service->closeSynth();
		service->freeContext();
	}
}

void MidiDeviceMt32::RenderAudioFramesToFifo(const int num_frames)
{
	static std::vector<AudioFrame> audio_frames = {};

	// Maybe expand the vector
	if (check_cast<int>(audio_frames.size()) < num_frames) {
		audio_frames.resize(num_frames);
	}

	std::unique_lock<std::mutex> lock(service_mutex);
	service->renderFloat(&audio_frames[0][0], num_frames);

	audio_frame_fifo.BulkEnqueue(audio_frames, num_frames);
}

void MidiDeviceMt32::ProcessWorkItem(const MidiWork& work)
{
	const std::lock_guard<std::mutex> lock(service_mutex);

	if (work.message_type == MessageType::Channel) {
		assert(work.message.size() <= MaxMidiMessageLen);

		const auto& data   = work.message.data();
		const uint32_t msg = data[0] + (data[1] << 8) + (data[2] << 16);

		service->playMsg(msg);
	} else {
		assert(work.message_type == MessageType::SysEx);

		service->playSysex(work.message.data(),
		                   static_cast<uint32_t>(work.message.size()));
	}
}

ModelAndDir MidiDeviceMt32::GetModelAndDir()
{
	return model_and_dir;
}

mt32emu_rom_info MidiDeviceMt32::GetRomInfo()
{
	mt32emu_rom_info rom_info = {};
	service->getROMInfo(&rom_info);
	return rom_info;
}

// Prints a table of directories and supported models. Models are printed
// across the first row and directories are printed down the left column.
// Long directories are truncated and model versions are used to avoid text
// wrapping.
void MT32_ListDevices(MidiDeviceMt32* device, MoreOutputStrings& output)
{
	// Table layout constants
	constexpr auto ColumnDelim = " ";
	constexpr auto Indent      = "  ";

	const std::vector<const LASynthModel*> mt32_model_list = {&mt32_104_model,
	                                                          &mt32_105_model,
	                                                          &mt32_106_model,
	                                                          &mt32_107_model,
	                                                          &mt32_bluer_model,
	                                                          &mt32_203_model,
	                                                          &mt32_204_model,
	                                                          &mt32_206_model,
	                                                          &mt32_207_model};

	const std::vector<const LASynthModel*> cm32_model_list = {
	        &cm32l_100_model, &cm32l_102_model, &cm32ln_100_model};

	// Get the set of directories and the models they support
	const auto service = create_mt32_service();

	DirsWithModels dirs_with_models;
	const auto available_models = find_available_models(*service,
	                                                    dirs_with_models);

	if (available_models.empty()) {
		output.AddString("%s%s\n\n",
		                 Indent,
		                 MSG_Get("MIDI_DEVICE_NO_MODELS").c_str());
		return;
	}

	const auto model_and_dir = [&]() -> std::optional<ModelAndDir> {
		if (device) {
			return device->GetModelAndDir();
		}
		return {};
	}();

	auto highlight_model = [&](const LASynthModel* model,
	                           const char* display_name) {
		constexpr auto darkgray = "[color=dark-gray]";
		constexpr auto green    = "[color=light-green]";
		constexpr auto reset    = "[reset]";

		const bool is_missing = (available_models.find(model) ==
		                         available_models.end());

		const auto is_active = (model_and_dir &&
		                        model_and_dir->first == model);

		const auto color = (is_missing ? darkgray
		                               : (is_active ? green : reset));

		const auto active_prefix = (is_active ? "*" : " ");
		const auto model_string  = format_str(
                        "%s%s%s%s", color, active_prefix, display_name, reset);

		return convert_ansi_markup(model_string);
	};

	// Print available MT-32 ROMs
	output.AddString("%s%s", Indent, MSG_Get("MT32_ROMS_LABEL").c_str());

	for (const auto& model : mt32_model_list) {
		const auto display_name = model->GetVersion();
		output.AddString("%s%s",
		                 highlight_model(model, display_name).c_str(),
		                 ColumnDelim);
	}
	output.AddString("\n");

	// Print available CM-32L ROMs
	output.AddString("%s%s", Indent, MSG_Get("CM32L_ROMS_LABEL").c_str());

	for (const auto& model : cm32_model_list) {
		const auto display_name = (model->GetName() == cm32ln_100_model.GetName()
		                                   ? model->GetName()
		                                   : model->GetVersion());
		output.AddString("%s%s",
		                 highlight_model(model, display_name).c_str(),
		                 ColumnDelim);
	}
	output.AddString("\n");

	output.AddString("%s---\n", Indent);

	// Print info about the active model
	if (model_and_dir) {
		output.AddString("%s%s%s (%s)\n",
		                 Indent,
		                 MSG_Get("MT32_ACTIVE_MODEL_LABEL").c_str(),
		                 model_and_dir->first->GetName(),
		                 device->GetRomInfo().control_rom_description);

		// Print the loaded ROM's directory
		const auto dir_label = MSG_Get("MT32_SOURCE_DIR_LABEL");

		const auto dir_max_length = INT10_GetTextColumns() -
		                            (dir_label.length() +
		                             std::string_view(Indent).length());

		const auto truncated_dir = truncate_path(model_and_dir->second.string(),
		                                         dir_max_length);

		output.AddString("%s%s%s\n",
		                 Indent,
		                 dir_label.c_str(),
		                 truncated_dir.c_str());
	} else {
		output.AddString("%s%s\n",
		                 Indent,
		                 MSG_Get("MIDI_DEVICE_NO_MODEL_ACTIVE").c_str());
	}

	output.AddString("\n");
}

static void notify_mt32_setting_updated([[maybe_unused]] SectionProp& section,
                                        const std::string& prop_name)
{
	const auto device = dynamic_cast<MidiDeviceMt32*>(MIDI_GetCurrentDevice());

	if (!device) {
		return;
	}

	if (prop_name == "model") {
		const auto curr_model = device->GetModelAndDir().first->GetName();
		const auto new_model = get_model_setting();

		if (curr_model != new_model) {
			MIDI_Init();
		}

	} else {
		MIDI_Init();
	}
}

void MT32_AddConfigSection(const ConfigPtr& conf)
{
	assert(conf);

	auto section = conf->AddSection("mt32");
	section->AddUpdateHandler(notify_mt32_setting_updated);

	init_mt32_config_settings(*section);
	register_mt32_text_messages();
}

#endif // C_MT32EMU
