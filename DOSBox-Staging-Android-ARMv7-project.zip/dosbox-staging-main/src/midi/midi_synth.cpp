// SPDX-FileCopyrightText:  2026-2026 The DOSBox Staging Team
// SPDX-License-Identifier: GPL-2.0-or-later

#include "private/midi_synth.h"

#include "hardware/pic.h"
#include "misc/support.h"
#include "utils/math_utils.h"
#include "utils/string_utils.h"

// #define MIDI_SYNTH_DEBUG

void MidiSynth::StartRenderer(const int sample_rate_hz, const char* thread_name)
{
	assert(mixer_channel);
	assertm(sample_rate_hz >= 8000, "Sample rate must be at least 8 kHz");

	ms_per_audio_frame = MillisInSecond / sample_rate_hz;

	// Double the baseline PCM prebuffer because MIDI is demanding and
	// bursty. The mixer's default of ~20 ms becomes 40 ms here, which gives
	// slower systems a better chance to keep up.
	const auto render_ahead_ms = MIXER_GetPreBufferMs() * 2;
	const auto audio_frames_per_ms = iround(sample_rate_hz / MillisInSecond);

	audio_frame_fifo.Resize(
	        check_cast<size_t>(render_ahead_ms * audio_frames_per_ms));

	work_fifo.Resize(MaxMidiWorkFifoSize);

	renderer = std::thread(std::bind_front(&MidiSynth::Render, this));
	set_thread_name(renderer, thread_name);
}

// Keep the FIFO populated with freshly rendered buffers
void MidiSynth::Render()
{
	while (work_fifo.IsRunning()) {
		if (pauser.ParkIfPaused(audio_frame_fifo)) {
			continue;
		}

		if (is_work_fifo_backlogged) {
			RenderBacklogged();
		} else {
			constexpr auto OneFrame = 1;
			work_fifo.IsEmpty() ? RenderAudioFramesToFifo(OneFrame)
			                    : ProcessWorkFromFifo();
		}
	}
	CloseRenderer();
}

void MidiSynth::Shutdown()
{
	LOG_MSG("%s: Shutting down", upcase(GetName()).c_str());

	if (had_underruns) {
		LOG_WARNING(
		        "%s: Fix underruns by lowering the CPU load or increasing "
		        "the 'prebuffer' or 'blocksize' settings",
		        upcase(GetName()).c_str());
	}

	// Stop queueing new MIDI work and audio frames
	work_fifo.Stop();
	audio_frame_fifo.Stop();

	MIXER_LockMixerThread();

	// Stop playback
	if (mixer_channel) {
		mixer_channel->Enable(false);
	}

	// Wake the renderer via the pauser's condvar if it's parked (stopping
	// `work_fifo` alone does not notify it); once unblocked it sees
	// `work_fifo` has stopped and exits its loop cleanly.
	Resume();

	// Wait for the rendering thread to finish
	if (renderer.joinable()) {
		renderer.join();
	}

	CloseSynth();

	// Deregister the mixer channel and remove it
	assert(mixer_channel);
	MIXER_DeregisterChannel(mixer_channel);
	mixer_channel.reset();

	MIXER_UnlockMixerThread();
}

// The next MIDI work task is processed, which includes rendering audio frames
// prior to applying channel and sysex messages to the service
void MidiSynth::ProcessWorkFromFifo()
{
	const auto work = work_fifo.Dequeue();
	if (!work) {
		return;
	}

	// Detect if the work FIFO is heavily backlogged and enter the special
	// backlogged rendering mode. This happens in fast-forward mode if the
	// MIDI synth can't keep up with the sped-up CPU emulation.
	const auto delta_from_now    = PIC_AtomicIndex() - work->timestamp;
	constexpr auto OneSecondInMs = 1000.0;

	if (delta_from_now > OneSecondInMs) {
		is_work_fifo_backlogged = true;
	}

#ifdef MIDI_SYNTH_DEBUG
	LOG_TRACE(
	        "%s: %2u audio frames prior to %s message, followed by "
	        "%2lu more messages. Have %4lu audio frames queued",
	        upcase(GetName()).c_str(),
	        work->num_pending_audio_frames,
	        work->message_type == MessageType::Channel ? "channel" : "SysEx",
	        work_fifo.Size(),
	        audio_frame_fifo.Size());
#endif

	if (work->num_pending_audio_frames > 0) {
		RenderAudioFramesToFifo(work->num_pending_audio_frames);
	}

	ProcessWorkItem(*work);
}

void MidiSynth::RenderBacklogged()
{
	if (work_fifo.IsEmpty()) {
		// We've caught up. Render a frame instead of blocking in
		// Dequeue(), exactly like the non-backlogged path does.
		constexpr auto OneFrame = 1;
		RenderAudioFramesToFifo(OneFrame);

	} else {
		// This will only keep the MIDI events we must process (e.g.
		// program change and SysEx messages).
		ProcessWorkFromFifoBacklogged();
	}

	// We must drip-feed these essential MIDI events to the MIDI synth
	// while in fast-forward mode and render a nominal sample now and then
	// to keep the emulation ticking along. Batching them up in groups of 10
	// does the job fine.
	//
	// If we'd let them pile up and send in one big batch after exiting
	// fast-forward mode, we'd overload the MIDI synth's input buffers so
	// not all messages would be processed. This has been proven to not be a
	// viable approach as it resulted in wrong-sounding instruments in many
	// cases.
	//
	if (work_fifo.Size() > 10) {
		constexpr auto OneFrame = 1;
		RenderAudioFramesToFifo(OneFrame);
	}

	if (!MIXER_FastForwardModeEnabled()) {
		is_work_fifo_backlogged = false;

		// Send "All Notes Off" message to all MIDI channels when
		// exiting from fast-forward mode. This is the best we can do as
		// we've skipped processing any "Note On" or "Note Off" messages
		// while in fast-forward mode. There would be a lot of hanging
		// notes if we don't do this.
		//
		// We're on the renderer thread, which is the only consumer of
		// `work_fifo`, so we must not go through `SendMidiMessage()`
		// here as `Enqueue()` blocks when the FIFO is full. Hand the
		// messages straight to the synth instead; the synth is already
		// in sync at this point so there are no audio frames to render
		// first.
		//
		for (uint8_t ch = 0; ch < NumMidiChannels; ++ch) {
			const uint8_t status = MidiStatus::ControlChange | ch;

			MidiMessage msg = {};
			msg[0]          = status;
			msg[1]          = MidiChannelMode::AllNotesOff;

			const MidiWork work{std::vector<uint8_t>(msg.data.begin(),
			                                         msg.data.end()),
			                    0,
			                    MessageType::Channel,
			                    PIC_AtomicIndex()};

			ProcessWorkItem(work);
		}
	}
}

void MidiSynth::ProcessWorkFromFifoBacklogged()
{
	const auto work = work_fifo.Dequeue();
	if (!work) {
		return;
	}

	// If we're in backlogged mode when fast-forward is activated, it means
	// the MIDI synth can't keep up with the sped-up CPU emulation.
	// Therefore, we need to minimise the work to catch up.
	//
	// We can't just *not* process any MIDI events at all; we need to keep
	// processing program change, control change, etc. events, otherwise
	// there's a chance the instrument sounds will be wrong when we resume
	// normal playback. But we can drop all MIDI notes and bypass the actual
	// audio rendering; we'll just render a few samples from time to time to
	// keep the MIDI synth ticking along. This way, we can catch up and stay
	// in sync with the CPU emulation.
	//
	if (const auto status = get_midi_status(work->message[0]);
	    get_midi_message_type(status) == MessageType::Channel) {

		if (status == MidiStatus::NoteOn || status == MidiStatus::NoteOff) {
			// Drop all MIDI note messages as we won't render any audio
			return;
		}
	}

	ProcessWorkItem(*work);
}

// The request to play the channel message is placed in the MIDI work FIFO
void MidiSynth::SendMidiMessage(const MidiMessage& msg)
{
	std::vector<uint8_t> message(msg.data.begin(), msg.data.end());

	MidiWork work{std::move(message),
	              GetNumPendingAudioFrames(),
	              MessageType::Channel,
	              PIC_AtomicIndex()};

	work_fifo.Enqueue(std::move(work));
}

// The request to play the sysex message is placed in the MIDI work FIFO
void MidiSynth::SendSysExMessage(uint8_t* sysex, size_t len)
{
	std::vector<uint8_t> message(sysex, sysex + len);

	MidiWork work{std::move(message),
	              GetNumPendingAudioFrames(),
	              MessageType::SysEx,
	              PIC_AtomicIndex()};

	work_fifo.Enqueue(std::move(work));
}

int MidiSynth::GetNumPendingAudioFrames()
{
	const auto now_ms = PIC_AtomicIndex();

	// Wake up the channel and update the last rendered time datum.
	assert(mixer_channel);
	if (mixer_channel->WakeUp()) {
		last_rendered_ms.store(now_ms);
		return 0;
	}

	assert(ms_per_audio_frame > 0.0);

	// `last_rendered_ms` is also updated by the mixer callback, so use a
	// compare-exchange loop to avoid losing concurrent updates.
	auto last_ms         = last_rendered_ms.load();
	int num_audio_frames = 0;
	double new_last_ms   = 0.0;

	do {
		if (last_ms >= now_ms) {
			return 0;
		}

		// Number of audio frames needed to get current again
		const auto elapsed_ms = now_ms - last_ms;
		num_audio_frames = iround(ceil(elapsed_ms / ms_per_audio_frame));
		new_last_ms = last_ms + (num_audio_frames * ms_per_audio_frame);

	} while (!last_rendered_ms.compare_exchange_weak(last_ms, new_last_ms));

	return num_audio_frames;
}

// The callback operates at the audio frame-level, steadily adding
// samples to the mixer until the requested numbers of audio frames is
// met.
void MidiSynth::MixerCallback(const int requested_audio_frames)
{
	assert(mixer_channel);

	// Report buffer underruns
	constexpr auto WarningPercent = 5.0f;

	if (const auto percent_full = audio_frame_fifo.GetPercentFull();
	    percent_full < WarningPercent) {

		static auto iteration = 0;
		if (iteration++ % 100 == 0) {
			LOG_WARNING("%s: Audio buffer underrun",
			            upcase(GetName()).c_str());
		}
		had_underruns = true;
	}

	static std::vector<AudioFrame> audio_frames = {};

	// A short read means the fifo was stopped for a pause (or a genuine
	// underrun): add whatever we got and pad the shortfall with silence.
	// Never hand `AddSamples_sfloat` fewer frames than it will read.
	const auto num_dequeued = audio_frame_fifo.BulkDequeue(audio_frames,
	                                                       requested_audio_frames);

	if (num_dequeued > 0) {
		mixer_channel->AddSamples_sfloat(check_cast<int>(num_dequeued),
		                                 &audio_frames[0][0]);

		last_rendered_ms.store(PIC_AtomicIndex());
	}

	if (check_cast<int>(num_dequeued) < requested_audio_frames) {
		mixer_channel->AddSilence();
	}
}

void MidiSynth::Pause()
{
	pauser.Pause();
}

void MidiSynth::Resume()
{
	pauser.Resume();
}
