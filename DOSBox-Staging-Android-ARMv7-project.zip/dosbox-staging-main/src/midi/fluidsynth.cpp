//  SPDX-FileCopyrightText:  2020-2026 The DOSBox Staging Team
//  SPDX-License-Identifier: GPL-2.0-or-later

#include "private/fluidsynth.h"

#include <bitset>
#include <cassert>
#include <compare>
#include <numeric>
#include <string>
#include <tuple>
#include <vector>

#include "audio/channel_names.h"
#include "audio/mixer.h"
#include "config/config.h"
#include "dos/programs.h"
#include "hardware/pic.h"
#include "ints/int10.h"
#include "misc/ansi_code_markup.h"
#include "misc/cross.h"
#include "misc/notifications.h"
#include "misc/support.h"
#include "utils/fs_utils.h"
#include "utils/math_utils.h"
#include "utils/string_utils.h"

#include "riffcpp/riffcpp.hpp"

constexpr auto SoundFontExtension = ".sf2";

constexpr auto ChorusSettingName    = "fsynth_chorus";
constexpr auto DefaultChorusSetting = "auto";
constexpr auto NumChorusParams      = 5;

constexpr auto ReverbSettingName    = "fsynth_reverb";
constexpr auto DefaultReverbSetting = "auto";
constexpr auto NumReverbParams      = 4;

// clang-format off

// Use reasonable default chorus settings matching ScummVM's defaults
constexpr ChorusParameters DefaultChorusParameters = {
	3,    // voice count
	1.2,  // level
	0.3,  // speed
	8.0,  // depth
	fluid_chorus_mod::FLUID_CHORUS_MOD_SINE // mod wave
};

constexpr ChorusParameters GeneralUserGsChorusParameters = {
	4,    // voice count
	0.55, // level
	0.36, // speed
	3.6,  // depth
	fluid_chorus_mod::FLUID_CHORUS_MOD_SINE // mod wave
};

constexpr ChorusParameters Awe32ChorusParameters = {
	3,    // voice count
	0.43, // level
	0.4,  // speed
	4.7,  // depth
	fluid_chorus_mod::FLUID_CHORUS_MOD_SINE // mod wave
};

constexpr ChorusParameters Trevor0402_Sc55ChorusParameters = {
	3,    // voice count
	0.1,  // level
	0.3,  // speed
	8.0,  // depth
	fluid_chorus_mod::FLUID_CHORUS_MOD_SINE // mod wave
};


// Use reasonable default reverb settings matching ScummVM's defaults
constexpr ReverbParameters DefaultReverbParameters = {
	0.61, // room size
	0.23, // damping
	0.76, // width
	0.56  // level
};

constexpr ReverbParameters GeneralUserGsReverbParameters = {
	0.5,  // room size
	0.3,  // damping
	0.8,  // width
	0.7   // level
};

constexpr ReverbParameters Awe32ReverbParameters = {
	0.65, // room size
	0.3,  // damping
	0.8,  // width
	0.6   // level
};

constexpr ReverbParameters Trevor0402_Sc55ReverbParameters = {
	0.61, // room size
	0.23, // damping
	0.76, // width
	0.15  // level
};

// clang-format on

#if defined(WIN32)

static std::vector<std_fs::path> get_platform_data_dirs()
{
	return {
	        get_config_dir() / DefaultSoundfontsDir,

	        // C:\soundfonts is the default place where FluidSynth places
	        // default.sf2
	        // https://www.fluidsynth.org/api/fluidsettings.xml#synth.default-soundfont
	        std::string("C:\\") + DefaultSoundfontsDir + "\\",
	};
}

#elif defined(MACOSX)

static std::vector<std_fs::path> get_platform_data_dirs()
{
	return {
	        get_config_dir() / DefaultSoundfontsDir,
	        resolve_home("~/Library/Audio/Sounds/Banks"),
	};
}

#else

static std::vector<std_fs::path> get_platform_data_dirs()
{
	// First priority is user-specific data location
	const auto xdg_data_home = get_xdg_data_home();

	std::vector<std_fs::path> dirs = {
	        xdg_data_home / "dosbox" / DefaultSoundfontsDir,
	        xdg_data_home / DefaultSoundfontsDir,
	        xdg_data_home / "sounds/sf2",
	};

	// Second priority are the $XDG_DATA_DIRS
	for (const auto& data_dir : get_xdg_data_dirs()) {
		dirs.emplace_back(data_dir / DefaultSoundfontsDir);
		dirs.emplace_back(data_dir / "sounds/sf2");
	}

	// Third priority is $XDG_CONF_HOME, for convenience
	dirs.emplace_back(get_config_dir() / DefaultSoundfontsDir);

	return dirs;
}

#endif

static SectionProp* get_fluidsynth_section()
{
	auto section = get_section("fluidsynth");
	assert(section);

	return section;
}

static std::vector<std_fs::path> get_data_dirs()
{
	auto dirs = get_platform_data_dirs();

	auto sf_dir = get_fluidsynth_section()->GetString("soundfont_dir");
	if (!sf_dir.empty()) {
		// The user-provided SoundFont dir might use a different casing
		// of the actual path on Linux & Windows, so we need to
		// normalise that to avoid some subtle bugs downstream (see
		// `find_sf_file()` as well).
		if (path_exists(sf_dir)) {
			std::error_code err = {};
			const auto canonical_path = std_fs::canonical(sf_dir, err); //-V821
			if (!err) {
				dirs.insert(dirs.begin(), canonical_path);
			}
		} else {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "FSYNTH",
			                      "FLUIDSYNTH_INVALID_SOUNDFONT_DIR",
			                      sf_dir.c_str());

			set_section_property_value("fluidsynth", "soundfont_dir", "");
		}
	}
	return dirs;
}

static std_fs::path find_sf_file(const std::string& sf_name)
{
	const std_fs::path sf_path = resolve_home(sf_name);
	if (path_exists(sf_path)) {
		return sf_path;
	}

	for (const auto& dir : get_data_dirs()) {
		for (const auto& sf :
		     {dir / sf_name, dir / (sf_name + SoundFontExtension)}) {
#if 0
			LOG_DEBUG("FSYNTH: FluidSynth checking if '%s' exists", sf.c_str());
#endif
			if (path_exists(sf)) {
				// Parts of the path come from the `soundfont`
				// setting, and `soundfont = FluidR3_GM.sf2` and
				// `soundfont = fluidr3_gm.sf2` refer to the
				// same file on case-preserving filesystems on
				// Windows and macOS.
				//
				// `std_fs::canonical` returns the absolute path
				// and matches its casing to that of the actual
				// physical file. This prevents certain subtle
				// bugs downstream when we use this path in
				// comparisons.
				std::error_code err = {};
				const auto canonical_path = std_fs::canonical(sf, err);

				if (err) {
					return {};
				}
				return canonical_path;
			}
		}
	}
	return {};
}

static std::string read_soundfont_name(const std_fs::path& path)
{
	const auto& path_str = path.string();

	try {
		riffcpp::Chunk root_chunk(path_str.c_str());

		for (auto list_chunk : root_chunk) {
			if (list_chunk.id() != riffcpp::list_id) {
				continue;
			}
			if (list_chunk.type() != riffcpp::FourCC{'I', 'N', 'F', 'O'}) {
				continue;
			}

			for (auto subchunk : list_chunk) {
				// The 'INAM' ID in the 'INFO" subchunk stores
				// the name of the SOundFont bank
				if (subchunk.id() !=
				    riffcpp::FourCC{'I', 'N', 'A', 'M'}) {
					continue;
				}

				std::string name(subchunk.size(), '\0');
				subchunk.read_data(name.data(), name.size());

				return name;
			}
		}

	} catch (const riffcpp::Error& ex) {
		LOG_WARNING("FSYNTH: Error reading SoundFont metadata of file '%s': %s",
		            path_str.c_str(),
		            ex.what());

	} catch (const std::runtime_error& ex) {
		LOG_ERR("FSYNTH: Unexpected error when reading SoundFont metadata of "
		        "file '%s': %s",
		        path_str.c_str(),
		        ex.what());
	}

	return "";
}

static void log_unknown_midi_message(const std::vector<uint8_t>& msg)
{
	auto append_as_hex = [](const std::string& str, const uint8_t val) {
		constexpr char HexChars[] = "0123456789ABCDEF";
		std::string hex_str;

		hex_str.reserve(2);
		hex_str += HexChars[val >> 4];
		hex_str += HexChars[val & 0x0F];

		return str + (str.empty() ? "" : ", ") + hex_str;
	};

	const auto hex_values = std::accumulate(msg.begin(),
	                                        msg.end(),
	                                        std::string(),
	                                        append_as_hex);

	LOG_WARNING("FSYNTH: Unknown MIDI message sequence (hex): %s",
	            hex_values.c_str());
}

// Checks if the passed effect parameter value is within the valid range and
// returns the default if it's not
static std::optional<double> validate_effect_parameter(
        const char* setting_name, const char* param_name,
        const std::string& value, const double min_value,
        const double max_value, const std::string& default_setting_value)
{
	// Convert the string to a double
	const auto val = parse_float(value);

	if (!val || (*val < min_value || *val > max_value)) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "FSYNTH",
		                      "FLUIDSYNTH_INVALID_EFFECT_PARAMETER",
		                      setting_name,
		                      param_name,
		                      value.c_str(),
		                      min_value,
		                      max_value,
		                      default_setting_value.c_str());
	}
	return val;
}

std::optional<ChorusParameters> parse_custom_chorus_params(const std::string& chorus_pref)
{
	const auto params = split(chorus_pref);

	if (params.size() != NumChorusParams) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "FSYNTH",
		                      "FLUIDSYNTH_INVALID_NUM_EFFECT_PARAMS",
		                      ChorusSettingName,
		                      params.size(),
		                      NumChorusParams);
		return {};
	}

	auto validate = [&](const char* param_name,
	                    const std::string& value,
	                    const double min_value,
	                    const double max_value) {
		return validate_effect_parameter(ChorusSettingName,
		                                 param_name,
		                                 value,
		                                 min_value,
		                                 max_value,
		                                 DefaultChorusSetting);
	};

	const auto voice_count_opt = validate("params voice-count", params[0], 0, 99);
	const auto level_opt = validate("params level", params[1], 0.0, 10.0);
	const auto speed_opt = validate("params speed", params[2], 0.1, 5.0);
	const auto depth_opt = validate("params depth", params[3], 0.0, 21.0);

	const auto mod_wave_opt = [&]() -> std::optional<int> {
		if (params[4] != "triangle" && params[4] != "sine") {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "FSYNTH",
			                      "FLUIDSYNTH_INVALID_CHORUS_WAVE",
			                      params[4].c_str(),
			                      DefaultChorusSetting);
			return {};
		} else {
			return (params[4] == "sine"
			                ? fluid_chorus_mod::FLUID_CHORUS_MOD_SINE
			                : fluid_chorus_mod::FLUID_CHORUS_MOD_TRIANGLE);
		}
	}();

	// One or more parameter couldn't be parsed
	if (!(voice_count_opt && level_opt && speed_opt && depth_opt && mod_wave_opt)) {
		return {};
	}

	// Success
	return ChorusParameters{iround(*voice_count_opt),
	                        *level_opt,
	                        *speed_opt,
	                        *depth_opt,
	                        *mod_wave_opt};
}

void MidiDeviceFluidSynth::SetChorusParams(const ChorusParameters& params)
{
	constexpr int AllFxGroups = -1;

	fluid_synth_set_chorus_group_nr(synth.get(), AllFxGroups, params.voice_count);
	fluid_synth_set_chorus_group_level(synth.get(), AllFxGroups, params.level);
	fluid_synth_set_chorus_group_speed(synth.get(), AllFxGroups, params.speed);
	fluid_synth_set_chorus_group_depth(synth.get(), AllFxGroups, params.depth);
	fluid_synth_set_chorus_group_type(synth.get(), AllFxGroups, params.mod_wave);

	LOG_MSG("FSYNTH: Chorus enabled with %d voices at level %.2f, "
	        "%.2f Hz speed, %.2f depth, and %s-wave modulation",
	        params.voice_count,
	        params.level,
	        params.speed,
	        params.depth,
	        (params.mod_wave == fluid_chorus_mod::FLUID_CHORUS_MOD_SINE
	                 ? "sine"
	                 : "triangle"));
}

void MidiDeviceFluidSynth::SetChorus()
{
	constexpr int AllFxGroups = -1;

	auto enable_chorus = [&] {
		fluid_synth_chorus_on(synth.get(), AllFxGroups, true);
		LOG_MSG("FSYNTH: Chorus enabled");
	};

	auto disable_chorus = [&] {
		fluid_synth_chorus_on(synth.get(), AllFxGroups, false);
		LOG_MSG("FSYNTH: Chorus disabled");
	};

	auto handle_auto_setting = [&]() {
		using enum SoundFont;

		auto log_auto_apply = [] {
			LOG_MSG("FSYNTH: Auto-applying optimal chorus settings");
		};

		switch (soundfont) {
		case Unknown:
			enable_chorus();
			SetChorusParams(DefaultChorusParameters);
			break;

		case GeneralUserGs:
			log_auto_apply();
			enable_chorus();
			SetChorusParams(GeneralUserGsChorusParameters);
			break;

		case Awe32_SynthGs:
		case SbLive_4GmGsMt:
			log_auto_apply();
			enable_chorus();
			SetChorusParams(Awe32ChorusParameters);
			break;

		case FluidR3:
			log_auto_apply();
			disable_chorus();
			break;

		case Trevor0402_Sc55:
			log_auto_apply();
			enable_chorus();
			SetChorusParams(Trevor0402_Sc55ChorusParameters);
			break;

		default: assertm(false, "Invalid SoundFont value");
		};
	};

	const auto pref = get_fluidsynth_section()->GetString(ChorusSettingName);

	if (has_true(pref)) {
		SetChorusParams(DefaultChorusParameters);
		enable_chorus();

	} else if (has_false(pref)) {
		disable_chorus();

	} else if (pref == "auto") {
		handle_auto_setting();

	} else {
		if (const auto chorus_params = parse_custom_chorus_params(pref);
		    chorus_params) {

			SetChorusParams(*chorus_params);
			enable_chorus();

		} else {
			// TODO error

			set_section_property_value("fluidsynth",
			                           ChorusSettingName,
			                           DefaultChorusSetting);
			handle_auto_setting();
		}
	}
}

std::optional<ReverbParameters> parse_custom_reverb_params(const std::string& reverb_pref)
{
	const auto reverb = split(reverb_pref);

	if (reverb.size() != NumReverbParams) {
		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "FSYNTH",
		                      "FLUIDSYNTH_INVALID_NUM_EFFECT_PARAMS",
		                      ReverbSettingName,
		                      reverb.size(),
		                      NumReverbParams);
		return {};
	}

	auto validate = [&](const char* param_name,
	                    const std::string& value,
	                    const double min_value,
	                    const double max_value) {
		return validate_effect_parameter(ReverbSettingName,
		                                 param_name,
		                                 value,
		                                 min_value,
		                                 max_value,
		                                 DefaultReverbSetting);
	};

	const auto room_size_opt = validate("reverb room-size", reverb[0], 0.0, 1.0);
	const auto damping_opt = validate("reverb damping", reverb[1], 0.0, 1.0);
	const auto width_opt = validate("reverb width", reverb[2], 0.0, 100.0);
	const auto level_opt = validate("reverb level", reverb[3], 0.0, 1.0);

	// One or more parameter couldn't be parsed
	if (!(room_size_opt && damping_opt && width_opt && level_opt)) {
		return {};
	}

	// Success
	return ReverbParameters{*room_size_opt, *damping_opt, *width_opt, *level_opt};
}

void MidiDeviceFluidSynth::SetReverbParams(const ReverbParameters& params)
{
	constexpr int AllFxGroups = -1;

	fluid_synth_set_reverb_group_roomsize(synth.get(), AllFxGroups, params.room_size);
	fluid_synth_set_reverb_group_damp(synth.get(), AllFxGroups, params.damping);
	fluid_synth_set_reverb_group_width(synth.get(), AllFxGroups, params.width);
	fluid_synth_set_reverb_group_level(synth.get(), AllFxGroups, params.level);

	LOG_MSG("FSYNTH: Reverb enabled with a %.2f room size, "
	        "%.2f damping, %.2f width, and level %.2f",
	        params.room_size,
	        params.damping,
	        params.width,
	        params.level);
}

void MidiDeviceFluidSynth::SetReverb()
{
	constexpr int AllFxGroups = -1;

	auto enable_reverb = [&] {
		fluid_synth_reverb_on(synth.get(), AllFxGroups, true);
		LOG_MSG("FSYNTH: Reverb enabled");
	};

	auto disable_reverb = [&] {
		fluid_synth_reverb_on(synth.get(), AllFxGroups, false);
		LOG_MSG("FSYNTH: Reverb disabled");
	};

	auto handle_auto_setting = [&]() {
		using enum SoundFont;

		auto log_auto_apply = [] {
			LOG_MSG("FSYNTH: Auto-applying optimal reverb settings");
		};

		switch (soundfont) {
		case Unknown:
		case FluidR3:
			enable_reverb();
			SetReverbParams(DefaultReverbParameters);
			break;

		case GeneralUserGs:
			log_auto_apply();
			enable_reverb();
			SetReverbParams(GeneralUserGsReverbParameters);
			break;

		case Awe32_SynthGs:
		case SbLive_4GmGsMt:
			log_auto_apply();
			enable_reverb();
			SetReverbParams(Awe32ReverbParameters);
			break;

		case Trevor0402_Sc55:
			log_auto_apply();
			enable_reverb();
			SetReverbParams(Trevor0402_Sc55ReverbParameters);
			break;

		default: assertm(false, "Invalid SoundFont value");
		};
	};

	const auto pref = get_fluidsynth_section()->GetString(ReverbSettingName);

	if (has_true(pref)) {
		SetReverbParams(DefaultReverbParameters);
		enable_reverb();

	} else if (has_false(pref)) {
		disable_reverb();

	} else if (pref == "auto") {
		handle_auto_setting();

	} else {
		if (const auto reverb_params = parse_custom_reverb_params(pref);
		    reverb_params) {

			SetReverbParams(*reverb_params);
			enable_reverb();

		} else {
			// TODO error

			set_section_property_value("fluidsynth",
			                           ReverbSettingName,
			                           DefaultReverbSetting);
			handle_auto_setting();
		}
	}
}

void MidiDeviceFluidSynth::SetVolume(const int volume_percent)
{
	const auto gain = static_cast<float>(volume_percent) / 100.0f;
	fluid_synth_set_gain(synth.get(), gain);
}

MidiDeviceFluidSynth::MidiDeviceFluidSynth()
{

	fluid_set_log_function(FLUID_DBG, NULL, NULL);

#ifdef NDEBUG
	fluid_set_log_function(FLUID_INFO, NULL, NULL);
	fluid_set_log_function(FLUID_ERR, NULL, NULL);
	fluid_set_log_function(FLUID_WARN, NULL, NULL);
#endif

	FluidSynthSettingsPtr fluid_settings(new_fluid_settings(),
	                                     delete_fluid_settings);
	if (!fluid_settings) {
		const auto msg = "FSYNTH: Failed to initialise the FluidSynth settings";
		LOG_ERR("%s", msg);
		throw std::runtime_error(msg);
	}

	auto section = get_fluidsynth_section();

	// Detailed explanation of all available FluidSynth settings:
	// http://www.fluidsynth.org/api/fluidsettings.xml

	// Per the FluidSynth API, the sample-rate should be part of the
	// settings used to instantiate the synth, so we use the mixer's
	// native rate to configure FluidSynth.
	const auto sample_rate_hz = MIXER_GetSampleRate();

	fluid_settings_setnum(fluid_settings.get(), "synth.sample-rate", sample_rate_hz);

	FluidSynthPtr fluid_synth(new_fluid_synth(fluid_settings.get()),
	                          delete_fluid_synth);
	if (!fluid_synth) {
		const auto msg = "FSYNTH: Failed to create the FluidSynth synthesizer";
		LOG_ERR("%s", msg);
		throw std::runtime_error(msg);
	}

	// Load the requested SoundFont or quit if none provided
	const auto sf_name = section->GetString("soundfont");
	const auto sf_path = find_sf_file(sf_name);

	constexpr auto ResetPresets = true;
	if (fluid_synth_sfload(fluid_synth.get(),
	                       sf_path.string().c_str(),
	                       ResetPresets) == FLUID_FAILED) {

		const auto msg = format_str("FSYNTH: Error loading SoundFont '%s'",
		                            sf_name.c_str());

		NOTIFY_DisplayWarning(Notification::Source::Console,
		                      "FSYNTH",
		                      "FLUIDSYNTH_ERROR_LOADING_SOUNDFONT",
		                      sf_name.c_str());

		throw std::runtime_error(msg);
	}

	synth    = std::move(fluid_synth);
	settings = std::move(fluid_settings);

	soundfont_path = sf_path;

	IdentifySoundFont();

	const auto volume_percent = section->GetInt("soundfont_volume");
	SetVolume(volume_percent);

	// Let the user know that the SoundFont was loaded
	if (volume_percent == 100) {
		LOG_MSG("FSYNTH: Using SoundFont '%s'", sf_path.string().c_str());
	} else {
		LOG_MSG("FSYNTH: Using SoundFont '%s' with volume scaled to %d%%",
		        sf_path.string().c_str(),
		        volume_percent);
	}

	constexpr int AllFxGroups = -1;

	// Use a 7th-order (highest) polynomial to generate MIDI channel
	// waveforms
	fluid_synth_set_interp_method(fluid_synth.get(),
	                              AllFxGroups,
	                              FLUID_INTERP_HIGHEST);

	// Always use XG/GS mode which emulates the concave curve specific to
	// the Roland Sound Canvas family of sound modules. In this mode the
	// portamento time is 7 bits wide, using only CC5, and the concave curve
	// ranges from 0s to 480s. The curve was reverse engineered from a
	// Roland SC-55 v1.21 hardware unit.
	fluid_synth_set_portamento_time_mode(fluid_synth.get(),
	                                     FLUID_PORTAMENTO_TIME_MODE_XG_GS);

	SetChorus();
	SetReverb();

	MIXER_LockMixerThread();

	// Set up the mixer callback
	const auto mixer_callback = std::bind_front(&MidiSynth::MixerCallback, this);

	mixer_channel = MIXER_AddChannel(mixer_callback,
	                                 sample_rate_hz,
	                                 ChannelName::FluidSynth,
	                                 {ChannelFeature::Sleep,
	                                  ChannelFeature::Stereo,
	                                  ChannelFeature::ReverbSend,
	                                  ChannelFeature::ChorusSend,
	                                  ChannelFeature::Synthesizer});

	// FluidSynth renders float audio frames between -1.0f and
	// +1.0f, so we ask the channel to scale all the samples up to
	// its 0db level.
	mixer_channel->Set0dbScalar(Max16BitSampleValue);

	SetFilter();

	StartRenderer(sample_rate_hz, "dosbox:fsynth");

	// Start playback
	MIXER_UnlockMixerThread();
}

void MidiDeviceFluidSynth::IdentifySoundFont()
{
	assert(synth);

	using enum SoundFont;

	const auto name = read_soundfont_name(soundfont_path);
	LOG_DEBUG("FSYNTH: Loaded SoundFont with name '%s'", name.c_str());

	// Resolve symlinks
	std::error_code err = {};

	const auto canonical_path = std_fs::canonical(soundfont_path, err);
	if (err) {
		soundfont = Unknown;
		return;
	}

	const auto filename = canonical_path.stem().string();

	auto has = find_in_case_insensitive;

	// Most of these SoundFonts don't have unique enough names set in their
	// metadata, so we'll do fuzzy matching based on the filename and the
	// metadata and hope for the best...
	soundfont = [&] {
		if (has("GeneralUser", name) || has("GeneralUser", filename)) {
			// Typical filename:   'GeneralUser-GS.sf2'
			//
			// Name from metadata: 'GeneralUser GS 2.0.3 BETA'
			// (version can change)
			//
			return GeneralUserGs;

		} else if (has("synthgs", filename)) {
			// Typical filename:   'synthgs-sf2_04-compat.sf2'
			// Name from metadata: 'GS' (pretty useless for
			// identification)
			//
			return Awe32_SynthGs;

		} else if (has("4MB GMGSMT", name) || has("4gmgsmt", filename)) {
			// Typical filename:   '4gmgsmt-sf2_04-compat.sf2'
			// Name from metadata: '4MB GMGSMT'
			//
			return Awe32_SynthGs;

		} else if (has("Fluid R3", name) || has("FluidR3", filename) ||
		           has("Fluid_R3", filename) || has("Fluid-R3", filename)) {
			// Typical filename:   'Fluid_R3_GM_GS.sf2'
			// Name from metadata: 'Fluid R3 GM'
			//
			return FluidR3;

		} else if (has("SC-55 SoundFont", name)) {
			// Typical filename:   'SC-55.SoundFont.v1.2b.sf2' (there
			// are lots of filename variations for this; unreliable)
			//
			// Name from metadata: 'SC-55 SoundFont v1.12b' (vague,
			// but let's try that and hope for the best...)
			//
			return Trevor0402_Sc55;

		} else {
			return Unknown;
		}
	}();
}

void MidiDeviceFluidSynth::SetFilter()
{
	const std::string filter_prefs = get_fluidsynth_section()->GetString(
	        "fsynth_filter");

	if (!mixer_channel->TryParseAndSetCustomFilter(filter_prefs)) {
		if (!has_false(filter_prefs)) {
			NOTIFY_DisplayWarning(Notification::Source::Console,
			                      "FSYNTH",
			                      "PROGRAM_CONFIG_INVALID_SETTING",
			                      "fsynth_filter",
			                      filter_prefs.c_str(),
			                      "off");
		}

		mixer_channel->SetHighPassFilter(FilterState::Off);
		mixer_channel->SetLowPassFilter(FilterState::Off);

		set_section_property_value("fluidsynth", "fsynth_filter", "off");
	}
}

void MidiDeviceFluidSynth::ApplyChannelMessage(const std::vector<uint8_t>& msg)
{
	const auto status_byte = msg[0];
	const auto controller  = msg[1];
	const auto status      = get_midi_status(status_byte);
	const auto channel     = get_midi_channel(status_byte);

	// clang-format off
	switch (status) {
	case MidiStatus::NoteOff:         fluid_synth_noteoff(         synth.get(), channel, controller);             break;
	case MidiStatus::NoteOn:          fluid_synth_noteon(          synth.get(), channel, controller, msg[2]);     break;
	case MidiStatus::PolyKeyPressure: fluid_synth_key_pressure(    synth.get(), channel, controller, msg[2]);     break;
	case MidiStatus::ControlChange:   fluid_synth_cc(              synth.get(), channel, controller, msg[2]);     break;
	case MidiStatus::ProgramChange:   fluid_synth_program_change(  synth.get(), channel, controller);             break;
	case MidiStatus::ChannelPressure: fluid_synth_channel_pressure(synth.get(), channel, controller);             break;
	case MidiStatus::PitchBend:       fluid_synth_pitch_bend(      synth.get(), channel, msg[1] + (msg[2] << 7)); break;
	default: log_unknown_midi_message(msg); break;
	}
	// clang-format on
}

// Apply the sysex message to the service
void MidiDeviceFluidSynth::ApplySysExMessage(const std::vector<uint8_t>& msg)
{
	const auto data = reinterpret_cast<const char*>(msg.data());
	const auto n    = static_cast<int>(msg.size());

	fluid_synth_sysex(synth.get(), data, n, nullptr, nullptr, nullptr, false);
}

void MidiDeviceFluidSynth::RenderAudioFramesToFifo(const int num_audio_frames)
{
	static std::vector<AudioFrame> audio_frames = {};

	// Maybe expand the vector
	if (check_cast<int>(audio_frames.size()) < num_audio_frames) {
		audio_frames.resize(num_audio_frames);
	}

	fluid_synth_write_float(synth.get(),
	                        num_audio_frames,
	                        &audio_frames[0][0],
	                        0,
	                        2,
	                        &audio_frames[0][0],
	                        1,
	                        2);

	audio_frame_fifo.BulkEnqueue(audio_frames, num_audio_frames);
}

void MidiDeviceFluidSynth::ProcessWorkItem(const MidiWork& work)
{
	if (work.message_type == MessageType::Channel) {
		assert(work.message.size() <= MaxMidiMessageLen);
		ApplyChannelMessage(work.message);

	} else {
		assert(work.message_type == MessageType::SysEx);
		ApplySysExMessage(work.message);
	}
}

std_fs::path MidiDeviceFluidSynth::GetSoundFontPath()
{
	return soundfont_path;
}

void FSYNTH_ListDevices(MidiDeviceFluidSynth* device, MoreOutputStrings& output)
{
	const size_t term_width = INT10_GetTextColumns();

	constexpr auto Indent   = "  ";
	const auto curr_sf_path = device ? device->GetSoundFontPath() : "";

	auto write_line = [&](const std_fs::path& sf_path) {
		const auto line = truncate_path(sf_path, term_width - strlen(Indent));

		const auto do_highlight = (curr_sf_path == sf_path);
		if (do_highlight) {
			constexpr auto Green = "[color=light-green]";
			constexpr auto Reset = "[reset]";

			output.AddString(convert_ansi_markup(
			        format_str("%s* %s%s\n", Green, line.c_str(), Reset)));
		} else {
			output.AddString("%s%s\n", Indent, line.c_str());
		}
	};

	// Print SoundFont found from user config.
	std::error_code err = {};

	std::vector<std_fs::path> sf_files = {};

	// Go through all SoundFont directories and list all .sf2 files.
	for (const auto& dir_path : get_data_dirs()) {
		for (const auto& entry : std_fs::directory_iterator(dir_path, err)) {
			if (err) {
				// Problem iterating, so skip the directory
				break;
			}

			if (!entry.is_regular_file(err)) {
				// Problem with entry, move onto the
				// next one
				continue;
			}

			const auto& sf_path = entry.path();

			// Is it an .sf2 file?
			auto ext = sf_path.extension().string();
			lowcase(ext);
			if (ext != SoundFontExtension) {
				continue;
			}

			sf_files.emplace_back(sf_path);
		}
	}

	// Add the currently loaded SoundFont to the list if wasn't already
	// found in the standard locations
	if (!curr_sf_path.empty() &&
	    std::ranges::find(sf_files, curr_sf_path) == sf_files.end()) {

		sf_files.emplace_back(curr_sf_path);
	}

	std::ranges::sort(sf_files, [](const std_fs::path& a, const std_fs::path& b) {
		return natural_compare(a.filename().string(), b.filename().string());
	});

	if (sf_files.empty()) {
		output.AddString("%s%s\n",
		                 Indent,
		                 MSG_Get("FLUIDSYNTH_NO_SOUNDFONTS").c_str());
	} else {
		for (const auto& path : sf_files) {
			write_line(path);
		}
	}

	output.AddString("\n");
}

void FSYNTH_Init()
{
	if (const auto device = MIDI_GetCurrentDevice();
	    device && device->GetName() == MidiDeviceName::FluidSynth) {
		MIDI_Init();
	}
}

static void notify_fluidsynth_setting_updated([[maybe_unused]] SectionProp& section,
                                              const std::string& prop_name)
{
	const auto device = dynamic_cast<MidiDeviceFluidSynth*>(
	        MIDI_GetCurrentDevice());

	if (!device) {
		return;
	}

	if (prop_name == ChorusSettingName) {
		device->SetChorus();

	} else if (prop_name == ReverbSettingName) {
		device->SetReverb();

	} else if (prop_name == "fsynth_filter") {
		device->SetFilter();

	} else if (prop_name == "soundfont_volume") {
		device->SetVolume(section.GetInt("soundfont_volume"));

	} else if (prop_name == "soundfont_dir") {
		// no-op; will take effect when loading a SoundFont

	} else {
		MIDI_Init();
	}
}

static void init_fluidsynth_config_settings(SectionProp& secprop)
{
	constexpr auto WhenIdle = Property::Changeable::WhenIdle;

	// Name 'default.sf2' picks the default SoundFont if it's installed
	// in the OS (usually "Fluid_R3").
	auto str_prop = secprop.AddString("soundfont", WhenIdle, "default.sf2");
	str_prop->SetHelp(
	        "Name or path of SoundFont file to use ('default.sf2' by default). The SoundFont\n"
	        "will be looked up in the following locations in order:\n"
	        "\n"
	        "  - The user-defined SoundFont directory (see 'soundfont_dir').\n"
	        "  - The 'soundfonts' directory in your DOSBox configuration directory.\n"
	        "  - Other common system locations.\n"
	        "\n"
	        "The '.sf2' extension can be omitted. You can use paths relative to the above\n"
	        "locations or absolute paths as well.\n"
	        "\n"
	        "Note: Run `MIXER /LISTMIDI` to see the list of available SoundFonts.");

	str_prop = secprop.AddString("soundfont_dir", WhenIdle, "");
	str_prop->SetHelp(
	        "Extra user-defined SoundFont directory (unset by default). If this is set,\n"
	        "SoundFonts are looked up in this directory first, then in the the standard\n"
	        "system locations.");

	constexpr auto DefaultVolume = 100;
	constexpr auto MinVolume     = 1;
	constexpr auto MaxVolume     = 800;

	auto int_prop = secprop.AddInt("soundfont_volume", WhenIdle, DefaultVolume);
	int_prop->SetMinMax(MinVolume, MaxVolume);
	int_prop->SetHelp(
	        format_str("Set the SoundFont's volume as a percentage (%d by default). This is useful for\n"
	                   "normalising the volume of different SoundFonts. The percentage value can range\n"
	                   "from %d to %d.",
	                   DefaultVolume,
	                   MinVolume,
	                   MaxVolume));

	str_prop = secprop.AddString(ChorusSettingName, WhenIdle, DefaultChorusSetting);
	str_prop->SetHelp(format_str(
	        "Configure the FluidSynth chorus ('%s' by default). Possible values:\n"
	        "\n"
	        "  auto:      Automatically apply optimised settings for common SoundFonts, or\n"
	        "             enable chorus with the default settings for all other Soundfonts\n"
	        "             (default).\n"
	        "\n"
	        "  on:        Always enable chorus.\n"
	        "  off:       Disable chorus.\n"
	        "\n"
	        "  <custom>:  Custom setting via five space-separated values:\n"
	        "               - voice-count:      Integer from 0 to 99\n"
	        "               - level:            Decimal from 0.0 to 10.0\n"
	        "               - speed:            Decimal from 0.1 to 5.0 (in Hz)\n"
	        "               - depth:            Decimal from 0.0 to 21.0\n"
	        "               - modulation-wave:  'sine' or 'triangle'\n"
	        "             For example: 'fsynth_chorus = 3 1.2 0.3 8.0 sine'\n"
	        "\n"
	        "Note: You can disable the FluidSynth chorus and enable the mixer-level chorus\n"
	        "      on the FluidSynth channel instead, or enable both chorus effects at the\n"
	        "      same time. Whether this sounds good depends on the SoundFont and the\n"
	        "      chorus settings being used.",
	        DefaultChorusSetting));

	str_prop = secprop.AddString(ReverbSettingName, WhenIdle, DefaultReverbSetting);
	str_prop->SetHelp(format_str(
	        "Configure the FluidSynth reverb ('%s' by default). Possible values:\n"
	        "\n"
	        "  auto:      Automatically apply optimised settings for common SoundFonts, or\n"
	        "             enable reverb with the default settings for all other Soundfonts\n"
	        "             (default).\n"
	        "\n"
	        "  on:        Enable reverb.\n"
	        "  off:       Disable reverb.\n"
	        "\n"
	        "  <custom>:  Custom setting via four space-separated values:\n"
	        "               - room-size:  Decimal from 0.0 to 1.0\n"
	        "               - damping:    Decimal from 0.0 to 1.0\n"
	        "               - width:      Decimal from 0.0 to 100.0\n"
	        "               - level:      Decimal from 0.0 to 1.0\n"
	        "             For example: 'fsynth_reverb = 0.61 0.23 0.76 0.56'\n"
	        "\n"
	        "Note: You can disable the FluidSynth reverb and enable the mixer-level reverb\n"
	        "      on the FluidSynth channel instead, or enable both reverb effects at the\n"
	        "      same time. Whether this sounds good depends on the SoundFont and the\n"
	        "      reverb settings being used.",
	        DefaultReverbSetting));

	str_prop = secprop.AddString("fsynth_filter", WhenIdle, "off");
	assert(str_prop);
	str_prop->SetHelp(
	        "Filter for the FluidSynth audio output ('off' by default). Possible values:\n"
	        "\n"
	        "  off:       Don't filter the output (default).\n"
	        "  <custom>:  Custom filter definition; see 'sb_filter' for details.");
}

static void register_fluidsynth_text_messages()
{
	MSG_Add("FLUIDSYNTH_NO_SOUNDFONTS", "No available SoundFonts");

	MSG_Add("FLUIDSYNTH_INVALID_SOUNDFONT_DIR",
	        "Invalid [color=light-green]soundfont_dir[reset] setting; "
	        "cannot open directory [color=white]'%s'[reset], using ''");

	MSG_Add("FLUIDSYNTH_ERROR_LOADING_SOUNDFONT",
	        "Error loading SoundFont [color=white]'%s'[reset]");

	MSG_Add("FLUIDSYNTH_INVALID_EFFECT_PARAMETER",
	        "Invalid [color=light-green]'%s'[reset] synth parameter (%s): "
	        "[color=white]%s[reset];\n"
	        "must be between %.2f and %.2f, using [color=white]'%s'[reset]");

	MSG_Add("FLUIDSYNTH_INVALID_CHORUS_WAVE",
	        "Invalid [color=light-green]'fsynth_chorus'[reset] synth parameter "
	        "(modulation wave type): [color=white]%s[reset];\n"
	        "must be [color=white]'sine'[reset] or [color=white]'triangle'[reset]");

	MSG_Add("FLUIDSYNTH_INVALID_NUM_EFFECT_PARAMS",
	        "Invalid number of [color=light-green]'%s'[reset] parameters: "
	        "[color=white]%d[reset];\n"
	        "must be %d space-separated values, using [color=white]'auto'[reset]");
}

void FSYNTH_AddConfigSection(const ConfigPtr& conf)
{
	assert(conf);

	auto section = conf->AddSection("fluidsynth");
	section->AddUpdateHandler(notify_fluidsynth_setting_updated);

	init_fluidsynth_config_settings(*section);
	register_fluidsynth_text_messages();
}
